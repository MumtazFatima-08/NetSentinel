# PowerBack

**From scattered signals to coordinated response.**

A citizen-powered outage intelligence and response coordination system, built
for the Global Innovation Hackathon 2026.

> The problem isn't collecting more reports.
> It's understanding which reports describe the same incident.

---

## Quick start

No install step. No API keys. No network access required.

```bash
cd backend
python3 -m powerback.server
```

Open <http://127.0.0.1:8000>, click **Load demo data** in the Response Center,
and the full workflow is live.

Only two third-party packages are needed, and most scientific Python installs
already have them:

```bash
pip install numpy scikit-learn
```

Run the tests:

```bash
cd backend && python3 tests/run_tests.py
# 25 passed, 0 failed, 25 total
```

---

## 1. Problem

A single physical outage does not arrive as one alert. It arrives as dozens of
fragmented observations:

```
18:42  "Power has gone out on our street."
18:44  "Several houses on this road have no electricity."
18:47  "The street lights are also off."
18:51  "Power is still not back."
18:57  "The transformer area appears to be affected."
```

Response teams need **one incident** with its area, severity and evidence — not
five disconnected tickets. And they need to know *why* those reports were
grouped, or they cannot trust the grouping.

## 2. Solution

PowerBack is an **intelligence layer between citizen observations and response
workflows**. It:

1. accepts free-text reports with optional location and photo
2. correlates them using semantic, spatial, temporal and evidence signals
3. forms explainable incidents — showing the actual computed values
4. prioritises them with transparent rules
5. generates a response brief and ticket
6. tracks restoration and verifies recovery before closing

It is **not** a complaint form with a database behind it.

---

## 3. Product lifecycle

```
REPORT → CORRELATE → UNDERSTAND → PRIORITIZE → RESPOND → RESTORE → VERIFY → CLOSE
```

All eight stages are implemented and covered end-to-end by test 15.

---

## 4. What PowerBack does NOT do

This section is deliberately first-class, because these boundaries are enforced
in code and asserted by tests, not just promised in a README.

- **It does not identify which physical component failed.** Correlating
  observations is not the same as diagnosing a transformer. PowerBack says
  "reports cluster here, go and inspect", never "transformer T-42 failed".
- **It does not control electrical infrastructure.** The highest-authority
  output is a `recommended_action` string that a human must act on. Citizen
  reports cannot trigger physical action.
- **It is not connected to any utility or government electricity department.**
  The response queue is simulated. `GET /api/system` reports
  `utility_integration.connected: false`.
- **It does not analyse photos.** No image classifier runs. Photos are
  validated, stored and shown to human reviewers. `evidence.analyze()` returns
  `available: false` and `confidence: null` — never a fabricated number.
- **It does not confirm physical restoration.** It reports restoration
  *confidence* derived from observable signals. Confirming actual grid
  restoration requires utility telemetry we do not have.

Test 20 (`No fabricated AI outputs are emitted anywhere`) asserts several of
these directly.

---

## 5. Architecture

Modular monolith. Full detail in [`docs/architecture.md`](docs/architecture.md).

```
frontend/          vanilla JS — no build step, no CDN, no framework
backend/
  powerback/
    config.py      every weight & threshold (no magic numbers elsewhere)
    lexicon.py     domain concept ontology + latent factor space
    symptoms.py    concept extraction            [rule-based]
    semantic.py    vector encoding + cosine      [vector-space model]
    geo.py         haversine, centroid, bbox, projection
    correlation.py the merge / review / new decision
    priority.py    response urgency              [rule-based]
    lifecycle.py   incident + ticket state machines
    restoration.py restoration confidence
    evidence.py    photo validation & storage    [no computer vision]
    abuse.py       rate limiting, duplicates, flags
    audit.py       append-only action trail
    service.py     the whole workflow, framework-agnostic
    server.py      stdlib HTTP transport         [primary, tested]
    api_fastapi.py FastAPI transport             [optional]
    seed.py        synthetic demo data
  tests/run_tests.py
docs/
```

`service.py` imports no web framework, so the test suite drives exactly the
code path the UI drives.

---

## 6. Correlation algorithm

Full detail, including a measured failure and how we fixed it, in
[`docs/correlation-engine.md`](docs/correlation-engine.md).

**Candidate gates** (hard): 600 m, 120 min, index-assisted bounding box.

**Four signals**, each in `[0,1]`:

| Signal | Weight | Method |
|---|---|---|
| Semantic | 0.50 | Max cosine against confirmed members |
| Spatial | 0.25 | `exp(-(d/350)²)` on haversine distance |
| Temporal | 0.15 | `exp(-Δt/45)` minutes |
| Evidence | 0.10 | Jaccard overlap of extracted concepts |

Missing signals are **excluded and the weights renormalised** — a missing GPS
fix is not scored as zero.

**Decision:**

| Confidence | Outcome |
|---|---|
| ≥ 0.60 and semantic ≥ 0.30 | `MERGE` |
| ≥ 0.60 but semantic < 0.30 | `REVIEW` (semantic floor blocked the merge) |
| 0.42 – 0.60 | `REVIEW` — a human decides |
| < 0.42 | `NEW` incident |

The **semantic floor** is what stops a burst water main 70 m away and two
minutes later from being absorbed into an outage on proximity alone.

### About the semantic model — read this

We first shipped plain TF-IDF. It failed, measurably: two reports of the *same*
outage scored **0.03**, while an outage and a garbage complaint scored **0.33**
(both contained "street"). Short citizen reports describe one event with almost
no shared vocabulary.

The fix was to ground text in a domain concept ontology projected into a
9-dimensional latent factor space, concatenated with a lower-weighted lexical
TF-IDF vector. Result on the demo set:

| | Mean cosine |
|---|---|
| Within the same outage | **0.53** |
| Outage vs. unrelated complaints | **0.008** |

This is a genuine vector space model with genuine cosine similarity — but it is
**lexical and ontological, not neural**, and the product says so at
`GET /api/system` and in the UI. Installing `sentence-transformers` switches it
to `all-MiniLM-L6-v2` neural embeddings automatically, with no code change.

---

## 7. Priority logic

Transparent rules, not a black-box model — because prioritisation decides who
gets power back first and must be auditable and appealable.

| Rule | Points |
|---|---|
| Safety hazard reported | +45 |
| Correlated reports | +5 each, capped at 30 |
| Rapid report growth (≥2.5 / 10 min) | +14 |
| Area-wide impact | +12 |
| Sustained outage (≥45 min) | +10 |
| Critical premises affected | +18 |
| Photo attached for review | +6 |

Bands: `CRITICAL ≥70`, `HIGH ≥42`, `MEDIUM ≥20`, else `LOW`.

Every reason shown in the UI carries the rule name, the triggering value and
the points — so a displayed justification always corresponds to a rule that
actually fired.

**Correlation confidence and priority are strictly separate.** A hazard makes
an incident *urgent*; it does not make the grouping more *certain*. Test 21
asserts they are not the same number.

---

## 8. Restoration verification

| Signal | Weight |
|---|---|
| Response team update | 0.45 |
| Citizen confirmations (saturating at 3) | 0.35 |
| No new reports for 20 min | 0.20 |
| Utility telemetry | **0.00 — not connected** |

Verification is refused below 0.70 confidence, with the reason and the current
value returned. The `utility_status` signal is wired at weight zero so
integrating a real feed is configuration, not a rewrite — and so nobody can
mistake this build for one that has such a feed.

Terminology is always "restoration confidence", never "restoration confirmed".

---

## 9. Tech stack

| Layer | Choice | Why |
|---|---|---|
| Frontend | Vanilla JS + CSS, no build | Deploys as static files anywhere; cannot fail on a bundler or CDN |
| Map | Hand-rolled SVG from live data | No tile service, no API key, no rate limit |
| Backend | Python stdlib `http.server` (FastAPI optional) | Starts with zero install |
| Database | SQLite | Zero setup; parameterised SQL keeps the PostgreSQL path open |
| Semantic | scikit-learn + numpy (sentence-transformers optional) | Free, local, no API key |

**Every dependency is free and open-source. Nothing requires an API key, a
credit card, or a paid tier.**

### External service audit

| Service | Used? | Key needed? | Can we run without it? |
|---|---|---|---|
| Any LLM API | No | — | Yes — never called |
| Map tile provider | No | — | Yes — map is self-rendered |
| Geocoding API | No | — | Yes — raw coordinates only |
| `sentence-transformers` | Optional | No | Yes — automatic fallback |

---

## 10. Setup

```bash
git clone <repo> && cd powerback
pip install numpy scikit-learn        # the only required dependencies
cd backend && python3 -m powerback.server
```

Optional upgrades:

```bash
pip install sentence-transformers      # neural semantic backend, auto-detected
pip install fastapi uvicorn            # alternative transport
uvicorn powerback.api_fastapi:app --port 8000
```

## 11. Environment variables

Every value has a working default; the app runs with **no `.env` at all**. See
[`.env.example`](.env.example). There are deliberately no API keys in it.

---

## 12. Demo script

1. `python3 -m powerback.server`, open <http://127.0.0.1:8000>
2. **Response Center → Load demo data**

This runs four synthetic scenarios through the **real pipeline** — nothing is
hardcoded:

| Scenario | Reports | Engine's decision |
|---|---|---|
| **A** — one street, 15 min | 5 | All `MERGE` → one `HIGH` incident |
| **B** — different street, 1.1 km away | 2 | `NEW` → separate incident |
| **D** — "Sparks near the pole", same place & time | 1 | `REVIEW` → human decides |
| **C** — resubmission + a water leak | 2 | `DUPLICATE` and `NEW` |

3. Open the incident → **"Why did PowerBack group these reports?"** shows the
   real computed signal values per report.
4. Response Center → **Needs your decision** → confirm the sparks report →
   priority escalates `HIGH → CRITICAL` because a hazard is now confirmed.
5. **Open response ticket** → read the generated brief → advance
   `Assigned → Field action → Restoration pending`.
6. **Restoration** → record team + citizen signals → watch confidence rise →
   **Verify** (refused below 0.70) → **Close**.
7. Repeat step 2 — the demo resets cleanly and reproduces identically
   (asserted by test 24).

### No hardcoded demo result

The seeder submits reports through `service.submit_report()`, the same function
the public API calls. Incident numbers, confidences, priorities and groupings
are whatever the engine computes at seed time.

---

## 13. Testing

```bash
cd backend && python3 tests/run_tests.py
```

25 tests, zero dependencies (pytest is not required), fresh database per test.

| # | Test |
|---|---|
| 1 | Same-event reports correlate into one incident |
| 2 | Nearby but semantically different reports are not blindly merged |
| 3 | Large time gaps prevent merging |
| 4 | Duplicates detected; different witnesses are *not* duplicates |
| 5 | Missing photo does not break processing |
| 6 | Missing location handled; half-coordinates rejected |
| 7 | Short/noisy/emoji/oversized text does not crash the engine |
| 8 | Safety indicators raise priority per the defined rules |
| 9 | Incident generates a response brief and ticket |
| 10 | Ticket progresses through valid states |
| 11 | Restoration updates recorded; invalid sources rejected |
| 12 | Verification closes an incident; premature verification refused |
| 13 | Invalid state transitions rejected; state machine self-consistent |
| 14 | Invalid payloads rejected cleanly with useful messages |
| 15 | **Full end-to-end lifecycle** |
| 16 | All three correlation outcomes are reachable |
| 17 | Human review can confirm or separate |
| 18 | Pending-review reports do not silently affect the incident |
| 19 | Rate limiting protects the public endpoint |
| 20 | **No fabricated AI outputs anywhere** |
| 21 | Correlation confidence and priority are independent |
| 22 | Geospatial/temporal maths verified against known values |
| 23 | Concept extraction has no false positives ("shocking news") |
| 24 | Clean-state demo seed is reproducible |
| 25 | **Live HTTP smoke test** incl. status codes and path traversal |

---

## 14. API

| Method | Endpoint | Purpose |
|---|---|---|
| `GET` | `/api/health` | Liveness |
| `GET` | `/api/system` | Capability report — what is and isn't enabled |
| `GET` | `/api/stats` | Aggregate counts |
| `POST` | `/api/reports` | Submit a citizen report |
| `GET` | `/api/reports` | List reports |
| `GET` | `/api/incidents` | List incidents |
| `GET` | `/api/incidents/{ref}` | Incident detail |
| `GET` | `/api/incidents/{ref}/explain` | Why these reports were grouped |
| `POST` | `/api/incidents/{ref}/response` | Open a response ticket |
| `POST` | `/api/incidents/{ref}/restoration` | Record a restoration signal |
| `POST` | `/api/incidents/{ref}/verify` | Verify restoration |
| `POST` | `/api/incidents/{ref}/close` | Close the incident |
| `PATCH` | `/api/response-tickets/{ref}` | Advance a ticket |
| `GET` | `/api/reviews` | Pending human reviews |
| `POST` | `/api/reviews/{id}` | `CONFIRM` or `REJECT` |
| `POST` | `/api/demo/seed` | Load synthetic scenarios |

Status codes: `400` validation, `404` not found, `409` invalid state
transition (with allowed next states), `429` rate limited (with retry hint),
`500` safe message only.

---

## 15. Security

Detail in [`docs/architecture.md#6-security-posture`](docs/architecture.md).

Input validation · parameterised SQL · magic-byte file validation · size caps ·
path-traversal protection (tested) · rate limiting · duplicate detection ·
configurable CORS · safe error responses · append-only audit log.

**PII minimisation:** no name, phone, email or address is ever collected. The
only identifier is a pseudonymous browser-generated session id used solely for
rate limiting and duplicate detection.

---

## 16. Limitations

Stated plainly, because a prototype that hides its limits cannot be trusted
with the parts that do work.

1. **Demo data is synthetic.** No real outage, locality or utility is
   represented.
2. **No utility telemetry or DISCOM integration.** The operator queue is
   simulated.
3. **No image analysis.** Photos are evidence for humans, not model input.
4. **The active semantic model is lexical + ontological, not neural**, and is
   English-only. Installing `sentence-transformers` upgrades it.
5. **Thresholds are prototype parameters** tuned on synthetic data. They are
   not claimed to be optimal and need real-world calibration.
6. **Semantic similarity is not physical causality.** Similar descriptions from
   one area suggest a shared incident; they do not prove a shared cause.
7. **Restoration verification is probabilistic** without authoritative
   telemetry.
8. **Citizen reports are noisy**, and correlation quality depends on report
   density. A sparsely-reported outage may not correlate at all.
9. **SQLite serialises writes.** Fine for a prototype, not for a city.
10. **No browser is available in this build sandbox**, so full pixel-level,
    cross-device screenshot QA has not been performed by the assistant. What
    *has* been done: the product team manually inspected the app in a real
    browser and found a genuine SVG-icon rendering defect (icon markup was
    appearing as literal text in button labels); the root cause was traced to
    the icon pipeline (a helper returned an SVG string that got wrapped in a
    text node instead of parsed as markup), fixed by having icons construct
    real `SVGElement` nodes via `createElementNS` throughout, and the fix was
    verified by executing the actual affected functions — extracted verbatim
    from `app.js` — against a from-scratch DOM shim built for this purpose
    (`frontend/verify_svg_fix.js`, `PYTHONPATH`-free, zero new dependencies),
    which confirms no raw SVG text reaches any tested DOM path and that the
    map's label-placement logic produces zero collisions against demo-shaped
    data. This is real code-execution verification of the reported defects,
    not a substitute for full visual regression testing across browsers and
    devices, which the team should still do before a production release.

---

## 17. Future integration

Not implemented — listed as future scope, not current capability:

utility telemetry & SCADA feeds · smart meter last-gasp signals · DISCOM
ticketing adapters · weather correlation · outage history and repeat-fault
analytics · critical-infrastructure registries · multilingual reporting ·
SMS/IVR reporting for non-smartphone users · predictive outage analytics.

The `utility_status` restoration signal and `SOURCE_UTILITY` already exist at
weight zero specifically so the first of these is an adapter, not a redesign.

---

## 18. Attribution

- [scikit-learn](https://scikit-learn.org/) — BSD-3-Clause — TF-IDF vectoriser
- [NumPy](https://numpy.org/) — BSD-3-Clause — vector maths
- [sentence-transformers](https://www.sbert.net/) — Apache-2.0 — optional
  neural backend
- [FastAPI](https://fastapi.tiangolo.com/) — MIT — optional transport

Everything else — correlation engine, concept ontology, priority rules, state
machines, SVG map renderer, UI, test harness — is original work for this
submission.

## 19. AI-assisted development

This project was built with AI assistance (Claude) for implementation,
documentation and test authoring, under the team's direction and review. All
architectural decisions, product boundaries and the honesty constraints above
were specified by the team. The team is responsible for the correctness,
originality and integrity of the submission.

Notably, AI assistance did **not** paper over the two significant failures
encountered during the build — the TF-IDF discrimination failure and the
orthogonal-concept failure. Both were measured, diagnosed and fixed, and both
are documented in `docs/correlation-engine.md` rather than quietly removed.

---

**Team Sunrisers** · Global Innovation Hackathon 2026 · *Innovate Without Borders*
