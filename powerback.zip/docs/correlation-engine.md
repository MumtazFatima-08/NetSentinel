# The PowerBack Correlation Engine

This document describes exactly how PowerBack decides whether two citizen
reports describe the same physical incident. It is written so a skeptical
engineer can check every claim against the code.

Implementation: `backend/powerback/correlation.py`
Parameters: `backend/powerback/config.py` (no magic numbers live anywhere else)

---

## 1. The problem

A single physical outage does not arrive as one alert. It arrives as this:

```
18:42  "Power has gone out on our street."
18:44  "Several houses on this road have no electricity."
18:47  "The street lights are also off."
18:51  "Power is still not back."
18:57  "The transformer area appears to be affected."
```

Five reports. One event. A response team needs to see one incident, not five
tickets — and it needs to know *why* they were grouped.

The hard part is not collecting reports. It is deciding which reports belong
together, **without** merging genuinely separate events that happen to be
nearby.

---

## 2. Pipeline

```
new report
    |
    v
[1] CANDIDATE SELECTION      hard spatial + temporal gates (indexed)
    |
    v
[2] SIGNAL SCORING           semantic | spatial | temporal | evidence
    |
    v
[3] COMBINATION              weighted mean over AVAILABLE signals
    |
    v
[4] DECISION                 MERGE | REVIEW | NEW  (+ semantic floor)
```

---

## 3. Candidate selection

Before any expensive comparison, incidents are filtered by two hard gates:

| Gate | Default | Config key |
|---|---|---|
| Distance from incident centroid | 600 m (+ the incident's own radius) | `PB_CANDIDATE_RADIUS_M` |
| Time from incident's last activity | 120 min | `PB_CANDIDATE_WINDOW_MIN` |

Incidents in `RESTORED`, `VERIFICATION` or `CLOSED` are excluded — a closed
incident must not silently reopen.

**Why this matters for scale.** The spatial filter runs first as an indexed
lat/lon bounding-box range query (`geo.bounding_box`), so the database returns
a small candidate set and exact haversine + semantic comparison run only on
that set. Without it, every new report would scan every incident.

Reports with no location skip the spatial gate and rely on the temporal gate.

---

## 4. The four signals

Each signal is independently computed, independently explainable, and bounded
to `[0, 1]`.

### 4.1 Semantic — weight 0.50

Cosine similarity between the new report's vector and the vectors of the
incident's **confirmed** member reports.

```
semantic = max over confirmed members m of  cos(v_new, v_m)
```

*Max, not mean.* An incident legitimately accumulates different facets of one
event ("no power", "streetlights off", "transformer noise"). Matching any one
member strongly is evidence of belonging; averaging would dilute that as the
incident grows, so late reports would be penalised for arriving late.

*Confirmed members only.* Reports that are themselves awaiting human review are
excluded from comparison, so one uncertain decision cannot cascade into many.

**How vectors are built** (`semantic.py`): see §7 — this is the part most
worth scrutinising.

### 4.2 Spatial — weight 0.25

Gaussian decay on haversine distance:

```
spatial = exp( -(distance_m / 350)^2 )
```

1.0 at zero distance, ≈0.37 at 350 m, ≈0 well beyond. Smooth, monotonic, and
trivially explainable to a non-technical operator ("they were 80 m apart").

### 4.3 Temporal — weight 0.15

Exponential decay on the gap to the incident's most recent report:

```
temporal = exp( -minutes_apart / 45 )
```

### 4.4 Evidence — weight 0.10

Jaccard overlap between the concepts extracted from the new report and the
concepts accumulated on the incident:

```
evidence = |concepts_report ∩ concepts_incident| / |union|
```

**This signal contains no computer vision.** It is derived from text concepts
and photo presence only. PowerBack runs no image classifier and never emits an
image-derived confidence. See `evidence.py`.

---

## 5. Combination

```
                Σ (score_i × weight_i)   for available signals i
confidence =   ────────────────────────
                Σ weight_i               for available signals i
```

**Missing signals are excluded and the weights renormalise.** A report with no
GPS fix does not score 0.0 on the spatial axis — the spatial axis is removed
and the remaining three are rescaled. Treating "unknown" as "zero" would
silently push valid correlations below threshold whenever a phone failed to get
a location.

---

## 6. Decision

| Condition | Outcome |
|---|---|
| `confidence ≥ 0.60` **and** `semantic ≥ 0.30` | `MERGE` — attach to the incident |
| `confidence ≥ 0.60` **but** `semantic < 0.30` | `REVIEW` — blocked by the semantic floor |
| `0.42 ≤ confidence < 0.60` | `REVIEW` — a human decides |
| `confidence < 0.42` | `NEW` — separate incident |

### The semantic floor is the important one

Proximity is cheap evidence. In a dense neighbourhood, *everything* is nearby
and recent. Without a floor, a report of a burst water main 70 m away from an
active outage, two minutes later, scores highly on spatial and temporal and
gets merged into the outage — corrupting the incident and hiding a real
separate problem.

The floor states: **however close in space and time, if the descriptions do not
agree at all, do not merge automatically — ask a human.**

### Supporting uncertainty is a feature, not a gap

`REVIEW` is a real workflow state, not a dead end. `POST /api/reviews/{id}` with
`CONFIRM` attaches the report; `REJECT` detaches it and promotes it into its own
incident. Until resolved, a pending report:

- does **not** count toward `report_count`
- does **not** move the centroid or affected radius
- does **not** raise priority or set the hazard flag
- **is** visible in the UI and on the map, outlined rather than filled

---

## 7. How the semantic vectors are built

This is where the "is your AI real?" question lands, so here is the full story
including a failure we hit.

### 7.1 Backends

| Backend | Status | Method |
|---|---|---|
| `sentence-transformers` (`all-MiniLM-L6-v2`) | Used automatically **if installed** | Dense contextual neural embeddings |
| `concept+tfidf` | **Active default in this build** | Lexicon-grounded concept vector ⊕ lexical TF-IDF |

The active backend is reported at `GET /api/system` and rendered in the UI, so
the product cannot misrepresent what is running. The default is the non-neural
backend because this prototype was built without network access and could not
download model weights.

### 7.2 Why not plain TF-IDF — a measured failure

The first implementation was straight TF-IDF + cosine. It did not work:

| Pair | TF-IDF cosine |
|---|---|
| "Power has gone out on our street" ↔ "Several houses on this road have no electricity" | **0.03** |
| "Power has gone out on our street" ↔ "Garbage has not been collected on our street" | **0.33** |

Two reports of the *same outage* scored 0.03. An outage and a *garbage
complaint* scored 0.33 — because both contain "street". Short citizen reports
describe one event with almost no shared vocabulary, so a bag-of-words model is
structurally unable to correlate them.

### 7.3 The fix: a concept space with latent factors

Text is matched against a domain ontology (`lexicon.py`) of ~11 concepts —
`POWER_ABSENT`, `AREA_WIDE`, `STREETLIGHT`, `EQUIPMENT`, `HAZARD`,
`PERSISTING`, `PARTIAL`, `RESTORED`, `WEATHER`, `CRITICAL_INFRA`,
`NON_ELECTRICAL` — using word-boundary-anchored patterns (so "shocking news"
does not register an electric shock).

Concepts are **not** orthogonal axes. Treating them as orthogonal made "the
street lights are off" score exactly 0.00 against "power has gone out", which is
just as wrong as the TF-IDF result. Instead each concept has coordinates in a
9-dimensional latent factor space:

```
FACTORS = outage_core, area_scale, equipment, hazard, persistence,
          restoration, critical, weather, other_domain

POWER_ABSENT   -> outage_core 1.00, area_scale 0.15
STREETLIGHT    -> outage_core 0.70, area_scale 0.45, equipment 0.25
PERSISTING     -> outage_core 0.85, persistence 1.00
NON_ELECTRICAL -> other_domain 1.00
```

Related concepts share factors, so relatedness is graded rather than
all-or-nothing, and the space remains a proper inner-product space (cosine
stays well-defined, vectors stay cacheable).

A lexical TF-IDF vector (word 1–2gram + char_wb 3–5gram, fitted on a fixed
domain corpus) is concatenated at lower weight so unseen phrasing still
contributes:

```
v = normalise( concat( 0.88 × concept_vec , 0.30 × tfidf_vec ) )
```

### 7.4 Measured result

| Group | Mean cosine |
|---|---|
| Within the 5-report demo outage | **0.53** |
| Outage vs. unrelated complaints | **0.008** (max 0.035) |

A wide, stable margin — which is what makes the thresholds in §6 meaningful.

### 7.5 Honest limitations of this backend

- It is **lexical + ontological**, not contextual. It cannot understand
  negation, sarcasm, or phrasing wholly outside the ontology.
- The ontology is **English-only**. Multilingual reporting needs either the
  neural backend or a translated lexicon.
- Concept coverage is hand-built and will have gaps on real-world data.
- Installing `sentence-transformers` upgrades this automatically, with no code
  change.

---

## 8. Performance

- Embeddings are computed **once** at intake and cached as a BLOB on the report
  row; correlation reads vectors, never re-encodes.
- Candidate selection is index-assisted (`idx_incidents_lat/lon/status/seen`)
  and capped, so semantic comparison runs against a bounded set.
- Member comparison is capped at the 25 most recent reports per incident.
- A fixed TF-IDF corpus keeps the vector space stable across restarts, so
  cached vectors remain valid — no re-indexing on deploy.

---

## 9. Calibration status — read this before quoting numbers

The weights and thresholds were tuned against the **synthetic** demo dataset in
`seed.py` and the 25-test suite. They are **prototype parameters**.

We do **not** claim they are optimal, and we have no real-world outage corpus to
validate them against. Deployment in any real locality would require
recalibration against labelled local data, and the thresholds are all
environment-overridable precisely so that is possible without a code change.

---

## 10. Known failure modes

| Failure mode | Current mitigation |
|---|---|
| Two genuinely separate outages on one street, minutes apart | Semantic floor sends the ambiguous report to human review rather than merging |
| Outage described entirely outside the ontology | Lexical component contributes; otherwise falls to `NEW` and a human sees it |
| A very large outage spanning > 600 m | The candidate radius is extended by the incident's own affected radius, so an established incident can absorb edge reports |
| Coordinated spam from one session | Rate limiting + duplicate detection + flags; flagged reports cannot escalate priority |
| Identical wording from two real neighbours | Duplicate detection requires the **same session** plus proximity in time and space, so distinct witnesses are never collapsed |
