# PowerBack Architecture

A modular monolith. Deliberately not microservices: this is a prototype that
must start with one command and be debuggable under demo pressure.

---

## 1. Request flow

```
                    Citizen                      Operator
                       |                             |
                       v                             v
        ┌──────────────────────────────────────────────────────┐
        │  Frontend  (vanilla JS, no build step, no CDN)       │
        │  report · processing · response center · incident    │
        └──────────────────────────┬───────────────────────────┘
                                   │  JSON over HTTP
                                   v
        ┌──────────────────────────────────────────────────────┐
        │  Transport                                           │
        │  server.py  (stdlib — primary, tested)               │
        │  api_fastapi.py  (optional, same service calls)      │
        └──────────────────────────┬───────────────────────────┘
                                   v
        ┌──────────────────────────────────────────────────────┐
        │  service.py — ALL workflow, framework-agnostic       │
        └──────────────────────────┬───────────────────────────┘
                                   v
   ┌───────────────────────────────────────────────────────────────┐
   │  Report intake                                                │
   │    symptoms.py   concept extraction (rule-based)              │
   │    semantic.py   vector encoding (cached)                     │
   │    abuse.py      rate limit · duplicates · flags              │
   │    evidence.py   photo validation + storage (no CV)           │
   └───────────────────────────────┬───────────────────────────────┘
                                   v
   ┌───────────────────────────────────────────────────────────────┐
   │  correlation.py                                               │
   │    candidate selection → semantic | spatial | temporal |       │
   │    evidence → combine → MERGE / REVIEW / NEW                  │
   └───────────────────────────────┬───────────────────────────────┘
                                   v
   ┌───────────────────────────────────────────────────────────────┐
   │  Incident engine (service.recompute_incident)                 │
   │    centroid · affected radius · symptoms · evidence summary   │
   └───────────────────────────────┬───────────────────────────────┘
                                   v
   ┌───────────────────────────────────────────────────────────────┐
   │  priority.py    transparent rules → score + traceable reasons │
   └───────────────────────────────┬───────────────────────────────┘
                                   v
   ┌───────────────────────────────────────────────────────────────┐
   │  Response       brief + ticket · lifecycle.py state machine   │
   └───────────────────────────────┬───────────────────────────────┘
                                   v
   ┌───────────────────────────────────────────────────────────────┐
   │  restoration.py  weighted signals → restoration CONFIDENCE    │
   └───────────────────────────────┬───────────────────────────────┘
                                   v
   ┌───────────────────────────────────────────────────────────────┐
   │  Verification → CLOSED     (audit.py records every step)      │
   └───────────────────────────────────────────────────────────────┘
                                   │
                                   v
                    database.py — SQLite, parameterised SQL
```

---

## 2. Components

| Module | Responsibility | Nature |
|---|---|---|
| `config.py` | Every weight, threshold and limit | Configuration — no logic |
| `lexicon.py` | Domain concept ontology + latent factor space | Data |
| `symptoms.py` | Concept matching, symptom/hazard extraction | **Rule-based** (labelled as such) |
| `semantic.py` | Vector encoding, cosine similarity | **Vector-space model** |
| `geo.py` | Haversine, centroid, bounding box, projection | Pure maths |
| `correlation.py` | The merge/review/new decision | Scoring |
| `priority.py` | Response urgency | **Rule-based** (labelled as such) |
| `lifecycle.py` | Incident + ticket state machines | Validation |
| `restoration.py` | Restoration confidence | Weighted signals |
| `evidence.py` | Photo validation + storage | **No computer vision** |
| `abuse.py` | Rate limit, duplicates, suspicion flags | Protection |
| `audit.py` | Append-only action trail | Logging |
| `service.py` | Orchestration of the whole lifecycle | Application core |
| `server.py` | Stdlib HTTP transport | Primary transport |
| `api_fastapi.py` | FastAPI transport | Optional, unverified here |
| `seed.py` | Synthetic demo data via the real pipeline | Demo |

**Why `service.py` imports no web framework:** the test suite drives the exact
code path the UI drives. A passing test therefore means the demo works, not
merely that a function works.

---

## 3. Data model

```
reports ──┬── incident_reports ──┬── incidents ──┬── response_tickets
          │   (link + score +    │               │
          │    match reasons)    │               └── restoration_updates
          │                      │
          └── embedding BLOB     └── link_type: MERGED | PENDING_REVIEW

audit_logs  (entity_type, entity_id, action, detail, actor, created_at)
```

Key decisions:

- **Reports are never destroyed by correlation.** The link table carries the
  score and the full reasoning; the original report row is untouched. Evidence
  survives regrouping.
- **`link_type` encodes uncertainty in the data model**, not just the UI. A
  `PENDING_REVIEW` row is attached but excluded from geometry, counts and
  priority.
- **Embeddings are cached** on the report row, so correlation never re-encodes.
- **Indices** on `(latitude)`, `(longitude)`, `(occurred_at)`,
  `(session_id, created_at)`, incident `(status)`, `(last_seen)`, centroid
  lat/lon — these are what keep candidate selection off a full table scan.

### PostgreSQL migration path

`database.py` is parameterised SQL behind a thin connection helper — no ORM. To
move: swap the connection factory, change `AUTOINCREMENT` → `SERIAL`/`IDENTITY`,
and `BLOB` → `BYTEA`. Queries are unchanged. For large deployments the
bounding-box pre-filter would become PostGIS `ST_DWithin` with a GiST index.

---

## 4. Lifecycle state machine

```
NEW_SIGNALS → INCIDENT_DETECTED → VALIDATING → PRIORITIZED
    → RESPONSE_CREATED → ASSIGNED → FIELD_ACTION
    → RESTORATION_PENDING → RESTORED → VERIFICATION → CLOSED
```

- Transitions are validated; invalid ones raise `TransitionError` → HTTP 409
  with the allowed next states listed.
- `RESPONSE_CREATED → RESTORATION_PENDING` is permitted directly: supply is
  often restored before a crew is formally assigned, and forcing the path
  through `ASSIGNED` would strand those incidents.
- `VERIFICATION → FIELD_ACTION` is permitted: verification can **fail**.
- `CLOSED` is terminal.
- The ticket machine is mapped onto the incident machine
  (`TICKET_TO_INCIDENT`), so the two cannot diverge — a ticket cannot read
  "Closed" while its incident is open.

---

## 5. Where the AI actually is

A judge asking "show me where the AI happens" should be pointed at:

| Claim | Location | What it really is |
|---|---|---|
| Semantic similarity | `semantic.py` → `encode()`, `cosine()` | Real vector space model + cosine. Concept+TF-IDF by default; neural embeddings if `sentence-transformers` is installed |
| Spatial correlation | `geo.py` → `haversine_m`, `spatial_score` | Real geodesic maths + Gaussian decay |
| Temporal correlation | `correlation.py` → `_temporal_signal` | Exponential time decay |
| Concept extraction | `symptoms.py` | **Rule-based** — and called rule-based |
| Priority | `priority.py` | **Rule-based** — and called rule-based |
| Image understanding | `evidence.py` → `analyze()` | **Not implemented.** Returns `available: false`, never a fabricated confidence |

We do not attach the word "AI" to the rule-based components.

---

## 6. Security posture

| Control | Implementation |
|---|---|
| Input validation | `service._validate_report_payload` — length, coordinate range, unparseable-coordinate rejection |
| SQL injection | Parameterised queries throughout; no string interpolation of user input |
| File upload | Magic-byte sniffing (declared MIME untrusted), size cap, extension derived from real type, content-addressed filename |
| Path traversal | `server._safe_join` — verified by a test that attempts `/media/../powerback/config.py` |
| Rate limiting | Per-session sliding window → HTTP 429 with retry hint |
| Duplicate/spam | Semantic + spatial + temporal + session duplicate detection; suspicion flags block priority escalation |
| Error leakage | Tracebacks logged server-side; clients receive a safe message |
| CORS | Configurable allowlist, `*` only as the local-dev default |
| Secrets | None exist; `.env.example` contains no keys; `.env` git-ignored |
| PII minimisation | No name, phone, email or address is collected. Only a pseudonymous browser-generated session id, used solely for rate limiting and duplicate detection |
| Audit | Append-only log of every state change with actor |

**Safety boundary enforced in code:** citizen reports never trigger physical
action. The highest-authority output is a `recommended_action` string on a
ticket that a human must act on.

---

## 7. Scaling path

Current design is sized for a prototype but does not paint itself into a corner:

- **Candidate search** — bounding box + index today; PostGIS `ST_DWithin` next.
- **Embeddings** — cached per report; an ANN index (FAISS / pgvector) replaces
  the linear member scan when incidents grow large.
- **Write path** — serialised behind a lock for SQLite; PostgreSQL removes that
  constraint.
- **Correlation** — pure function of (report, candidates); horizontally
  scalable behind a queue with no change to the decision logic.
- **Utility integration** — `restoration.SOURCE_UTILITY` and the
  `utility_status` weight already exist, weighted **0** because no real feed is
  connected. Integrating one is a configuration change plus an adapter, not a
  redesign.

No benchmark numbers are quoted anywhere, because none have been measured.
