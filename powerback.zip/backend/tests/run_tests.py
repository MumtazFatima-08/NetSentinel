#!/usr/bin/env python3
"""
PowerBack test suite.

Runs with a hand-rolled harness rather than pytest, because pytest is not
guaranteed to be installed and the suite must run with a bare Python 3.10+
interpreter and no network access:

    python tests/run_tests.py

Each test gets a FRESH database, so tests cannot leak state into one another
and the suite is order-independent. The tests exercise the service layer --
the same code path the HTTP API and the UI use -- plus a live HTTP smoke test
against the real server.
"""
from __future__ import annotations

import os
import sys
import tempfile
import traceback
from datetime import timedelta

# Make the package importable regardless of where the suite is invoked from.
HERE = os.path.dirname(os.path.abspath(__file__))
BACKEND = os.path.dirname(HERE)
sys.path.insert(0, BACKEND)

_TMP = tempfile.mkdtemp(prefix="powerback-tests-")
os.environ.setdefault("PB_MEDIA_DIR", os.path.join(_TMP, "media"))

from powerback import (abuse, config, correlation, database, lifecycle,  # noqa: E402
                       priority, restoration, semantic, service, symptoms)
from powerback.util import to_iso, now  # noqa: E402

# ---------------------------------------------------------------------------
# Tiny harness
# ---------------------------------------------------------------------------
TESTS = []
PASSED, FAILED = [], []


def test(name):
    def deco(fn):
        TESTS.append((name, fn))
        return fn
    return deco


class Check:
    """Assertions that report the observed value, so a failure is diagnosable."""

    @staticmethod
    def true(cond, msg):
        if not cond:
            raise AssertionError(msg)

    @staticmethod
    def eq(actual, expected, msg=""):
        if actual != expected:
            raise AssertionError(f"{msg} | expected {expected!r}, got {actual!r}")

    @staticmethod
    def ne(actual, unexpected, msg=""):
        if actual == unexpected:
            raise AssertionError(f"{msg} | expected anything but {unexpected!r}")

    @staticmethod
    def gt(actual, threshold, msg=""):
        if not actual > threshold:
            raise AssertionError(f"{msg} | expected > {threshold}, got {actual}")

    @staticmethod
    def gte(actual, threshold, msg=""):
        if not actual >= threshold:
            raise AssertionError(f"{msg} | expected >= {threshold}, got {actual}")

    @staticmethod
    def lt(actual, threshold, msg=""):
        if not actual < threshold:
            raise AssertionError(f"{msg} | expected < {threshold}, got {actual}")

    @staticmethod
    def raises(exc_type, fn, msg=""):
        try:
            fn()
        except exc_type:
            return
        except Exception as other:
            raise AssertionError(
                f"{msg} | expected {exc_type.__name__}, got {type(other).__name__}: {other}")
        raise AssertionError(f"{msg} | expected {exc_type.__name__}, nothing was raised")


C = Check
_counter = [0]


def fresh_db():
    """A brand-new database file for one test."""
    _counter[0] += 1
    path = os.path.join(_TMP, f"t{_counter[0]}.db")
    if os.path.exists(path):
        os.remove(path)
    os.environ["PB_DB_PATH"] = path
    database.close()
    return database.reset_db(path)


BASE = now() - timedelta(minutes=30)
ORIGIN = (17.44970, 78.53920)


def at(minute):
    return to_iso(BASE + timedelta(minutes=minute))


def offset(dlat_m, dlon_m, base=ORIGIN):
    import math
    return (round(base[0] + dlat_m / 111_320.0, 6),
            round(base[1] + dlon_m / (111_320.0 * math.cos(math.radians(base[0]))), 6))


def submit(conn, desc, minute=0, coords=ORIGIN, session=None, **extra):
    lat, lon = (coords if coords else (None, None))
    payload = {
        "description": desc, "latitude": lat, "longitude": lon,
        "occurred_at": at(minute),
        "session_id": session or f"s-{_counter[0]}-{minute}-{abs(hash(desc)) % 9999}",
    }
    payload.update(extra)
    return service.submit_report(payload, conn=conn)


# ===========================================================================
# TEST 1 — same event correlates
# ===========================================================================
@test("1. Reports describing the same event are correlated into one incident")
def t1():
    conn = fresh_db()
    a = submit(conn, "Power has gone out on our street.", 0, offset(0, 0))
    b = submit(conn, "Several houses on this road have no electricity.", 2, offset(60, 40))
    c = submit(conn, "The street lights are also off.", 5, offset(-50, 90))

    C.eq(a["correlation"]["decision"], correlation.NEW, "first report seeds an incident")
    C.eq(b["correlation"]["decision"], correlation.MERGE, "second report should merge")
    C.eq(c["correlation"]["decision"], correlation.MERGE, "third report should merge")
    C.eq(b["incident"]["public_id"], a["incident"]["public_id"], "same incident")
    C.eq(c["incident"]["report_count"], 3, "incident should hold three reports")
    C.eq(len(service.list_incidents(conn=conn)), 1, "exactly one incident should exist")


# ===========================================================================
# TEST 2 — nearby but semantically different is NOT blindly merged
# ===========================================================================
@test("2. A nearby but semantically different report is not blindly merged")
def t2():
    conn = fresh_db()
    submit(conn, "Power has gone out on our street.", 0, offset(0, 0))
    submit(conn, "Several houses on this road have no electricity.", 2, offset(60, 40))

    # Same street, two minutes later, completely different subject.
    other = submit(conn, "There is a water leak on the main road near our house.",
                   4, offset(40, 60))
    C.ne(other["correlation"]["decision"], correlation.MERGE,
         "an unrelated complaint must not auto-merge into an outage")
    incidents = service.list_incidents(conn=conn)
    C.gte(len(incidents), 2, "the unrelated report should not be absorbed")

    # And the semantic signal is what separated them, not distance.
    sem = next(s for s in other["correlation"]["signals"] if s["name"] == "semantic")
    C.lt(sem["score"], config.SEMANTIC_MERGE_FLOOR,
         "semantic similarity should be below the merge floor")


# ===========================================================================
# TEST 3 — large time gap
# ===========================================================================
@test("3. Reports separated by a large time gap are not merged")
def t3():
    conn = fresh_db()
    first = submit(conn, "Power has gone out on our street.", 0, offset(0, 0))
    # Same words, same place, but far outside the candidate window.
    later = submit(conn, "Power has gone out on our street.",
                   config.CANDIDATE_WINDOW_MIN + 90, offset(0, 0))
    C.eq(later["correlation"]["decision"], correlation.NEW,
         "a report outside the temporal gate must start its own incident")
    C.ne(later["incident"]["public_id"], first["incident"]["public_id"],
         "should be a different incident")


# ===========================================================================
# TEST 4 — duplicates
# ===========================================================================
@test("4. Near-identical resubmissions are detected as duplicates")
def t4():
    conn = fresh_db()
    submit(conn, "Power has gone out on our street.", 0, offset(0, 0), session="dup-user")
    dup = submit(conn, "Power has gone out on our street.", 3, offset(5, 5), session="dup-user")

    C.true(dup["duplicate_of"] is not None, "the resubmission should be flagged as a duplicate")
    C.true(dup["incident"] is None, "a duplicate must not be correlated into an incident")
    inc = service.list_incidents(conn=conn)[0]
    C.eq(inc["report_count"], 1, "a duplicate must not inflate the report count")

    # A different person saying the same thing is NOT a duplicate.
    other = submit(conn, "Power has gone out on our street.", 4, offset(5, 5),
                   session="different-user")
    C.true(other["duplicate_of"] is None,
           "a different session reporting the same outage is a real second witness")


# ===========================================================================
# TEST 5 — missing photo
# ===========================================================================
@test("5. A missing photo does not break processing")
def t5():
    conn = fresh_db()
    out = submit(conn, "No electricity in our building at all.", 0, offset(0, 0))
    C.true(out["incident"] is not None, "report without a photo should still create an incident")
    C.eq(out["report"]["has_photo"], False, "no photo attached")
    ev = out["incident"]["evidence_summary"]
    C.eq(ev["photo_count"], 0, "photo count should be zero")
    C.eq(ev["vision"]["available"], False, "vision must honestly report unavailable")
    C.true(ev["vision"]["confidence"] is None,
           "no fabricated confidence value may be produced for images")


# ===========================================================================
# TEST 6 — missing location
# ===========================================================================
@test("6. A missing location is handled gracefully")
def t6():
    conn = fresh_db()
    out = submit(conn, "The whole street has no power since evening.", 0, coords=None)
    C.true(out["incident"] is not None, "a report without coordinates must still be accepted")
    C.true("NO_LOCATION" in out["report"]["flags"], "missing location should be flagged")

    # A second, located report should still correlate on meaning and time.
    out2 = submit(conn, "Several houses on this road have no electricity.", 3, offset(0, 0))
    C.true(out2["incident"] is not None, "processing must continue")

    # Half-specified coordinates are a data error and must be rejected.
    C.raises(service.ValidationError,
             lambda: service.submit_report(
                 {"description": "No power here", "latitude": 17.4, "occurred_at": at(1)},
                 conn=conn),
             "latitude without longitude must be rejected")


# ===========================================================================
# TEST 7 — short / noisy text
# ===========================================================================
@test("7. Short, noisy or unusual descriptions do not crash the engine")
def t7():
    conn = fresh_db()
    for text in ["no power", "???!!!", "aaaa aaaa aaaa aaaa", "⚡⚡⚡ no light ⚡⚡⚡",
                 "x" * 900, "POWER    OUT     NOW", "1234567890"]:
        out = submit(conn, text, 0, offset(0, 0))
        C.true(out is not None, f"engine must survive input: {text[:20]!r}")

    # Too short and too long are rejected cleanly, not with a stack trace.
    C.raises(service.ValidationError,
             lambda: service.submit_report({"description": "a"}, conn=conn),
             "a too-short description must be rejected")
    C.raises(service.ValidationError,
             lambda: service.submit_report({"description": "y" * 5000}, conn=conn),
             "an over-long description must be rejected")


# ===========================================================================
# TEST 8 — safety indicators drive priority
# ===========================================================================
@test("8. Safety indicators raise priority according to the defined rules")
def t8():
    conn = fresh_db()
    calm = submit(conn, "No electricity in our house since a few minutes.", 0, offset(0, 0))
    calm_priority = calm["incident"]["priority_score"]

    conn2 = fresh_db()
    hazard = submit(conn2, "Sparks and smoke coming from the transformer, very dangerous.",
                    0, offset(0, 0))
    hazard_priority = hazard["incident"]["priority_score"]

    C.gt(hazard_priority, calm_priority, "a hazard report must outrank a calm one")
    C.true(hazard["incident"]["hazard"], "hazard flag should be set")

    rules = [r["rule"] for r in hazard["incident"]["priority_reasons"]]
    C.true("safety_hazard" in rules, "the safety_hazard rule must appear in the reasons")

    # Every reason shown must correspond to a rule that actually fired.
    for r in hazard["incident"]["priority_reasons"]:
        C.true(r.get("points", 0) > 0, f"reason {r['rule']} must carry real points")
        C.true(bool(r.get("text")), "every reason needs human-readable text")


# ===========================================================================
# TEST 9 — incident creates a response ticket
# ===========================================================================
@test("9. An incident can generate a response brief and ticket")
def t9():
    conn = fresh_db()
    out = submit(conn, "Power has gone out on our street.", 0, offset(0, 0))
    inc_id = out["incident"]["public_id"]

    res = service.create_response(inc_id, conn=conn)
    ticket = res["ticket"]
    C.eq(res["created"], True, "a ticket should be created")
    C.eq(ticket["status"], lifecycle.AWAITING_DISPATCH, "new tickets await dispatch")
    C.eq(res["incident"]["status"], lifecycle.RESPONSE_CREATED, "incident advances in lockstep")
    C.true(inc_id in ticket["brief"], "the brief must reference the incident")
    C.true("Recommended Next Action" in ticket["brief"], "the brief must recommend an action")
    C.true("does not" in ticket["brief"] and "infrastructure" in ticket["brief"],
           "the brief must carry the no-control boundary statement")

    # Asking twice must not open a second competing ticket.
    again = service.create_response(inc_id, conn=conn)
    C.eq(again["created"], False, "a second open ticket must not be created")


# ===========================================================================
# TEST 10 — ticket progresses through valid states
# ===========================================================================
@test("10. A response ticket progresses through its valid states")
def t10():
    conn = fresh_db()
    out = submit(conn, "Power has gone out on our street.", 0, offset(0, 0))
    inc_id = out["incident"]["public_id"]
    ticket = service.create_response(inc_id, conn=conn)["ticket"]

    seq = [
        (lifecycle.TICKET_ASSIGNED, "Field Crew 7", lifecycle.ASSIGNED),
        (lifecycle.TICKET_FIELD_ACTION, None, lifecycle.FIELD_ACTION),
        (lifecycle.TICKET_RESTORATION_PENDING, None, lifecycle.RESTORATION_PENDING),
    ]
    for ticket_state, team, expected_incident_state in seq:
        res = service.update_ticket(ticket["public_id"], status=ticket_state,
                                    assigned_team=team, conn=conn)
        C.eq(res["ticket"]["status"], ticket_state, "ticket state should advance")
        C.eq(res["incident"]["status"], expected_incident_state,
             "incident state must track the ticket")

    # Assigning without a team is a workflow error.
    conn2 = fresh_db()
    o2 = submit(conn2, "Power has gone out on our street.", 0, offset(0, 0))
    t2_ = service.create_response(o2["incident"]["public_id"], conn=conn2)["ticket"]
    C.raises(service.ValidationError,
             lambda: service.update_ticket(t2_["public_id"],
                                           status=lifecycle.TICKET_ASSIGNED, conn=conn2),
             "moving to ASSIGNED without a team must be rejected")


# ===========================================================================
# TEST 11 — restoration updates
# ===========================================================================
@test("11. Restoration updates are recorded and raise confidence")
def t11():
    conn = fresh_db()
    out = submit(conn, "Power has gone out on our street.", 0, offset(0, 0))
    inc_id = out["incident"]["public_id"]
    service.create_response(inc_id, conn=conn)

    before = service.get_incident(inc_id, conn=conn)["restoration"]["confidence"]
    res = service.add_restoration_update(
        inc_id, restoration.SOURCE_CITIZEN, restoration.STATUS_RESTORED,
        "power is back", conn=conn)
    after = res["restoration"]["confidence"]
    C.gt(after, before, "a restoration signal must raise confidence")

    res2 = service.add_restoration_update(
        inc_id, restoration.SOURCE_TEAM, restoration.STATUS_RESTORED,
        "fuse replaced", conn=conn)
    C.gt(res2["restoration"]["confidence"], after,
         "a response-team confirmation must raise it further")

    # Signals are never presented as confirmed physical restoration.
    C.true("not a confirmation" in res2["restoration"]["disclaimer"],
           "the restoration disclaimer must be present")

    # Invalid sources and statuses are rejected.
    C.raises(ValueError,
             lambda: service.add_restoration_update(inc_id, "MAGIC", "RESTORED", conn=conn),
             "an unknown restoration source must be rejected")
    C.raises(ValueError,
             lambda: service.add_restoration_update(
                 inc_id, restoration.SOURCE_TEAM, "TOTALLY_FIXED", conn=conn),
             "an unknown restoration status must be rejected")


# ===========================================================================
# TEST 12 — verification closes the incident
# ===========================================================================
@test("12. Restoration verification can close an incident")
def t12():
    conn = fresh_db()
    out = submit(conn, "Power has gone out on our street.", 0, offset(0, 0))
    inc_id = out["incident"]["public_id"]
    service.create_response(inc_id, conn=conn)

    # Verifying with no evidence must be refused.
    C.raises(service.ValidationError,
             lambda: service.verify_restoration(inc_id, conn=conn),
             "verification without sufficient confidence must be refused")

    service.add_restoration_update(inc_id, restoration.SOURCE_TEAM,
                                   restoration.STATUS_RESTORED, conn=conn)
    service.add_restoration_update(inc_id, restoration.SOURCE_CITIZEN,
                                   restoration.STATUS_RESTORED, conn=conn)

    verified = service.verify_restoration(inc_id, conn=conn)
    C.eq(verified["incident"]["status"], lifecycle.VERIFICATION, "incident reaches VERIFICATION")
    C.gte(verified["restoration"]["confidence"], config.RESTORATION_VERIFY_MIN,
          "confidence must clear the verification threshold")

    closed = service.close_incident(inc_id, conn=conn)
    C.eq(closed["incident"]["status"], lifecycle.CLOSED, "incident should close")
    for t in closed["incident"]["tickets"]:
        C.eq(t["status"], lifecycle.TICKET_CLOSED, "open tickets close with the incident")


# ===========================================================================
# TEST 13 — invalid state transitions rejected
# ===========================================================================
@test("13. Invalid state transitions are rejected")
def t13():
    conn = fresh_db()
    out = submit(conn, "Power has gone out on our street.", 0, offset(0, 0))
    inc_id = out["incident"]["public_id"]
    ticket = service.create_response(inc_id, conn=conn)["ticket"]

    # Cannot skip backwards.
    service.update_ticket(ticket["public_id"], status=lifecycle.TICKET_ASSIGNED,
                          assigned_team="Crew 1", conn=conn)
    C.raises(lifecycle.TransitionError,
             lambda: service.update_ticket(ticket["public_id"],
                                           status=lifecycle.AWAITING_DISPATCH, conn=conn),
             "a ticket must not move backwards to AWAITING_DISPATCH")

    # Cannot invent a state.
    C.raises(lifecycle.TransitionError,
             lambda: service.update_ticket(ticket["public_id"], status="TELEPORTED", conn=conn),
             "an unknown state must be rejected")

    # A closed incident is terminal.
    C.raises(lifecycle.TransitionError,
             lambda: lifecycle.transition_incident(lifecycle.CLOSED, lifecycle.ASSIGNED),
             "CLOSED must be terminal")

    # The machine itself must be internally consistent.
    for state, targets in lifecycle.INCIDENT_TRANSITIONS.items():
        C.true(state in lifecycle.INCIDENT_STATES, f"{state} must be a declared state")
        for t in targets:
            C.true(t in lifecycle.INCIDENT_STATES, f"{state}->{t} targets an unknown state")


# ===========================================================================
# TEST 14 — invalid API payloads rejected cleanly
# ===========================================================================
@test("14. Invalid payloads are rejected cleanly with useful messages")
def t14():
    conn = fresh_db()
    bad_payloads = [
        ({}, "empty body"),
        ({"description": ""}, "blank description"),
        ({"description": "   "}, "whitespace description"),
        ({"description": "No power", "latitude": 999, "longitude": 10}, "latitude out of range"),
        ({"description": "No power", "latitude": 10, "longitude": 999}, "longitude out of range"),
        ({"description": "No power", "latitude": "abc", "longitude": "def"}, "non-numeric coords"),
    ]
    for payload, label in bad_payloads:
        try:
            service.submit_report(payload, conn=conn)
            raise AssertionError(f"{label} should have been rejected")
        except service.ValidationError as exc:
            C.true(len(str(exc)) > 10, f"{label}: error message must be informative")

    # A non-dict body must not explode.
    C.raises(service.ValidationError,
             lambda: service.submit_report("not a dict", conn=conn),
             "a non-object body must be rejected")

    # Unknown entities produce NotFound, not a crash.
    C.raises(service.NotFound, lambda: service.get_incident("INC-999", conn=conn),
             "unknown incident must raise NotFound")
    C.raises(service.NotFound, lambda: service.update_ticket("PB-999", status="ASSIGNED", conn=conn),
             "unknown ticket must raise NotFound")

    # A corrupt image payload is rejected as a validation error.
    C.raises(service.ValidationError,
             lambda: service.submit_report({
                 "description": "No power on our street at all",
                 "photo_base64": "data:image/png;base64,bm90YW5pbWFnZQ==",
             }, conn=conn),
             "a non-image upload must be rejected")


# ===========================================================================
# TEST 15 — full end-to-end lifecycle
# ===========================================================================
@test("15. End-to-end: report -> correlate -> incident -> priority -> response "
      "-> restoration -> verification -> closed")
def t15():
    conn = fresh_db()
    texts = [
        ("Power has gone out on our street.", 0, offset(0, 0)),
        ("Several houses on this road have no electricity.", 2, offset(60, 40)),
        ("The street lights are also off.", 5, offset(-50, 90)),
        ("Power is still not back.", 9, offset(120, -30)),
        ("The transformer area appears to be affected.", 15, offset(30, 150)),
    ]
    incident_id = None
    for text, minute, coords in texts:
        out = submit(conn, text, minute, coords)
        incident_id = out["incident"]["public_id"]

    inc = service.get_incident(incident_id, conn=conn)
    C.eq(inc["report_count"], 5, "all five reports should form one incident")
    C.eq(len(service.list_incidents(conn=conn)), 1, "exactly one incident")
    C.true(inc["priority"] in ("MEDIUM", "HIGH", "CRITICAL"),
           f"a five-report street outage should not be LOW (got {inc['priority']})")

    # Explainability must be backed by real computed values.
    explain = service.explain_incident(incident_id, conn=conn)
    C.gt(len(explain["factors"]), 0, "there must be explanation factors")
    for f in explain["factors"]:
        C.true(0.0 <= f["mean_score"] <= 1.0, "signal scores must be in range")
    C.true(any(f["signal"] == "semantic" for f in explain["factors"]),
           "semantic similarity must appear in the explanation")

    # Response
    ticket = service.create_response(incident_id, conn=conn)["ticket"]
    service.update_ticket(ticket["public_id"], status=lifecycle.TICKET_ASSIGNED,
                          assigned_team="Field Crew 7", conn=conn)
    service.update_ticket(ticket["public_id"], status=lifecycle.TICKET_FIELD_ACTION, conn=conn)

    # Restoration
    service.add_restoration_update(incident_id, restoration.SOURCE_TEAM,
                                   restoration.STATUS_RESTORED, "replaced fuse", conn=conn)
    # Three independent citizen confirmations reach full citizen weight. The
    # threshold is deliberately not trivial to clear -- closing an incident
    # that is still out is the worst failure this system could have.
    for who in ("power back", "our lights are on", "supply restored here"):
        service.add_restoration_update(incident_id, restoration.SOURCE_CITIZEN,
                                       restoration.STATUS_RESTORED, who, conn=conn)

    # Verify + close
    service.verify_restoration(incident_id, conn=conn)
    final = service.close_incident(incident_id, conn=conn)["incident"]
    C.eq(final["status"], lifecycle.CLOSED, "the incident must end CLOSED")

    # The audit trail must actually record the journey.
    actions = [t["action"] for t in final["timeline"]]
    for required in ("INCIDENT_CREATED", "RESPONSE_CREATED", "RESTORATION_UPDATE",
                     "RESTORATION_VERIFIED", "INCIDENT_CLOSED"):
        C.true(required in actions, f"audit trail must contain {required}")


# ===========================================================================
# EXTRA — properties that protect the product's claims
# ===========================================================================
@test("16. The three-way correlation outcome (merge / review / new) is reachable")
def t16():
    conn = fresh_db()
    submit(conn, "Power has gone out on our street.", 0, offset(0, 0))
    submit(conn, "Several houses on this road have no electricity.", 2, offset(60, 40))

    merged = submit(conn, "The street lights are also off.", 5, offset(-50, 90))
    review = submit(conn, "Sparks near the pole at the corner.", 8, offset(80, 110))
    separate = submit(conn, "There is a water leak on the main road.", 10, offset(40, 60))

    C.eq(merged["correlation"]["decision"], correlation.MERGE, "clear match should merge")
    C.eq(review["correlation"]["decision"], correlation.REVIEW,
         "an ambiguous hazard observation should go to human review")
    C.eq(separate["correlation"]["decision"], correlation.NEW,
         "an unrelated report should start its own incident")


@test("17. Human review can confirm or separate an uncertain report")
def t17():
    conn = fresh_db()
    submit(conn, "Power has gone out on our street.", 0, offset(0, 0))
    submit(conn, "Several houses on this road have no electricity.", 2, offset(60, 40))
    submit(conn, "Sparks near the pole at the corner.", 8, offset(80, 110))

    reviews = service.list_reviews(conn=conn)
    C.eq(len(reviews), 1, "there should be one pending review")
    before = service.get_incident(reviews[0]["incident_id"], conn=conn)["report_count"]

    confirmed = service.resolve_review(reviews[0]["link_id"], "CONFIRM", conn=conn)
    C.eq(confirmed["incident"]["report_count"], before + 1,
         "confirming must add the report to the incident")
    C.eq(len(service.list_reviews(conn=conn)), 0, "the review queue should be empty")

    # And rejection must split the report into its own incident.
    conn = fresh_db()
    submit(conn, "Power has gone out on our street.", 0, offset(0, 0))
    submit(conn, "Several houses on this road have no electricity.", 2, offset(60, 40))
    submit(conn, "Sparks near the pole at the corner.", 8, offset(80, 110))
    rv = service.list_reviews(conn=conn)[0]

    # An unknown action must be refused BEFORE the link is consumed.
    C.raises(service.ValidationError,
             lambda: service.resolve_review(rv["link_id"], "MAYBE", conn=conn),
             "an unknown review action must be rejected")

    rejected = service.resolve_review(rv["link_id"], "REJECT", conn=conn)
    C.true(rejected["new_incident"] is not None, "rejection must create a separate incident")
    C.eq(rejected["new_incident"]["report_count"], 1, "the separated report stands alone")

    # Resolving the same link twice must not succeed silently.
    C.raises((service.ValidationError, service.NotFound),
             lambda: service.resolve_review(rv["link_id"], "CONFIRM", conn=conn),
             "an already-resolved review must not be resolvable again")


@test("18. A pending-review report does not silently affect the incident")
def t18():
    conn = fresh_db()
    submit(conn, "Power has gone out on our street.", 0, offset(0, 0))
    submit(conn, "Several houses on this road have no electricity.", 2, offset(60, 40))
    before = service.get_incident("INC-001", conn=conn)

    submit(conn, "Sparks near the pole at the corner.", 8, offset(80, 110))
    after = service.get_incident("INC-001", conn=conn)

    C.eq(after["report_count"], before["report_count"],
         "an unconfirmed report must not raise the report count")
    C.eq(after["hazard"], False,
         "an unconfirmed hazard must not flip the incident's hazard flag")
    C.true(after["needs_review"], "the incident should be marked as needing review")


@test("19. Rate limiting protects the public reporting endpoint")
def t19():
    conn = fresh_db()
    session = "flooder"
    for i in range(config.RATE_LIMIT_MAX_REPORTS):
        submit(conn, f"No power in sector {i} of our area right now", i, offset(i * 5, 0),
               session=session)
    C.raises(abuse.RateLimitExceeded,
             lambda: submit(conn, "No power anywhere here at all", 99, offset(0, 0),
                            session=session),
             "exceeding the rate limit must be blocked")

    # A different session is unaffected.
    ok = submit(conn, "No electricity in our building here", 5, offset(0, 0), session="normal")
    C.true(ok is not None, "an unrelated session must not be rate limited")


@test("20. No fabricated AI outputs are emitted anywhere")
def t20():
    conn = fresh_db()
    out = submit(conn, "Power has gone out on our street.", 0, offset(0, 0))

    # Vision must report unavailable, with no invented confidence.
    vision = out["incident"]["evidence_summary"]["vision"]
    C.eq(vision["available"], False, "vision must report unavailable in this build")
    C.true(vision["confidence"] is None, "vision must not emit a confidence value")

    # The system report must not overclaim.
    sys_info = service.system_info()
    C.eq(sys_info["utility_integration"]["connected"], False,
         "the prototype must not claim a utility connection")
    C.eq(sys_info["vision"]["vision_enabled"], False,
         "the prototype must not claim image classification")
    C.eq(sys_info["restoration"]["utility_telemetry_connected"], False,
         "the prototype must not claim utility telemetry")

    # Semantic similarity must be genuinely computed, not stubbed.
    a = semantic.encode_one("Power has gone out on our street.")
    b = semantic.encode_one("Several houses on this road have no electricity.")
    c = semantic.encode_one("There is a water leak on the main road.")
    sim_same = semantic.cosine(a, b)
    sim_diff = semantic.cosine(a, c)
    C.gt(sim_same, sim_diff,
         "related outage text must score higher than unrelated text")
    C.eq(semantic.cosine(a, a), 1.0, "a vector must be identical to itself")

    # The declared semantic method must match the backend actually in use.
    desc = semantic.describe()
    C.eq(desc["is_neural"], desc["backend"].startswith("sentence-transformers"),
         "the reported model type must match the live backend")


@test("21. Correlation confidence and priority are independent concepts")
def t21():
    conn = fresh_db()
    # One lone hazard report: maximum urgency, but nothing to correlate with.
    out = submit(conn, "Sparks and smoke coming from the transformer, very dangerous.",
                 0, offset(0, 0))
    inc = out["incident"]
    C.true(inc["priority"] in ("HIGH", "CRITICAL"),
           "a hazard must be urgent even as a single report")
    C.eq(inc["report_count"], 1, "it is still only one report")
    # Urgency must not masquerade as grouping certainty, and vice versa.
    C.true(inc["correlation_confidence"] <= 1.0, "confidence stays in range")
    C.ne(inc["priority_score"], inc["correlation_confidence"],
         "priority score and correlation confidence must not be the same number")


@test("22. Geospatial and temporal maths behave correctly")
def t22():
    from powerback.geo import haversine_m, centroid, affected_radius_m, spatial_score

    # Known reference: 1 degree of latitude is ~111.3 km.
    d = haversine_m(0.0, 0.0, 1.0, 0.0)
    C.true(110_000 < d < 112_000, f"1 degree latitude should be ~111 km, got {d:.0f} m")
    C.eq(round(haversine_m(17.4, 78.5, 17.4, 78.5), 3), 0.0, "distance to self is zero")

    c = centroid([(0.0, 0.0), (0.0, 2.0)])
    C.true(abs(c[1] - 1.0) < 0.001, "centroid should sit between the points")

    C.gte(affected_radius_m([(17.4, 78.5)]), 1.0, "a single point still yields a floor radius")
    C.eq(spatial_score(0, 350), 1.0, "zero distance is a perfect spatial score")
    C.lt(spatial_score(2000, 350), 0.01, "distant points score near zero")


@test("23. Concept extraction does not produce false positives")
def t23():
    # Substring matching would wrongly fire on these; boundary matching must not.
    signals = symptoms.extract_signals("The shocking news about the power of habit")
    C.eq(signals["has_hazard"], False,
         "'shocking' must not be read as an electric shock hazard")

    real = symptoms.extract_signals("I got an electric shock near the pole")
    C.eq(real["has_hazard"], True, "a genuine hazard phrase must be detected")

    nonelec = symptoms.extract_signals("There is a water leak on the main road")
    C.eq(nonelec["is_non_electrical"], True, "a water leak is not an electrical issue")
    C.eq(nonelec["indicates_outage"], False, "a water leak is not an outage")


@test("24. A clean-state demo seed is reproducible across runs")
def t24():
    from powerback import seed as seed_mod

    runs = []
    for _ in range(2):
        fresh_db()
        result = seed_mod.seed(reset=True)
        runs.append({
            "incidents": len(result["incidents"]),
            "decisions": [r["decision"] for group in result["results"].values() for r in group],
        })
    C.eq(runs[0], runs[1], "seeding twice from a clean state must give the same result")
    C.gte(runs[0]["incidents"], 2, "the demo must produce more than one incident")
    C.true("DUPLICATE" in runs[0]["decisions"], "the demo must demonstrate duplicate detection")
    C.true("REVIEW" in runs[0]["decisions"], "the demo must demonstrate human review")
    C.true("MERGE" in runs[0]["decisions"], "the demo must demonstrate correlation")
    C.true("NEW" in runs[0]["decisions"], "the demo must demonstrate separation")


@test("25. HTTP API smoke test against a live server")
def t25():
    import json
    import threading
    import urllib.error
    import urllib.request
    from powerback import server as server_mod

    fresh_db()
    os.environ["PB_QUIET"] = "1"
    httpd = server_mod.create_server("127.0.0.1", 0)
    port = httpd.server_address[1]
    thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    thread.start()
    base = f"http://127.0.0.1:{port}"

    def call(path, method="GET", body=None):
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(
            base + path, data=data, method=method,
            headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=20) as resp:
                return resp.status, json.loads(resp.read().decode())
        except urllib.error.HTTPError as exc:
            return exc.code, json.loads(exc.read().decode())

    try:
        status, health = call("/api/health")
        C.eq(status, 200, "health endpoint must respond")
        C.eq(health["status"], "ok", "health must report ok")

        status, _ = call("/api/demo/seed", "POST", {"reset": True})
        C.eq(status, 200, "seeding over HTTP must work")

        status, incidents = call("/api/incidents")
        C.eq(status, 200, "incident list must respond")
        C.gte(len(incidents["incidents"]), 2, "seeded incidents must be listed")

        ref = incidents["incidents"][0]["public_id"]
        status, detail = call(f"/api/incidents/{ref}")
        C.eq(status, 200, "incident detail must respond")
        C.true("reports" in detail, "detail must include reports")

        status, explain = call(f"/api/incidents/{ref}/explain")
        C.eq(status, 200, "explain endpoint must respond")
        C.true("factors" in explain, "explain must return factors")

        # Errors map to the right status codes.
        status, err = call("/api/reports", "POST", {"description": ""})
        C.eq(status, 400, "invalid input must return 400")
        C.true("error" in err, "errors must carry a message")

        status, _ = call("/api/incidents/INC-404")
        C.eq(status, 404, "unknown incident must return 404")

        status, _ = call("/api/nope")
        C.eq(status, 404, "unknown route must return 404")

        # A real submission over HTTP.
        status, created = call("/api/reports", "POST", {
            "description": "No power in our whole lane here right now",
            "latitude": ORIGIN[0], "longitude": ORIGIN[1],
            "session_id": "http-smoke",
        })
        C.eq(status, 200, "a valid report must be accepted")
        C.true(created["incident"] is not None, "a report must yield an incident")

        # Invalid transition maps to 409.
        inc_ref = created["incident"]["public_id"]
        status, resp = call(f"/api/incidents/{inc_ref}/response", "POST", {})
        C.eq(status, 200, "opening a ticket must work")
        tick = resp["ticket"]["public_id"]
        status, _ = call(f"/api/response-tickets/{tick}", "PATCH", {"status": "VERIFIED"})
        C.eq(status, 409, "an invalid transition must return 409")

        # Static frontend is served.
        with urllib.request.urlopen(base + "/", timeout=20) as r:
            C.eq(r.status, 200, "the frontend index must be served")
            C.true(b"PowerBack" in r.read(), "index.html must render the product name")

        # Path traversal must be refused.
        try:
            with urllib.request.urlopen(base + "/media/../powerback/config.py", timeout=20) as r:
                body = r.read()
                C.true(b"THRESHOLD_MERGE" not in body,
                       "path traversal must not expose source files")
        except urllib.error.HTTPError as exc:
            C.true(exc.code in (403, 404), "traversal attempt must be refused")
    finally:
        httpd.shutdown()
        httpd.server_close()


# ===========================================================================
# RUNNER
# ===========================================================================
def main():
    print("=" * 74)
    print("  PowerBack test suite")
    print("=" * 74)
    print(f"  Semantic backend : {semantic.describe()['backend']}")
    print(f"  Temp workspace   : {_TMP}")
    print("-" * 74)

    for name, fn in TESTS:
        try:
            fn()
            PASSED.append(name)
            print(f"  PASS  {name}")
        except Exception as exc:
            FAILED.append((name, exc, traceback.format_exc()))
            print(f"  FAIL  {name}")
            print(f"        {type(exc).__name__}: {exc}")

    print("-" * 74)
    print(f"  {len(PASSED)} passed, {len(FAILED)} failed, {len(TESTS)} total")
    print("=" * 74)

    if FAILED:
        print("\nFAILURE DETAIL\n" + "=" * 74)
        for name, exc, tb in FAILED:
            print(f"\n--- {name} ---")
            print(tb)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
