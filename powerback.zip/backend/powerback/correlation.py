"""
PowerBack correlation engine.

Answers exactly one question:

    "Does this new report describe the same physical incident as an existing
     one -- and how confident are we?"

It deliberately does NOT answer "which transformer failed". Correlating citizen
observations is not the same as identifying a physical grid component, and the
product never conflates the two.

PIPELINE
--------
  1. CANDIDATE SELECTION  -- hard spatial + temporal gates, index-assisted.
                             Bounds the expensive step and prevents absurd
                             cross-city correlations.
  2. SIGNAL SCORING       -- semantic, spatial, temporal, evidence.
                             Each in [0, 1], each independently explainable.
  3. COMBINATION          -- weighted mean over the signals that are ACTUALLY
                             available, with weights renormalised.
  4. DECISION             -- MERGE / REVIEW / NEW, with a semantic floor that
                             blocks automatic merges of physically adjacent but
                             semantically different events.

Every threshold and weight comes from config.py. There are no magic numbers in
this file.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional, Sequence

from . import config, semantic
from .geo import bounding_box, haversine_m, spatial_score
from .lexicon import concept_label
from .util import parse_time, minutes_between

# Decision outcomes
MERGE = "MERGE"
REVIEW = "REVIEW"
NEW = "NEW"


@dataclass
class SignalScore:
    """One explainable signal contributing to a correlation decision."""
    name: str
    score: float
    weight: float
    available: bool
    detail: str = ""
    evidence: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "score": round(self.score, 4),
            "weight": round(self.weight, 4),
            "available": self.available,
            "detail": self.detail,
            "evidence": self.evidence,
        }


@dataclass
class CorrelationResult:
    decision: str
    confidence: float
    incident_id: Optional[int]
    incident_public_id: Optional[str]
    signals: List[SignalScore] = field(default_factory=list)
    reasons: List[str] = field(default_factory=list)
    blocked_by: Optional[str] = None
    considered: List[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "decision": self.decision,
            "confidence": round(self.confidence, 4),
            "incident_id": self.incident_id,
            "incident_public_id": self.incident_public_id,
            "signals": [s.to_dict() for s in self.signals],
            "reasons": self.reasons,
            "blocked_by": self.blocked_by,
            "considered": self.considered,
            "thresholds": {
                "merge": config.THRESHOLD_MERGE,
                "review": config.THRESHOLD_REVIEW,
                "semantic_floor": config.SEMANTIC_MERGE_FLOOR,
            },
        }


# ---------------------------------------------------------------------------
# 1. CANDIDATE SELECTION
# ---------------------------------------------------------------------------
def select_candidates(conn, latitude, longitude, occurred_at) -> List[dict]:
    """
    Fetch incidents that could plausibly match, using both hard gates.

    The spatial pre-filter uses an indexed lat/lon bounding-box range query so
    this does not degrade into a full table scan as the incident table grows;
    exact haversine is then applied to the small candidate set. Reports with no
    location skip the spatial gate and rely on the temporal gate alone.
    """
    when = parse_time(occurred_at)
    params: List[Any] = []
    clauses = ["status NOT IN (%s)" % ",".join("?" * len(config.CANDIDATE_EXCLUDED_STATES))]
    params.extend(config.CANDIDATE_EXCLUDED_STATES)

    has_location = latitude is not None and longitude is not None
    if has_location:
        min_lat, max_lat, min_lon, max_lon = bounding_box(
            latitude, longitude, config.CANDIDATE_RADIUS_M)
        clauses.append(
            "(centroid_latitude IS NULL OR "
            "(centroid_latitude BETWEEN ? AND ? AND centroid_longitude BETWEEN ? AND ?))")
        params.extend([min_lat, max_lat, min_lon, max_lon])

    sql = f"SELECT * FROM incidents WHERE {' AND '.join(clauses)} ORDER BY last_seen DESC LIMIT 200"
    rows = [dict(r) for r in conn.execute(sql, params).fetchall()]

    candidates: List[dict] = []
    for row in rows:
        # Temporal gate: measured against the incident's most recent activity.
        gap = minutes_between(when, parse_time(row["last_seen"]))
        if gap > config.CANDIDATE_WINDOW_MIN:
            continue
        # Exact spatial gate.
        if has_location and row["centroid_latitude"] is not None:
            dist = haversine_m(latitude, longitude,
                               row["centroid_latitude"], row["centroid_longitude"])
            # Allow the incident's own affected radius on top of the gate, so a
            # large already-established outage can still absorb an edge report.
            if dist > config.CANDIDATE_RADIUS_M + (row["affected_radius_m"] or 0.0):
                continue
            row["_distance_m"] = dist
        else:
            row["_distance_m"] = None
        row["_minutes_apart"] = gap
        candidates.append(row)
    return candidates


# ---------------------------------------------------------------------------
# 2. SIGNAL SCORING
# ---------------------------------------------------------------------------
def _semantic_signal(conn, report_text, report_vec, incident_id) -> SignalScore:
    """
    Max cosine similarity between the new report and the incident's member
    reports. Max (not mean) because an incident legitimately accumulates
    different facets of one event -- matching any one strongly is evidence of
    belonging, and averaging would dilute that as the incident grows.

    Embeddings are read from cache; they are computed once at report intake.
    """
    rows = conn.execute(
        "SELECT r.id, r.description, r.embedding FROM reports r "
        "JOIN incident_reports ir ON ir.report_id = r.id "
        # Only CONFIRMED members are used for comparison. Letting a report that
        # is itself awaiting human review pull further reports into the incident
        # would let one uncertain decision cascade into many.
        "WHERE ir.incident_id = ? AND ir.link_type = 'MERGED' "
        "ORDER BY r.occurred_at DESC LIMIT 25",
        (incident_id,)).fetchall()
    if not rows:
        return SignalScore("semantic", 0.0, config.WEIGHTS["semantic"], False,
                           "No member reports to compare against.")

    best = 0.0
    best_text = ""
    for row in rows:
        vec = semantic.blob_to_vector(row["embedding"])
        if vec is None:
            vec = semantic.encode_one(row["description"])
        score = semantic.cosine(report_vec, vec)
        if score > best:
            best, best_text = score, row["description"]

    shared = semantic.shared_concepts(report_text, best_text) if best_text else []
    shared_labels = [concept_label(c) for c in shared if c != "NON_ELECTRICAL"]
    detail = (f"Closest existing report scored {best:.2f} cosine similarity."
              + (f" Shared themes: {', '.join(shared_labels)}." if shared_labels else ""))
    return SignalScore(
        "semantic", best, config.WEIGHTS["semantic"], True, detail,
        {"closest_report": best_text[:200], "shared_concepts": shared,
         "shared_concept_labels": shared_labels},
    )


def _spatial_signal(distance_m: Optional[float]) -> SignalScore:
    if distance_m is None:
        return SignalScore("spatial", 0.0, config.WEIGHTS["spatial"], False,
                           "No location on the report or the incident.")
    score = spatial_score(distance_m, config.SPATIAL_DECAY_M)
    return SignalScore(
        "spatial", score, config.WEIGHTS["spatial"], True,
        f"{distance_m:.0f} m from the incident centroid.",
        {"distance_m": round(distance_m, 1), "decay_m": config.SPATIAL_DECAY_M},
    )


def _temporal_signal(minutes_apart: Optional[float]) -> SignalScore:
    if minutes_apart is None:
        return SignalScore("temporal", 0.0, config.WEIGHTS["temporal"], False,
                           "No usable timestamp.")
    import math
    score = float(math.exp(-max(0.0, minutes_apart) / config.TEMPORAL_DECAY_MIN))
    return SignalScore(
        "temporal", score, config.WEIGHTS["temporal"], True,
        f"{minutes_apart:.0f} min from the most recent report in this incident.",
        {"minutes_apart": round(minutes_apart, 1),
         "decay_minutes": config.TEMPORAL_DECAY_MIN},
    )


def _evidence_signal(report_signals: dict, incident_row: dict) -> SignalScore:
    """
    Agreement between the structured signals extracted from the report and the
    incident's accumulated evidence.

    IMPORTANT -- NO FABRICATED COMPUTER VISION.
    This signal is computed from TEXT-derived concepts and from whether a photo
    is attached. PowerBack does not run an image classifier and therefore never
    emits an image-derived confidence number. A photo raises the evidence value
    of a report (a human can inspect it) but is never converted into a
    machine-made claim about what the photo contains. See evidence.py.
    """
    from .database import jload

    report_concepts = set(report_signals.get("concepts") or [])
    incident_concepts = set(jload(incident_row.get("evidence_summary"), {})
                            .get("concepts", []))
    if not report_concepts or not incident_concepts:
        return SignalScore("evidence", 0.0, config.WEIGHTS["evidence"], False,
                           "Not enough structured evidence to compare.")

    overlap = report_concepts & incident_concepts
    union = report_concepts | incident_concepts
    score = len(overlap) / len(union) if union else 0.0
    labels = [concept_label(c) for c in sorted(overlap)]
    return SignalScore(
        "evidence", score, config.WEIGHTS["evidence"], True,
        (f"Shares {len(overlap)} of {len(union)} observed evidence categories."
         + (f" Common: {', '.join(labels)}." if labels else "")),
        {"shared": sorted(overlap), "shared_labels": labels,
         "report_concepts": sorted(report_concepts),
         "incident_concepts": sorted(incident_concepts)},
    )


# ---------------------------------------------------------------------------
# 3 + 4. COMBINATION AND DECISION
# ---------------------------------------------------------------------------
def combine(signals: Sequence[SignalScore]) -> float:
    """
    Weighted mean over AVAILABLE signals only.

    A missing signal is excluded and the remaining weights are renormalised, so
    an absent photo or a missing GPS fix never silently counts as a zero score
    and drags a valid correlation below threshold.
    """
    usable = [s for s in signals if s.available and s.weight > 0]
    total_weight = sum(s.weight for s in usable)
    if total_weight <= 0:
        return 0.0
    return float(sum(s.score * s.weight for s in usable) / total_weight)


def score_against_incident(conn, report: dict, report_vec, incident_row: dict) -> dict:
    """Score one (report, incident) pair across all four signals."""
    signals = [
        _semantic_signal(conn, report["description"], report_vec, incident_row["id"]),
        _spatial_signal(incident_row.get("_distance_m")),
        _temporal_signal(incident_row.get("_minutes_apart")),
        _evidence_signal(report.get("extracted_signals") or {}, incident_row),
    ]
    confidence = combine(signals)
    return {
        "incident_id": incident_row["id"],
        "incident_public_id": incident_row["public_id"],
        "confidence": confidence,
        "signals": signals,
    }


def decide(conn, report: dict, report_vec) -> CorrelationResult:
    """
    Run the full correlation decision for one incoming report.

    Returns MERGE, REVIEW or NEW -- never a silent auto-merge of everything
    nearby. Supporting uncertainty explicitly is a product requirement, not an
    implementation detail: a wrong merge hides a real second outage.
    """
    candidates = select_candidates(
        conn, report.get("latitude"), report.get("longitude"), report["occurred_at"])

    if not candidates:
        return CorrelationResult(
            NEW, 0.0, None, None, [],
            ["No existing incident fell within the spatial and temporal search window."],
        )

    scored = [score_against_incident(conn, report, report_vec, c) for c in candidates]
    scored.sort(key=lambda s: s["confidence"], reverse=True)
    best = scored[0]

    considered = [{
        "incident_public_id": s["incident_public_id"],
        "confidence": round(s["confidence"], 4),
        "signals": {x.name: round(x.score, 4) for x in s["signals"] if x.available},
    } for s in scored[:5]]

    confidence = best["confidence"]
    signals = best["signals"]
    sem = next((s for s in signals if s.name == "semantic"), None)
    reasons: List[str] = []
    blocked_by = None

    # --- Decision ---------------------------------------------------------
    if confidence >= config.THRESHOLD_MERGE:
        # SAFETY GATE: strong proximity in space and time is NOT sufficient.
        # Two genuinely different events can happen on the same street minutes
        # apart. Require a minimum semantic agreement before auto-merging.
        if sem is not None and sem.available and sem.score < config.SEMANTIC_MERGE_FLOOR:
            decision = REVIEW
            blocked_by = "semantic_floor"
            reasons.append(
                f"Location and timing matched strongly (combined {confidence:.2f}), "
                f"but the descriptions only agreed at {sem.score:.2f}, below the "
                f"{config.SEMANTIC_MERGE_FLOOR:.2f} floor required for an automatic merge. "
                "Sent for human review instead of merging.")
        else:
            decision = MERGE
            reasons.append(
                f"Combined correlation confidence {confidence:.2f} met the "
                f"{config.THRESHOLD_MERGE:.2f} merge threshold.")
    elif confidence >= config.THRESHOLD_REVIEW:
        decision = REVIEW
        reasons.append(
            f"Combined correlation confidence {confidence:.2f} fell between the "
            f"review ({config.THRESHOLD_REVIEW:.2f}) and merge "
            f"({config.THRESHOLD_MERGE:.2f}) thresholds, so a human decides.")
    else:
        decision = NEW
        reasons.append(
            f"Best existing incident scored only {confidence:.2f}, below the "
            f"{config.THRESHOLD_REVIEW:.2f} review threshold. Treated as a separate incident.")

    for s in signals:
        if s.available:
            reasons.append(f"{s.name.capitalize()}: {s.detail}")

    return CorrelationResult(
        decision=decision,
        confidence=confidence,
        incident_id=best["incident_id"] if decision != NEW else None,
        incident_public_id=best["incident_public_id"] if decision != NEW else None,
        signals=signals,
        reasons=reasons,
        blocked_by=blocked_by,
        considered=considered,
    )
