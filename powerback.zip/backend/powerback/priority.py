"""
Priority engine.

This is a TRANSPARENT RULE SYSTEM and we call it that in the product. It is not
a machine-learning model, and labelling it "AI" would be dishonest.

That is a deliberate engineering choice, not a shortcut. Response prioritisation
decides who gets electricity restored first; it must be auditable, appealable
and adjustable by an operator. A learned score trained on synthetic hackathon
data would be less accurate AND less defensible than explicit rules.

Every reason string emitted here is generated from a rule that ACTUALLY fired,
with the real triggering value attached -- so the UI can never show a
justification that did not happen.

Correlation confidence and priority are kept strictly separate:
  correlation = "are these the same incident?"
  priority    = "how urgently should it be investigated?"
A hazard makes an incident urgent; it does not make the grouping more certain.
"""
from __future__ import annotations

from typing import Any, Dict, List

from . import config
from .util import minutes_between, parse_time


def _band(score: float) -> str:
    for name, floor in config.PRIORITY_BANDS:
        if score >= floor:
            return name
    return "LOW"


def evaluate(incident: Dict[str, Any], reports: List[Dict[str, Any]]) -> dict:
    """
    Score an incident's response priority from its actual reports.

    Returns {priority, score, reasons[], factors{}} where each reason names the
    rule, the observed value and the points contributed.
    """
    rules = config.PRIORITY_RULES
    score = 0.0
    reasons: List[dict] = []
    factors: Dict[str, Any] = {}

    signals = [r.get("extracted_signals") or {} for r in reports]
    n = len(reports)

    # --- Rule 1: safety hazard (dominant) --------------------------------
    hazard_terms: List[str] = []
    for s in signals:
        hazard_terms.extend(s.get("hazard_terms") or [])
    hazard_terms = sorted(set(hazard_terms))
    factors["hazard"] = bool(hazard_terms)
    factors["hazard_terms"] = hazard_terms
    if hazard_terms:
        score += rules["hazard_points"]
        reasons.append({
            "rule": "safety_hazard",
            "points": rules["hazard_points"],
            "text": f"Safety hazard reported by citizens ({', '.join(hazard_terms[:3])}).",
            "value": hazard_terms[:3],
        })

    # --- Rule 2: scale, capped so a big cluster cannot outrank a hazard ---
    report_points = min(n * rules["points_per_report"], rules["report_points_cap"])
    factors["report_count"] = n
    if report_points > 0:
        score += report_points
        reasons.append({
            "rule": "affected_reports",
            "points": round(report_points, 1),
            "text": f"{n} correlated report{'s' if n != 1 else ''} from the affected area.",
            "value": n,
        })

    # --- Rule 3: rapid growth = spreading event ---------------------------
    growth = 0.0
    if n >= 2:
        times = sorted(parse_time(r["occurred_at"]) for r in reports)
        span_min = minutes_between(times[0], times[-1])
        growth = (n / span_min * 10.0) if span_min > 0 else float(n)
        factors["reports_per_10min"] = round(growth, 2)
        factors["span_minutes"] = round(span_min, 1)
        if growth >= rules["growth_reports_per_10min"]:
            score += rules["growth_points"]
            reasons.append({
                "rule": "rapid_growth",
                "points": rules["growth_points"],
                "text": (f"Reports arriving rapidly ({growth:.1f} per 10 min), "
                         "indicating a spreading or escalating event."),
                "value": round(growth, 2),
            })

    # --- Rule 4: area-wide impact ----------------------------------------
    # One household losing supply may be a local fault; a whole street losing
    # supply is a distribution problem. Reporters say which it is, so we use it.
    area_wide = any("AREA_WIDE" in (s.get("concepts") or []) for s in signals)
    factors["area_wide"] = area_wide
    if area_wide:
        score += rules["area_wide_points"]
        reasons.append({
            "rule": "area_wide_impact",
            "points": rules["area_wide_points"],
            "text": "Reports describe multiple premises affected, not a single household.",
            "value": True,
        })

    # --- Rule 5: sustained outage ----------------------------------------
    if n >= 1:
        times = sorted(parse_time(r["occurred_at"]) for r in reports)
        duration = minutes_between(times[0], parse_time(incident.get("last_seen")))
        factors["duration_minutes"] = round(duration, 1)
        if duration >= rules["duration_minutes_threshold"]:
            score += rules["duration_points"]
            reasons.append({
                "rule": "sustained_duration",
                "points": rules["duration_points"],
                "text": f"Outage ongoing for approximately {duration:.0f} minutes.",
                "value": round(duration, 1),
            })

    # --- Rule 6: critical premises ---------------------------------------
    infra_terms: List[str] = []
    for s in signals:
        infra_terms.extend(s.get("critical_infra_terms") or [])
    infra_terms = sorted(set(infra_terms))
    factors["critical_infrastructure"] = infra_terms
    if infra_terms:
        score += rules["critical_infra_points"]
        reasons.append({
            "rule": "critical_infrastructure",
            "points": rules["critical_infra_points"],
            "text": f"Critical premises reported affected ({', '.join(infra_terms[:3])}).",
            "value": infra_terms[:3],
        })

    # --- Rule 7: photo evidence awaiting human review --------------------
    photos = sum(1 for r in reports if r.get("photo_path"))
    factors["photo_count"] = photos
    if photos:
        score += rules["evidence_points"]
        reasons.append({
            "rule": "photo_evidence",
            "points": rules["evidence_points"],
            "text": f"{photos} photo{'s' if photos != 1 else ''} attached for field review.",
            "value": photos,
        })

    priority = _band(score)
    return {
        "priority": priority,
        "score": round(score, 2),
        "reasons": reasons,
        "factors": factors,
        "bands": {name: floor for name, floor in config.PRIORITY_BANDS},
    }


def recommended_action(priority: str, factors: Dict[str, Any]) -> str:
    """
    A RECOMMENDATION for a human responder. PowerBack issues no commands to
    physical infrastructure and never claims to have identified the faulty
    component -- only what a crew should go and check.
    """
    if factors.get("hazard"):
        return ("Dispatch urgent field inspection: make the location safe before "
                "restoration work. Public safety hazard reported at the site.")
    if priority == "CRITICAL":
        return ("Dispatch field inspection immediately and notify the distribution "
                "operator; critical premises are affected.")
    if priority == "HIGH":
        return ("Dispatch field inspection to the affected distribution area to "
                "identify the cause of supply loss.")
    if priority == "MEDIUM":
        return ("Schedule a field check for the affected area and monitor for "
                "further reports.")
    return ("Monitor. Await further citizen reports before dispatching a crew.")
