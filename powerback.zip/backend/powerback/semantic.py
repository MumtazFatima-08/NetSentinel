"""
Semantic similarity for outage report text.

READ THIS BEFORE JUDGING THE "AI" CLAIM
=======================================

PowerBack computes semantic similarity with a real vector space model and real
cosine similarity. It does not put an "AI" label on a keyword match. But we are
equally careful not to overstate what is running: this build uses a
*lexicon-grounded distributional* model, not a neural language model, and the
product reports that fact at `GET /api/system`.

Two backends sit behind one interface:

  1. SentenceTransformerBackend ("all-MiniLM-L6-v2")
     Dense contextual neural embeddings. Selected automatically whenever the
     `sentence-transformers` package and its weights are importable.

  2. ConceptLexicalBackend   <-- ACTIVE DEFAULT IN THIS BUILD
     A concatenation of
       (a) a DOMAIN CONCEPT vector from lexicon.py, and
       (b) a lexical TF-IDF vector (word 1-2gram + char_wb 3-5gram, sklearn),
     each L2-normalised, weighted, concatenated, then L2-normalised again.
     Compared with cosine similarity.

Why (a) exists -- this is an empirical finding, not a preference:

We first implemented pure TF-IDF. It failed. Measured on the demo scenario,
two reports describing the SAME outage scored 0.03 cosine similarity, while an
outage report and an unrelated garbage-collection complaint scored 0.33, purely
because both contained the word "street". Short citizen reports describe one
physical event with almost no shared vocabulary ("power has gone out" vs "no
electricity" vs "everything went dark"), so a bag-of-words model is structurally
unable to correlate them.

Grounding text in concepts fixes the discrimination problem and, just as
importantly, makes the similarity *explainable*: the UI can say "both reports
describe loss of supply affecting multiple premises" instead of showing an
opaque number.

Component (b) is retained at a lower weight so wording the ontology has never
seen still contributes, and so two reports are not treated as identical merely
because they trip the same concept.

All vectors are L2-normalised, so cosine similarity is a dot product and
vectors are cacheable in the database and directly comparable across restarts.
"""
from __future__ import annotations

import threading
from typing import List, Optional, Sequence

import numpy as np

from . import config
from .lexicon import CONCEPTS, FACTORS, factor_vector
from .symptoms import match_concepts, normalize_text

# Precomputed concept -> latent factor coordinates (built once at import).
_FACTOR_MATRIX = {name: factor_vector(name) for name in CONCEPTS}

# ---------------------------------------------------------------------------
# Corpus used to fit the lexical component. A FIXED corpus keeps the vector
# space stable across process restarts so cached vectors stay valid.
# ---------------------------------------------------------------------------
DOMAIN_CORPUS: Sequence[str] = (
    "power has gone out on our street",
    "there is no electricity in my house",
    "no power in the whole area since evening",
    "several houses on this road have no electricity",
    "the entire lane is affected by the outage",
    "power cut in our neighbourhood",
    "electricity failure across the block",
    "we have no current at home",
    "the street lights are also off",
    "streetlights on the main road are not working",
    "lamp posts are dark tonight",
    "power is still not back after two hours",
    "electricity has not been restored yet",
    "still no power since morning",
    "the transformer area appears to be affected",
    "there is a loud noise from the transformer",
    "the transformer is making a humming sound",
    "sparks are coming from the electric pole",
    "i can see sparking near the junction box",
    "there is smoke coming from the distribution box",
    "a wire has fallen on the road",
    "the cable is hanging low and looks dangerous",
    "burning smell near the feeder box",
    "flames near the electricity pole",
    "a live wire is lying on the street",
    "someone got an electric shock near the pole",
    "voltage is very low in our house",
    "lights are flickering continuously",
    "power keeps fluctuating every few minutes",
    "only one phase is working at home",
    "half of the house has no power",
    "the hospital nearby has no electricity",
    "the school building is without power",
    "the water pumping station has no supply",
    "traffic signal is not working due to power failure",
    "power supply resumed a few minutes ago",
    "electricity is back in our house now",
    "supply has been restored in the area",
    "the lights came back on",
    "everything is working normally again",
    "the outage started around six in the evening",
    "we lost power suddenly without warning",
    "there was a loud bang and then everything went dark",
    "the meter box is sparking",
    "the substation seems to have tripped",
    "our building generator is running because there is no supply",
    "power went off during the storm",
    "heavy rain and then the electricity stopped",
    "a tree branch fell on the power line",
    "the pole is leaning dangerously",
    "no water supply in our building today",
    "the road has a large pothole",
    "garbage has not been collected on our street",
    "there is a water leak on the main road",
    "the drainage is blocked near my house",
    "internet connection is not working",
    "phone network signal is very weak here",
    "a street dog is causing problems in the lane",
    "the park lights are switched off at night",
    "construction noise is disturbing the neighbourhood",
)


class SemanticBackend:
    name = "base"
    dim = 0

    def encode(self, texts: Sequence[str]) -> np.ndarray:
        raise NotImplementedError

    def describe(self) -> dict:
        return {"backend": self.name, "dim": self.dim}


def _l2(mat: np.ndarray) -> np.ndarray:
    norms = np.linalg.norm(mat, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return mat / norms


class ConceptLexicalBackend(SemanticBackend):
    """Domain concept vector + lexical TF-IDF vector, concatenated."""

    name = "concept+tfidf"

    def __init__(self, corpus: Sequence[str] = DOMAIN_CORPUS):
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.pipeline import FeatureUnion

        docs = [normalize_text(c) for c in corpus]
        self._vec = FeatureUnion([
            ("word", TfidfVectorizer(analyzer="word", ngram_range=(1, 2),
                                     sublinear_tf=True, min_df=1)),
            ("char", TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5),
                                     sublinear_tf=True, min_df=1)),
        ])
        self._vec.fit(docs)
        self._lex_dim = int(self._vec.transform([docs[0]]).shape[1])
        self._concept_dim = len(FACTORS)
        self.dim = self._concept_dim + self._lex_dim
        self._alpha = float(config.SEMANTIC_ALPHA_CONCEPT)
        self._beta = float(config.SEMANTIC_BETA_LEXICAL)

    def _concept_matrix(self, texts: Sequence[str]) -> np.ndarray:
        """
        Project matched concepts into the LATENT FACTOR space (lexicon.FACTORS)
        rather than onto one orthogonal axis per concept.

        This is what lets "the street lights are off" and "power has gone out"
        score as related: both load heavily on `outage_core`, even though they
        share no concept and no vocabulary.
        """
        out = np.zeros((len(texts), self._concept_dim), dtype=np.float32)
        for row, text in enumerate(texts):
            for concept, hits in match_concepts(text).items():
                weight = float(CONCEPTS[concept]["weight"])
                # Saturating count: more distinct matched phrases strengthen the
                # concept, but a single strong phrase already carries it.
                strength = weight * (1.0 + 0.25 * min(len(hits) - 1, 3))
                out[row] += np.asarray(
                    _FACTOR_MATRIX[concept], dtype=np.float32) * strength
        return _l2(out)

    def encode(self, texts: Sequence[str]) -> np.ndarray:
        docs = [normalize_text(t) for t in texts]
        concept = self._concept_matrix(docs) * self._alpha
        lex = np.asarray(self._vec.transform(docs).todense(), dtype=np.float32)
        lex = _l2(lex) * self._beta
        return _l2(np.hstack([concept, lex]).astype(np.float32))

    def describe(self) -> dict:
        return {
            "backend": self.name,
            "dim": self.dim,
            "concept_dim": self._concept_dim,
            "lexical_dim": self._lex_dim,
            "alpha_concept": self._alpha,
            "beta_lexical": self._beta,
        }


class SentenceTransformerBackend(SemanticBackend):
    """Dense neural embeddings. Used when the package and weights are present."""

    name = "sentence-transformers"

    def __init__(self, model_name: str = config.SEMANTIC_MODEL_NAME):
        from sentence_transformers import SentenceTransformer

        self._model = SentenceTransformer(model_name)
        self.name = f"sentence-transformers:{model_name}"
        self.dim = int(self._model.get_sentence_embedding_dimension())

    def encode(self, texts: Sequence[str]) -> np.ndarray:
        vecs = self._model.encode(
            [normalize_text(t) for t in texts],
            convert_to_numpy=True,
            normalize_embeddings=True,
            show_progress_bar=False,
        )
        return np.asarray(vecs, dtype=np.float32)


_backend: Optional[SemanticBackend] = None
_backend_lock = threading.Lock()
_backend_error: Optional[str] = None


def get_backend() -> SemanticBackend:
    """Lazily build the best available backend once. Thread-safe."""
    global _backend, _backend_error
    if _backend is not None:
        return _backend
    with _backend_lock:
        if _backend is not None:
            return _backend
        pref = (config.SEMANTIC_BACKEND or "auto").lower()
        if pref in ("auto", "sentence-transformers"):
            try:
                _backend = SentenceTransformerBackend()
                return _backend
            except Exception as exc:  # environment dependent, not a bug
                _backend_error = f"sentence-transformers unavailable ({exc})"
        _backend = ConceptLexicalBackend()
        return _backend


def reset_backend() -> None:
    """Test hook: force the backend to be rebuilt."""
    global _backend
    with _backend_lock:
        _backend = None


def encode(texts: Sequence[str]) -> np.ndarray:
    return get_backend().encode(list(texts))


def encode_one(text: str) -> np.ndarray:
    return encode([text])[0]


def cosine(a, b) -> float:
    """Cosine similarity clipped to [0, 1]. Negative similarity is not a
    meaningful correlation signal here, so it floors at 0."""
    if a is None or b is None:
        return 0.0
    a = np.asarray(a, dtype=np.float32).ravel()
    b = np.asarray(b, dtype=np.float32).ravel()
    if a.size == 0 or b.size == 0 or a.size != b.size:
        return 0.0
    na = float(np.linalg.norm(a))
    nb = float(np.linalg.norm(b))
    if na == 0.0 or nb == 0.0:
        return 0.0
    return float(max(0.0, min(1.0, float(np.dot(a, b)) / (na * nb))))


def shared_concepts(text_a: str, text_b: str) -> List[str]:
    """Concepts present in BOTH texts -- drives the human-readable explanation."""
    a = set(match_concepts(text_a).keys())
    b = set(match_concepts(text_b).keys())
    return sorted(a & b)


def vector_to_blob(vec) -> bytes:
    return np.asarray(vec, dtype=np.float32).tobytes()


def blob_to_vector(blob: Optional[bytes]):
    if not blob:
        return None
    return np.frombuffer(blob, dtype=np.float32)


def describe() -> dict:
    b = get_backend()
    info = b.describe()
    is_neural = b.name.startswith("sentence-transformers")
    info["is_neural"] = is_neural
    info["fallback_reason"] = _backend_error
    info["method"] = (
        "Dense contextual neural sentence embeddings; cosine similarity."
        if is_neural else
        "Lexicon-grounded concept vector concatenated with lexical TF-IDF "
        "(word 1-2gram + char_wb 3-5gram); cosine similarity. "
        "Vector-space model, not a neural language model."
    )
    return info
