"""Shared small utilities: time parsing, ids, safe numbers."""
from __future__ import annotations

import secrets
from datetime import datetime, timezone
from typing import Optional, Union

ISO = "%Y-%m-%dT%H:%M:%S"


def now() -> datetime:
    return datetime.now(timezone.utc).replace(microsecond=0)


def to_iso(dt: Optional[datetime] = None) -> str:
    d = dt or now()
    if d.tzinfo is None:
        d = d.replace(tzinfo=timezone.utc)
    return d.astimezone(timezone.utc).replace(microsecond=0).isoformat()


def parse_time(value: Union[str, datetime, None]) -> datetime:
    """
    Tolerant ISO-8601 parser. Always returns a timezone-aware UTC datetime.

    Citizen clients send a variety of shapes ("...Z", naive local, with or
    without microseconds), and a report must never be rejected because of a
    timestamp formatting quirk. Unparseable input falls back to 'now' rather
    than raising, because losing an outage report is worse than an imprecise
    timestamp -- the fallback is recorded in the report's flags upstream.
    """
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    if not value:
        return now()
    text = str(value).strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(text)
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except ValueError:
        pass
    for fmt in (ISO, "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(text, fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    return now()


def minutes_between(a: datetime, b: datetime) -> float:
    """Absolute gap in minutes between two datetimes."""
    a = a if a.tzinfo else a.replace(tzinfo=timezone.utc)
    b = b if b.tzinfo else b.replace(tzinfo=timezone.utc)
    return abs((a - b).total_seconds()) / 60.0


def new_id(prefix: str, n: int) -> str:
    return f"{prefix}-{n:03d}"


def token(nbytes: int = 8) -> str:
    return secrets.token_hex(nbytes)


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, float(value)))


def safe_float(value, default=None) -> Optional[float]:
    if value is None or value == "":
        return default
    try:
        f = float(value)
    except (TypeError, ValueError):
        return default
    if f != f or f in (float("inf"), float("-inf")):  # NaN / inf
        return default
    return f
