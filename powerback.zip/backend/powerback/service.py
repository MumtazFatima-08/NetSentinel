"""
PowerBack service layer.

This module contains the ENTIRE application workflow and is deliberately
framework-agnostic: it imports no web framework and knows nothing about HTTP.
Two transports (a zero-dependency stdlib server and a FastAPI adapter) call
into it, and the test suite drives it directly. That is what makes the demo
reproducible -- the tests exercise the same code path the UI does.

Lifecycle implemented here:

    REPORT -> CORRELATE -> UNDERSTAND -> PRIORITIZE
           -> RESPOND -> RESTORE -> VERIFY -> CLOSE
"""
from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

from . import (abuse, audit, config, correlation, evidence, lifecycle,
               priority as priority_mod, restoration as restoration_mod,
               semantic, symptoms)
from .database import connect, jdump, jload
from .geo import affected_radius_m, centroid, haversine_m
from .lexicon import concept_label
from .util import (clamp, minutes_between, now, parse_time, safe_float, to_iso,
                   token)

MEDIA_DIR = os.environ.get(
    "PB_MEDIA_DIR", os.path.join(os.path.dirname(os.path.dirname(__file__)), "media"))


class ValidationError(ValueError):
    """Raised for invalid client input. Maps to HTTP 400."""

    def __init__(self, message: str, field: Optional[str] = None):
        self.field = field
        super().__init__(message)


class NotFound(LookupError):
    """Raised when an entity does not exist. Maps to HTTP 404."""


# ===========================================================================
# VALIDATION
# ===========================================================================
def _validate_report_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(payload, dict):
        raise ValidationError("Request body must be a JSON object.")

    description = payload.get("description")
    if description is None or not str(description).strip():
        raise ValidationError("A description of what you observed is required.",
                              "description")
    description = str(description).strip()
    if len(description) < config.DESCRIPTION_MIN_LEN:
        raise ValidationError(
            f"Description must be at least {config.DESCRIPTION_MIN_LEN} characters.",
            "description")
    if len(description) > config.DESCRIPTION_MAX_LEN:
        raise ValidationError(
            f"Description must be {config.DESCRIPTION_MAX_LEN} characters or fewer.",
            "description")

    raw_lat, raw_lon = payload.get("latitude"), payload.get("longitude")
    lat = safe_float(raw_lat)
    lon = safe_float(raw_lon)
    # A coordinate that was SUPPLIED but does not parse is a client error, not
    # an absent location. Silently discarding it would place the report in the
    # wrong part of the pipeline without telling anyone.
    for raw, parsed, field in ((raw_lat, lat, "latitude"), (raw_lon, lon, "longitude")):
        if raw not in (None, "") and parsed is None:
            raise ValidationError(
                f"'{raw}' is not a valid {field}. Provide a decimal number, "
                "or omit the location entirely.", field)
    # Location is optional, but if one coordinate is given both must be, and
    # both must be in range -- a half-specified position is a data error.
    if (lat is None) != (lon is None):
        raise ValidationError(
            "Both latitude and longitude are required when providing a location.",
            "latitude" if lat is None else "longitude")
    if lat is not None:
        if not (config.LAT_RANGE[0] <= lat <= config.LAT_RANGE[1]):
            raise ValidationError(
                f"Latitude must be between {config.LAT_RANGE[0]} and {config.LAT_RANGE[1]}.",
                "latitude")
        if not (config.LON_RANGE[0] <= lon <= config.LON_RANGE[1]):
            raise ValidationError(
                f"Longitude must be between {config.LON_RANGE[0]} and {config.LON_RANGE[1]}.",
                "longitude")

    session_id = payload.get("session_id")
    session_id = str(session_id)[:64] if session_id else None

    return {
        "description": description,
        "latitude": lat,
        "longitude": lon,
        "occurred_at": to_iso(parse_time(payload.get("occurred_at"))),
        "session_id": session_id,
        "photo_base64": payload.get("photo_base64"),
        "photo_mime": payload.get("photo_mime"),
    }


# ===========================================================================
# REPORT INTAKE  (REPORT -> CORRELATE -> UNDERSTAND -> PRIORITIZE)
# ===========================================================================
def submit_report(payload: Dict[str, Any], conn=None) -> Dict[str, Any]:
    """
    Full intake pipeline for one citizen report.

    Returns a processing trace mirroring the stages the UI animates, so the
    frontend displays what genuinely happened rather than a scripted animation.
    """
    conn = conn or connect()
    data = _validate_report_payload(payload)
    trace: List[Dict[str, Any]] = []

    # --- Stage 0: abuse controls -------------------------------------
    abuse.check_rate_limit(conn, data["session_id"])

    # --- Stage 1: understand the text (rule-based extraction) ----------
    signals = symptoms.extract_signals(data["description"])
    trace.append({
        "stage": "EXTRACT",
        "label": "Report received",
        "ok": True,
        "detail": (f"Recognised {len(signals['concepts'])} outage concept(s)."
                   if signals["concepts"] else
                   "No known outage concept recognised in the text."),
        "data": {"concepts": signals["concepts"],
                 "matched_terms": signals["matched_terms"]},
    })

    # --- Stage 2: embed (semantic vector) --------------------------------
    vector = semantic.encode_one(data["description"])
    trace.append({
        "stage": "EMBED",
        "label": "Semantic encoding",
        "ok": True,
        "detail": f"Encoded with {semantic.get_backend().name} ({len(vector)} dims).",
        "data": {"backend": semantic.get_backend().name, "dims": int(len(vector))},
    })

    # --- Stage 3: duplicate detection ------------------------------------
    duplicate = abuse.find_duplicate(conn, data, vector)
    flags = abuse.suspicion_flags(conn, data, signals)

    # --- Stage 4: photo evidence -----------------------------------------
    photo_meta: Dict[str, Any] = {}
    if data.get("photo_base64"):
        try:
            photo_meta = evidence.validate_and_store(
                data["photo_base64"], MEDIA_DIR, data.get("photo_mime"))
        except evidence.EvidenceError as exc:
            raise ValidationError(str(exc), "photo_base64") from exc

    status = abuse.DUPLICATE if duplicate else abuse.ACCEPTED
    if duplicate:
        flags = sorted(set(flags + ["DUPLICATE_SUBMISSION"]))

    # --- Persist the report (always, even when duplicate/flagged) --------
    public_id = f"R-{token(4)}"
    cur = conn.execute(
        "INSERT INTO reports (public_id, description, latitude, longitude, "
        "occurred_at, created_at, session_id, photo_path, photo_mime, photo_bytes, "
        "extracted_signals, embedding, status, flags) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (public_id, data["description"], data["latitude"], data["longitude"],
         data["occurred_at"], to_iso(), data["session_id"],
         photo_meta.get("photo_path"), photo_meta.get("photo_mime"),
         photo_meta.get("photo_bytes"), jdump(signals),
         semantic.vector_to_blob(vector), status, jdump(flags)))
    report_id = cur.lastrowid
    conn.commit()

    report = {
        "id": report_id, "public_id": public_id, **data,
        "extracted_signals": signals, "photo_path": photo_meta.get("photo_path"),
    }
    audit.log(conn, "report", report_id, "REPORT_RECEIVED",
              {"status": status, "flags": flags}, actor="citizen")

    if duplicate:
        trace.append({
            "stage": "DUPLICATE", "label": "Duplicate detected", "ok": False,
            "detail": (f"Near-identical to report {duplicate['public_id']} "
                       f"(similarity {duplicate['similarity']:.2f}). Stored but not correlated."),
            "data": duplicate,
        })
        conn.commit()
        return {
            "report": _report_public(report, flags, status),
            "duplicate_of": duplicate,
            "correlation": None,
            "incident": None,
            "trace": trace,
            "message": "This looks like a repeat of a report you already sent.",
        }

    trace.append({
        "stage": "DEDUPE", "label": "Duplicate check", "ok": True,
        "detail": "No near-identical recent report from this session.", "data": {},
    })

    # --- Stage 5: correlation -------------------------------------------
    result = correlation.decide(conn, report, vector)
    available = {s.name: round(s.score, 3) for s in result.signals if s.available}
    trace.append({
        "stage": "CORRELATE", "label": "Correlation engine", "ok": True,
        "detail": (f"Decision {result.decision} at confidence {result.confidence:.2f}."
                   if result.decision != correlation.NEW else
                   "No existing incident matched; creating a new one."),
        "data": {"decision": result.decision,
                 "confidence": round(result.confidence, 4),
                 "signals": available,
                 "blocked_by": result.blocked_by},
    })

    # --- Stage 6: attach or create --------------------------------------
    if result.decision == correlation.MERGE and result.incident_id:
        incident_id = result.incident_id
        _link_report(conn, incident_id, report_id, result.confidence,
                     result.to_dict(), "MERGED")
        audit.log(conn, "incident", incident_id, "REPORT_MERGED",
                  {"report": public_id, "confidence": round(result.confidence, 4)})
    elif result.decision == correlation.REVIEW and result.incident_id:
        incident_id = result.incident_id
        _link_report(conn, incident_id, report_id, result.confidence,
                     result.to_dict(), "PENDING_REVIEW")
        conn.execute("UPDATE incidents SET needs_review = 1, updated_at = ? WHERE id = ?",
                     (to_iso(), incident_id))
        audit.log(conn, "incident", incident_id, "REPORT_FLAGGED_FOR_REVIEW",
                  {"report": public_id, "confidence": round(result.confidence, 4),
                   "blocked_by": result.blocked_by})
    else:
        incident_id = _create_incident(conn, report, result.confidence)
        _link_report(conn, incident_id, report_id, 1.0,
                     {"decision": "SEED", "reasons": ["First report of this incident."]},
                     "MERGED")
        audit.log(conn, "incident", incident_id, "INCIDENT_CREATED",
                  {"seed_report": public_id})

    # --- Stage 7: recompute derived state + priority ---------------------
    recompute_incident(conn, incident_id)
    conn.commit()

    incident = get_incident(incident_id, conn=conn)
    trace.append({
        "stage": "PRIORITIZE", "label": "Priority assessment", "ok": True,
        "detail": (f"{incident['priority']} priority "
                   f"(score {incident['priority_score']})."),
        "data": {"priority": incident["priority"],
                 "score": incident["priority_score"],
                 "reasons": [r["text"] for r in incident["priority_reasons"]]},
    })

    return {
        "report": _report_public(report, flags, status),
        "duplicate_of": None,
        "correlation": result.to_dict(),
        "incident": incident,
        "trace": trace,
        "message": {
            correlation.MERGE: "Your report was correlated with an existing incident.",
            correlation.REVIEW: "Your report was linked for human review.",
            correlation.NEW: "A new incident was created from your report.",
        }[result.decision],
    }


def _report_public(report: dict, flags: List[str], status: str) -> dict:
    return {
        "id": report["id"],
        "public_id": report["public_id"],
        "description": report["description"],
        "latitude": report.get("latitude"),
        "longitude": report.get("longitude"),
        "occurred_at": report["occurred_at"],
        "has_photo": bool(report.get("photo_path")),
        "photo_path": report.get("photo_path"),
        "signals": report.get("extracted_signals", {}),
        "flags": flags,
        "status": status,
        "trustworthy": abuse.is_trustworthy(flags),
    }


def _link_report(conn, incident_id: int, report_id: int, score: float,
                 reasons: dict, link_type: str) -> None:
    conn.execute(
        "INSERT OR IGNORE INTO incident_reports "
        "(incident_id, report_id, match_score, match_reasons, link_type, created_at) "
        "VALUES (?,?,?,?,?,?)",
        (incident_id, report_id, clamp(score), jdump(reasons), link_type, to_iso()))


def _create_incident(conn, report: dict, confidence: float) -> int:
    seq = conn.execute("SELECT COUNT(*) AS c FROM incidents").fetchone()["c"] + 1
    public_id = f"INC-{seq:03d}"
    ts = report["occurred_at"]
    cur = conn.execute(
        "INSERT INTO incidents (public_id, status, priority, priority_score, "
        "priority_reasons, correlation_confidence, centroid_latitude, centroid_longitude, "
        "affected_radius_m, first_seen, last_seen, report_count, evidence_summary, "
        "symptoms, hazard_flag, recommended_action, restoration_confidence, "
        "needs_review, created_at, updated_at) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (public_id, lifecycle.INCIDENT_DETECTED, None, 0.0, jdump([]),
         clamp(confidence), report.get("latitude"), report.get("longitude"),
         0.0, ts, ts, 0, jdump({}), jdump([]), 0, None, 0.0, 0, to_iso(), to_iso()))
    return cur.lastrowid


# ===========================================================================
# DERIVED STATE
# ===========================================================================
def recompute_incident(conn, incident_id: int) -> None:
    """
    Recompute everything derived from an incident's member reports:
    centroid, affected radius, time bounds, evidence, symptoms and priority.

    Called after every change so the incident is never stale. Reports linked as
    PENDING_REVIEW are EXCLUDED from geometry and priority -- an unconfirmed
    report must not silently move an incident's centroid or escalate it.
    """
    incident = conn.execute("SELECT * FROM incidents WHERE id = ?",
                            (incident_id,)).fetchone()
    if incident is None:
        raise NotFound(f"Incident {incident_id} does not exist.")
    incident = dict(incident)

    rows = conn.execute(
        "SELECT r.*, ir.link_type, ir.match_score FROM reports r "
        "JOIN incident_reports ir ON ir.report_id = r.id "
        "WHERE ir.incident_id = ? ORDER BY r.occurred_at ASC",
        (incident_id,)).fetchall()
    members = [dict(r) for r in rows]
    for m in members:
        m["extracted_signals"] = jload(m["extracted_signals"], {})
        m["flags"] = jload(m["flags"], [])

    confirmed = [m for m in members if m["link_type"] == "MERGED"]
    # Flagged reports stay visible but must not drive escalation.
    scoring_set = [m for m in confirmed if abuse.is_trustworthy(m["flags"])] or confirmed

    points = [(m["latitude"], m["longitude"]) for m in confirmed
              if m["latitude"] is not None and m["longitude"] is not None]
    center = centroid(points) if points else None
    radius = affected_radius_m(points, center) if points else 0.0

    times = [parse_time(m["occurred_at"]) for m in confirmed] or [parse_time(incident["first_seen"])]
    first_seen = to_iso(min(times))
    last_seen = to_iso(max(times))

    concepts: List[str] = []
    for m in confirmed:
        concepts.extend(m["extracted_signals"].get("concepts") or [])
    concept_counts: Dict[str, int] = {}
    for c in concepts:
        concept_counts[c] = concept_counts.get(c, 0) + 1

    photos = [m for m in confirmed if m["photo_path"]]
    hazard = any(m["extracted_signals"].get("has_hazard") for m in scoring_set)

    evidence_summary = {
        "concepts": sorted(concept_counts.keys()),
        "concept_counts": concept_counts,
        "concept_labels": [concept_label(c) for c in sorted(concept_counts.keys())],
        "photo_count": len(photos),
        "report_count": len(confirmed),
        "pending_review_count": sum(1 for m in members if m["link_type"] == "PENDING_REVIEW"),
        "vision": evidence.analyze(photos[0]["photo_path"] if photos else None),
    }
    symptom_list = symptoms.symptom_summary([m["description"] for m in confirmed])

    # Correlation confidence = mean of confirmed member match scores (the seed
    # report scores 1.0). This is the grouping's strength, NOT its urgency.
    scores = [m["match_score"] for m in confirmed if m["match_score"] is not None]
    corr_conf = sum(scores) / len(scores) if scores else 0.0

    incident_for_priority = {**incident, "last_seen": last_seen}
    assessment = priority_mod.evaluate(incident_for_priority, scoring_set)
    action = priority_mod.recommended_action(assessment["priority"], assessment["factors"])

    # Advance NEW_SIGNALS/INCIDENT_DETECTED to PRIORITIZED once scored, but
    # never regress an incident that is already in the response workflow.
    status = incident["status"]
    if status in (lifecycle.NEW_SIGNALS, lifecycle.INCIDENT_DETECTED, lifecycle.VALIDATING):
        if lifecycle.can_transition_incident(status, lifecycle.PRIORITIZED):
            status = lifecycle.PRIORITIZED

    conn.execute(
        "UPDATE incidents SET status=?, priority=?, priority_score=?, priority_reasons=?, "
        "correlation_confidence=?, centroid_latitude=?, centroid_longitude=?, "
        "affected_radius_m=?, first_seen=?, last_seen=?, report_count=?, "
        "evidence_summary=?, symptoms=?, hazard_flag=?, recommended_action=?, "
        "updated_at=? WHERE id=?",
        (status, assessment["priority"], assessment["score"], jdump(assessment["reasons"]),
         clamp(corr_conf), center[0] if center else None, center[1] if center else None,
         radius, first_seen, last_seen, len(confirmed), jdump(evidence_summary),
         jdump(symptom_list), 1 if hazard else 0, action, to_iso(), incident_id))


# ===========================================================================
# READ APIs
# ===========================================================================
def _incident_row_public(row: dict) -> dict:
    return {
        "id": row["id"],
        "public_id": row["public_id"],
        "status": row["status"],
        "priority": row["priority"],
        "priority_score": row["priority_score"],
        "priority_reasons": jload(row["priority_reasons"], []),
        "correlation_confidence": round(row["correlation_confidence"] or 0.0, 4),
        "centroid": ({"latitude": row["centroid_latitude"],
                      "longitude": row["centroid_longitude"]}
                     if row["centroid_latitude"] is not None else None),
        "affected_radius_m": row["affected_radius_m"],
        "first_seen": row["first_seen"],
        "last_seen": row["last_seen"],
        "report_count": row["report_count"],
        "evidence_summary": jload(row["evidence_summary"], {}),
        "symptoms": jload(row["symptoms"], []),
        "hazard": bool(row["hazard_flag"]),
        "recommended_action": row["recommended_action"],
        "restoration_confidence": row["restoration_confidence"],
        "needs_review": bool(row["needs_review"]),
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }


def list_incidents(conn=None, status: Optional[str] = None,
                   limit: int = 100) -> List[dict]:
    conn = conn or connect()
    if status:
        rows = conn.execute(
            "SELECT * FROM incidents WHERE status = ? ORDER BY "
            "CASE priority WHEN 'CRITICAL' THEN 0 WHEN 'HIGH' THEN 1 "
            "WHEN 'MEDIUM' THEN 2 ELSE 3 END, last_seen DESC LIMIT ?",
            (status, limit)).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM incidents ORDER BY "
            "CASE WHEN status = 'CLOSED' THEN 1 ELSE 0 END, "
            "CASE priority WHEN 'CRITICAL' THEN 0 WHEN 'HIGH' THEN 1 "
            "WHEN 'MEDIUM' THEN 2 ELSE 3 END, last_seen DESC LIMIT ?",
            (limit,)).fetchall()
    return [_incident_row_public(dict(r)) for r in rows]


def _resolve_incident(conn, incident_ref) -> dict:
    """Look up an incident by numeric id or public id (INC-001)."""
    row = None
    if isinstance(incident_ref, int) or str(incident_ref).isdigit():
        row = conn.execute("SELECT * FROM incidents WHERE id = ?",
                           (int(incident_ref),)).fetchone()
    if row is None:
        row = conn.execute("SELECT * FROM incidents WHERE public_id = ?",
                           (str(incident_ref),)).fetchone()
    if row is None:
        raise NotFound(f"Incident '{incident_ref}' was not found.")
    return dict(row)


def get_incident(incident_ref, conn=None) -> dict:
    """Full incident detail: the hero screen's payload."""
    conn = conn or connect()
    row = _resolve_incident(conn, incident_ref)
    out = _incident_row_public(row)

    rows = conn.execute(
        "SELECT r.*, ir.link_type, ir.match_score, ir.match_reasons, ir.id AS link_id "
        "FROM reports r JOIN incident_reports ir ON ir.report_id = r.id "
        "WHERE ir.incident_id = ? ORDER BY r.occurred_at ASC", (row["id"],)).fetchall()
    out["reports"] = [{
        "link_id": r["link_id"],
        "id": r["id"],
        "public_id": r["public_id"],
        "description": r["description"],
        "latitude": r["latitude"],
        "longitude": r["longitude"],
        "occurred_at": r["occurred_at"],
        "link_type": r["link_type"],
        "match_score": round(r["match_score"] or 0.0, 4),
        "match_reasons": jload(r["match_reasons"], {}),
        "signals": jload(r["extracted_signals"], {}),
        "flags": jload(r["flags"], []),
        "has_photo": bool(r["photo_path"]),
        "photo_path": r["photo_path"],
    } for r in rows]

    tickets = conn.execute(
        "SELECT * FROM response_tickets WHERE incident_id = ? ORDER BY id DESC",
        (row["id"],)).fetchall()
    out["tickets"] = [_ticket_public(dict(t)) for t in tickets]

    updates = conn.execute(
        "SELECT * FROM restoration_updates WHERE incident_id = ? ORDER BY id ASC",
        (row["id"],)).fetchall()
    out["restoration_updates"] = [{
        "source": u["source"], "status": u["status"], "note": u["note"],
        "created_at": u["created_at"],
    } for u in updates]

    out["restoration"] = restoration_mod.compute_confidence(conn, row)
    out["timeline"] = audit.for_entity(conn, "incident", row["id"])
    out["allowed_transitions"] = lifecycle.allowed_incident_next(row["status"])
    return out


def explain_incident(incident_ref, conn=None) -> dict:
    """
    "Why did PowerBack group these reports?"

    Built entirely from stored per-link signal values, so the explanation shows
    what the engine actually computed -- never a reconstructed or illustrative
    number.
    """
    conn = conn or connect()
    row = _resolve_incident(conn, incident_ref)
    links = conn.execute(
        "SELECT r.public_id, r.description, r.occurred_at, ir.match_score, "
        "ir.match_reasons, ir.link_type FROM reports r "
        "JOIN incident_reports ir ON ir.report_id = r.id "
        "WHERE ir.incident_id = ? ORDER BY r.occurred_at ASC", (row["id"],)).fetchall()

    per_report, agg = [], {}
    for link in links:
        reasons = jload(link["match_reasons"], {})
        sigs = {s["name"]: s for s in reasons.get("signals", []) if s.get("available")}
        for name, s in sigs.items():
            agg.setdefault(name, []).append(s["score"])
        per_report.append({
            "report": link["public_id"],
            "description": link["description"],
            "occurred_at": link["occurred_at"],
            "link_type": link["link_type"],
            "match_score": round(link["match_score"] or 0.0, 4),
            "decision": reasons.get("decision", "SEED"),
            "blocked_by": reasons.get("blocked_by"),
            "signals": [{
                "name": s["name"], "score": s["score"],
                "weight": s["weight"], "detail": s.get("detail", ""),
            } for s in sigs.values()],
            "reasons": reasons.get("reasons", []),
        })

    evidence_summary = jload(row["evidence_summary"], {})
    factors = []
    labels = {
        "semantic": "Descriptions were semantically similar",
        "spatial": "Reports were geographically close",
        "temporal": "Reports occurred within the configured time window",
        "evidence": "Reports shared observed outage evidence",
    }
    for name, scores in agg.items():
        mean = sum(scores) / len(scores)
        factors.append({
            "signal": name,
            "label": labels.get(name, name),
            "mean_score": round(mean, 4),
            "samples": len(scores),
            "weight": config.WEIGHTS.get(name, 0.0),
        })
    factors.sort(key=lambda f: f["weight"], reverse=True)

    return {
        "incident": row["public_id"],
        "correlation_confidence": round(row["correlation_confidence"] or 0.0, 4),
        "factors": factors,
        "shared_evidence": evidence_summary.get("concept_labels", []),
        "per_report": per_report,
        "method": semantic.describe(),
        "thresholds": {
            "merge": config.THRESHOLD_MERGE,
            "review": config.THRESHOLD_REVIEW,
            "semantic_floor": config.SEMANTIC_MERGE_FLOOR,
        },
        "boundary": (
            "These signals indicate that reports describe the same incident. They "
            "do not identify which physical grid component failed; that requires "
            "field inspection or utility telemetry."
        ),
    }


# ===========================================================================
# RESPONSE  (RESPOND)
# ===========================================================================
def build_brief(incident: dict) -> str:
    """Structured, human-readable response brief."""
    centroid_txt = "Location not available"
    if incident.get("centroid"):
        centroid_txt = (f"{incident['centroid']['latitude']:.5f}, "
                        f"{incident['centroid']['longitude']:.5f} "
                        f"(approx. {incident['affected_radius_m']:.0f} m radius)")
    symptoms_txt = "\n".join(f"  - {s}" for s in incident.get("symptoms", [])) or "  - None recorded"
    ev = incident.get("evidence_summary", {})
    lines = [
        f"INCIDENT {incident['public_id']}",
        "",
        "Affected Area:",
        f"  {centroid_txt}",
        "",
        f"First Observed: {incident['first_seen']}",
        f"Latest Update:  {incident['last_seen']}",
        f"Reports:        {incident['report_count']}",
        "",
        "Observed Symptoms:",
        symptoms_txt,
        "",
        f"Priority: {incident['priority']} (score {incident['priority_score']})",
        "Priority Reasons:",
    ]
    for r in incident.get("priority_reasons", []):
        lines.append(f"  - {r['text']}")
    lines += [
        "",
        f"Correlation Confidence: {incident['correlation_confidence']:.2f}",
        "",
        "Recommended Next Action:",
        f"  {incident.get('recommended_action') or 'Monitor.'}",
        "",
        "Evidence:",
        f"  - {ev.get('report_count', 0)} correlated citizen reports",
        f"  - {ev.get('photo_count', 0)} photo(s) for human review",
        f"  - Observed categories: {', '.join(ev.get('concept_labels', [])) or 'none'}",
        "",
        "NOTE: This is a recommendation for human responders. PowerBack does not",
        "issue commands to electrical infrastructure and has not identified a",
        "specific failed component.",
    ]
    return "\n".join(lines)


def create_response(incident_ref, assigned_team: Optional[str] = None,
                    conn=None) -> dict:
    """Generate the response brief and open a response ticket."""
    conn = conn or connect()
    row = _resolve_incident(conn, incident_ref)

    existing = conn.execute(
        "SELECT * FROM response_tickets WHERE incident_id = ? AND status != ? "
        "ORDER BY id DESC LIMIT 1",
        (row["id"], lifecycle.TICKET_CLOSED)).fetchone()
    if existing:
        return {"ticket": _ticket_public(dict(existing)),
                "incident": get_incident(row["id"], conn=conn),
                "created": False,
                "message": "An open response ticket already exists for this incident."}

    incident = get_incident(row["id"], conn=conn)
    if incident["report_count"] == 0:
        raise ValidationError("Cannot open a response ticket for an incident with no confirmed reports.")

    brief = build_brief(incident)
    seq = conn.execute("SELECT COUNT(*) AS c FROM response_tickets").fetchone()["c"] + 1
    public_id = f"PB-{seq:03d}"

    cur = conn.execute(
        "INSERT INTO response_tickets (public_id, incident_id, status, priority, "
        "assigned_team, recommended_action, brief, created_at, updated_at) "
        "VALUES (?,?,?,?,?,?,?,?,?)",
        (public_id, row["id"], lifecycle.AWAITING_DISPATCH, incident["priority"],
         assigned_team, incident["recommended_action"], brief, to_iso(), to_iso()))
    ticket_id = cur.lastrowid

    target = lifecycle.TICKET_TO_INCIDENT[lifecycle.AWAITING_DISPATCH]
    new_status = lifecycle.transition_incident(row["status"], target)
    conn.execute("UPDATE incidents SET status = ?, updated_at = ? WHERE id = ?",
                 (new_status, to_iso(), row["id"]))

    audit.log(conn, "incident", row["id"], "RESPONSE_CREATED",
              {"ticket": public_id, "from": row["status"], "to": new_status},
              actor="operator")
    audit.log(conn, "ticket", ticket_id, "TICKET_OPENED", {"status": lifecycle.AWAITING_DISPATCH})
    conn.commit()

    ticket = conn.execute("SELECT * FROM response_tickets WHERE id = ?",
                          (ticket_id,)).fetchone()
    return {"ticket": _ticket_public(dict(ticket)),
            "incident": get_incident(row["id"], conn=conn),
            "created": True,
            "message": f"Response ticket {public_id} opened."}


def _ticket_public(row: dict) -> dict:
    return {
        "id": row["id"], "public_id": row["public_id"],
        "incident_id": row["incident_id"], "status": row["status"],
        "priority": row["priority"], "assigned_team": row["assigned_team"],
        "recommended_action": row["recommended_action"], "brief": row["brief"],
        "created_at": row["created_at"], "updated_at": row["updated_at"],
        "allowed_transitions": lifecycle.allowed_ticket_next(row["status"]),
    }


def update_ticket(ticket_ref, status: Optional[str] = None,
                  assigned_team: Optional[str] = None, conn=None) -> dict:
    """
    Advance a response ticket. Invalid transitions raise TransitionError,
    which the transport maps to HTTP 409 with the allowed next states.

    The incident is advanced in lockstep so the two state machines cannot
    diverge.
    """
    conn = conn or connect()
    row = None
    if isinstance(ticket_ref, int) or str(ticket_ref).isdigit():
        row = conn.execute("SELECT * FROM response_tickets WHERE id = ?",
                           (int(ticket_ref),)).fetchone()
    if row is None:
        row = conn.execute("SELECT * FROM response_tickets WHERE public_id = ?",
                           (str(ticket_ref),)).fetchone()
    if row is None:
        raise NotFound(f"Response ticket '{ticket_ref}' was not found.")
    row = dict(row)

    new_status = row["status"]
    if status and status != row["status"]:
        new_status = lifecycle.transition_ticket(row["status"], status)

    team = assigned_team if assigned_team is not None else row["assigned_team"]
    # Moving to ASSIGNED without a team is a workflow error worth catching.
    if new_status == lifecycle.TICKET_ASSIGNED and not team:
        raise ValidationError("A team must be assigned when moving a ticket to ASSIGNED.",
                              "assigned_team")

    conn.execute(
        "UPDATE response_tickets SET status = ?, assigned_team = ?, updated_at = ? WHERE id = ?",
        (new_status, team, to_iso(), row["id"]))

    incident = conn.execute("SELECT * FROM incidents WHERE id = ?",
                            (row["incident_id"],)).fetchone()
    incident = dict(incident)
    target = lifecycle.TICKET_TO_INCIDENT.get(new_status)
    if target and target != incident["status"]:
        if lifecycle.can_transition_incident(incident["status"], target):
            conn.execute("UPDATE incidents SET status = ?, updated_at = ? WHERE id = ?",
                         (target, to_iso(), incident["id"]))
            audit.log(conn, "incident", incident["id"], "STATE_CHANGED",
                      {"from": incident["status"], "to": target,
                       "driver": f"ticket {row['public_id']}"}, actor="operator")

    audit.log(conn, "ticket", row["id"], "TICKET_UPDATED",
              {"from": row["status"], "to": new_status, "team": team}, actor="operator")
    conn.commit()

    updated = conn.execute("SELECT * FROM response_tickets WHERE id = ?",
                           (row["id"],)).fetchone()
    return {"ticket": _ticket_public(dict(updated)),
            "incident": get_incident(row["incident_id"], conn=conn)}


# ===========================================================================
# RESTORATION + VERIFICATION  (RESTORE -> VERIFY -> CLOSE)
# ===========================================================================
def add_restoration_update(incident_ref, source: str, status: str,
                           note: Optional[str] = None, conn=None) -> dict:
    conn = conn or connect()
    row = _resolve_incident(conn, incident_ref)
    restoration_mod.validate_update(source, status)
    if row["status"] == lifecycle.CLOSED:
        raise ValidationError("Cannot add restoration updates to a closed incident.")

    conn.execute(
        "INSERT INTO restoration_updates (incident_id, source, status, note, "
        "confidence, created_at) VALUES (?,?,?,?,?,?)",
        (row["id"], source, status, (note or "")[:500], 0.0, to_iso()))

    assessment = restoration_mod.compute_confidence(conn, row)
    conn.execute("UPDATE incidents SET restoration_confidence = ?, updated_at = ? WHERE id = ?",
                 (assessment["confidence"], to_iso(), row["id"]))

    # First restoration signal moves an in-flight incident to RESTORATION_PENDING.
    if (status == restoration_mod.STATUS_RESTORED
            and lifecycle.can_transition_incident(row["status"], lifecycle.RESTORATION_PENDING)):
        conn.execute("UPDATE incidents SET status = ?, updated_at = ? WHERE id = ?",
                     (lifecycle.RESTORATION_PENDING, to_iso(), row["id"]))
        audit.log(conn, "incident", row["id"], "STATE_CHANGED",
                  {"from": row["status"], "to": lifecycle.RESTORATION_PENDING,
                   "driver": f"{source} restoration signal"})

    audit.log(conn, "incident", row["id"], "RESTORATION_UPDATE",
              {"source": source, "status": status,
               "confidence": assessment["confidence"]},
              actor=source.lower())
    conn.commit()
    return {"restoration": restoration_mod.compute_confidence(conn, row),
            "incident": get_incident(row["id"], conn=conn)}


def verify_restoration(incident_ref, conn=None) -> dict:
    """
    Move an incident to VERIFICATION, and then to RESTORED/CLOSED, only when the
    computed restoration confidence clears the configured threshold.

    Verification is refused -- with the reason and the current confidence -- when
    the evidence is not there. Closing an incident that is still out is the most
    damaging failure this system could have.
    """
    conn = conn or connect()
    row = _resolve_incident(conn, incident_ref)
    assessment = restoration_mod.compute_confidence(conn, row)

    if not assessment["can_verify"]:
        raise ValidationError(
            f"Restoration confidence is {assessment['confidence']:.2f}, below the "
            f"{assessment['verify_threshold']:.2f} required to verify. "
            "Collect more restoration signals (response team update or citizen "
            "confirmations) before verifying.")

    status = row["status"]
    for target in (lifecycle.RESTORED, lifecycle.VERIFICATION):
        if status == target:
            continue
        if lifecycle.can_transition_incident(status, target):
            conn.execute("UPDATE incidents SET status = ?, updated_at = ? WHERE id = ?",
                         (target, to_iso(), row["id"]))
            audit.log(conn, "incident", row["id"], "STATE_CHANGED",
                      {"from": status, "to": target, "driver": "verification"},
                      actor="operator")
            status = target

    conn.execute("UPDATE incidents SET restoration_confidence = ?, updated_at = ? WHERE id = ?",
                 (assessment["confidence"], to_iso(), row["id"]))
    audit.log(conn, "incident", row["id"], "RESTORATION_VERIFIED",
              {"confidence": assessment["confidence"], "band": assessment["band"]},
              actor="operator")
    conn.commit()
    return {"restoration": assessment, "incident": get_incident(row["id"], conn=conn)}


def close_incident(incident_ref, note: Optional[str] = None, conn=None) -> dict:
    """Close an incident and its open tickets."""
    conn = conn or connect()
    row = _resolve_incident(conn, incident_ref)
    if row["status"] == lifecycle.CLOSED:
        return {"incident": get_incident(row["id"], conn=conn),
                "message": "Incident is already closed."}

    new_status = lifecycle.transition_incident(row["status"], lifecycle.CLOSED)
    conn.execute("UPDATE incidents SET status = ?, updated_at = ? WHERE id = ?",
                 (new_status, to_iso(), row["id"]))
    conn.execute(
        "UPDATE response_tickets SET status = ?, updated_at = ? "
        "WHERE incident_id = ? AND status != ?",
        (lifecycle.TICKET_CLOSED, to_iso(), row["id"], lifecycle.TICKET_CLOSED))
    audit.log(conn, "incident", row["id"], "INCIDENT_CLOSED",
              {"from": row["status"], "note": note or ""}, actor="operator")
    conn.commit()
    return {"incident": get_incident(row["id"], conn=conn),
            "message": f"Incident {row['public_id']} closed."}


# ===========================================================================
# HUMAN REVIEW OF UNCERTAIN CORRELATIONS
# ===========================================================================
def resolve_review(link_id: int, action: str, conn=None) -> dict:
    """
    Resolve a PENDING_REVIEW link.

    action = "CONFIRM"  -> the report does belong to this incident
    action = "REJECT"   -> detach it and promote it into its own incident

    This is the human half of "the system supports uncertainty". Without it,
    REVIEW would be a dead end rather than a workflow.
    """
    conn = conn or connect()
    link = conn.execute(
        "SELECT ir.*, r.description, r.latitude, r.longitude, r.occurred_at, "
        "r.public_id AS report_public_id, r.extracted_signals "
        "FROM incident_reports ir JOIN reports r ON r.id = ir.report_id "
        "WHERE ir.id = ?", (link_id,)).fetchone()
    if link is None:
        raise NotFound(f"Review link {link_id} was not found.")
    link = dict(link)
    if link["link_type"] != "PENDING_REVIEW":
        raise ValidationError(
            f"Link {link_id} is not pending review (current state: {link['link_type']}).")

    action = (action or "").upper()
    if action not in ("CONFIRM", "REJECT"):
        raise ValidationError("Action must be either 'CONFIRM' or 'REJECT'.", "action")

    incident_id = link["incident_id"]
    if action == "CONFIRM":
        conn.execute("UPDATE incident_reports SET link_type = 'MERGED' WHERE id = ?", (link_id,))
        audit.log(conn, "incident", incident_id, "REVIEW_CONFIRMED",
                  {"report": link["report_public_id"]}, actor="operator")
        new_incident_id = incident_id
    else:
        conn.execute("DELETE FROM incident_reports WHERE id = ?", (link_id,))
        report = {
            "id": link["report_id"],
            "latitude": link["latitude"],
            "longitude": link["longitude"],
            "occurred_at": link["occurred_at"],
        }
        new_incident_id = _create_incident(conn, report, 1.0)
        _link_report(conn, new_incident_id, link["report_id"], 1.0,
                     {"decision": "SEED",
                      "reasons": ["Separated from another incident by human review."]},
                     "MERGED")
        audit.log(conn, "incident", incident_id, "REVIEW_REJECTED",
                  {"report": link["report_public_id"], "moved_to_incident": new_incident_id},
                  actor="operator")
        audit.log(conn, "incident", new_incident_id, "INCIDENT_CREATED",
                  {"seed_report": link["report_public_id"], "origin": "review rejection"})
        recompute_incident(conn, new_incident_id)

    remaining = conn.execute(
        "SELECT COUNT(*) AS c FROM incident_reports WHERE incident_id = ? AND link_type = 'PENDING_REVIEW'",
        (incident_id,)).fetchone()["c"]
    conn.execute("UPDATE incidents SET needs_review = ?, updated_at = ? WHERE id = ?",
                 (1 if remaining else 0, to_iso(), incident_id))
    recompute_incident(conn, incident_id)
    conn.commit()

    return {
        "action": action,
        "incident": get_incident(incident_id, conn=conn),
        "new_incident": (get_incident(new_incident_id, conn=conn)
                         if new_incident_id != incident_id else None),
    }


def list_reviews(conn=None) -> List[dict]:
    conn = conn or connect()
    rows = conn.execute(
        "SELECT ir.id AS link_id, ir.match_score, ir.match_reasons, "
        "i.public_id AS incident_public_id, i.id AS incident_id, "
        "r.public_id AS report_public_id, r.description, r.occurred_at "
        "FROM incident_reports ir "
        "JOIN incidents i ON i.id = ir.incident_id "
        "JOIN reports r ON r.id = ir.report_id "
        "WHERE ir.link_type = 'PENDING_REVIEW' ORDER BY ir.id DESC").fetchall()
    return [{
        "link_id": r["link_id"],
        "incident_id": r["incident_id"],
        "incident": r["incident_public_id"],
        "report": r["report_public_id"],
        "description": r["description"],
        "occurred_at": r["occurred_at"],
        "match_score": round(r["match_score"] or 0.0, 4),
        "reasons": jload(r["match_reasons"], {}).get("reasons", []),
    } for r in rows]


# ===========================================================================
# SYSTEM / STATS
# ===========================================================================
def list_reports(conn=None, limit: int = 200) -> List[dict]:
    conn = conn or connect()
    rows = conn.execute(
        "SELECT * FROM reports ORDER BY occurred_at DESC LIMIT ?", (limit,)).fetchall()
    return [{
        "id": r["id"], "public_id": r["public_id"], "description": r["description"],
        "latitude": r["latitude"], "longitude": r["longitude"],
        "occurred_at": r["occurred_at"], "status": r["status"],
        "flags": jload(r["flags"], []), "has_photo": bool(r["photo_path"]),
        "signals": jload(r["extracted_signals"], {}),
    } for r in rows]


def stats(conn=None) -> dict:
    conn = conn or connect()
    total_reports = conn.execute("SELECT COUNT(*) c FROM reports").fetchone()["c"]
    total_incidents = conn.execute("SELECT COUNT(*) c FROM incidents").fetchone()["c"]
    open_incidents = conn.execute(
        "SELECT COUNT(*) c FROM incidents WHERE status != 'CLOSED'").fetchone()["c"]
    by_priority = {r["priority"] or "UNSET": r["c"] for r in conn.execute(
        "SELECT priority, COUNT(*) c FROM incidents WHERE status != 'CLOSED' GROUP BY priority")}
    pending = conn.execute(
        "SELECT COUNT(*) c FROM incident_reports WHERE link_type = 'PENDING_REVIEW'"
    ).fetchone()["c"]
    tickets = conn.execute(
        "SELECT COUNT(*) c FROM response_tickets WHERE status != 'CLOSED'").fetchone()["c"]
    correlated = conn.execute(
        "SELECT COUNT(*) c FROM incident_reports WHERE link_type = 'MERGED'").fetchone()["c"]

    return {
        "reports": total_reports,
        "incidents": total_incidents,
        "open_incidents": open_incidents,
        "closed_incidents": total_incidents - open_incidents,
        "by_priority": by_priority,
        "pending_review": pending,
        "open_tickets": tickets,
        "correlated_links": correlated,
        # The headline consolidation metric: how many raw observations collapse
        # into one actionable incident. Computed, never asserted.
        "consolidation_ratio": (round(correlated / total_incidents, 2)
                                if total_incidents else 0.0),
    }


def system_info() -> dict:
    """Capability report. The UI renders this verbatim so it cannot overclaim."""
    return {
        "product": "PowerBack",
        "tagline": "From scattered signals to coordinated response.",
        "semantic": semantic.describe(),
        "vision": evidence.describe(),
        "abuse": abuse.describe(),
        "restoration": restoration_mod.describe(),
        "correlation": {
            "weights": dict(config.WEIGHTS),
            "thresholds": {
                "merge": config.THRESHOLD_MERGE,
                "review": config.THRESHOLD_REVIEW,
                "semantic_floor": config.SEMANTIC_MERGE_FLOOR,
            },
            "candidate_gates": {
                "radius_m": config.CANDIDATE_RADIUS_M,
                "window_minutes": config.CANDIDATE_WINDOW_MIN,
            },
            "spatial_decay_m": config.SPATIAL_DECAY_M,
            "temporal_decay_minutes": config.TEMPORAL_DECAY_MIN,
            "note": ("Prototype parameters calibrated against the synthetic demo "
                     "dataset. Not claimed to be optimal."),
        },
        "utility_integration": {
            "connected": False,
            "mode": "Integration-ready adapter (simulated operator queue)",
            "note": ("PowerBack is NOT connected to any real utility or government "
                     "electricity department in this build."),
        },
        "boundaries": [
            "Correlates citizen observations; does not identify which physical "
            "grid component failed.",
            "Issues recommendations to human responders; never commands "
            "electrical infrastructure.",
            "Reports restoration confidence, not confirmed physical restoration.",
            "No automated image classification; photos are preserved for human review.",
        ],
    }
