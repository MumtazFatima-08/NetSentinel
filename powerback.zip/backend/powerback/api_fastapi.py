"""
Optional FastAPI transport.

STATUS: this adapter is provided because FastAPI is the documented target
stack, but the PRIMARY, fully-tested transport in this repository is
`powerback/server.py`, which uses only the standard library.

Why: the build environment for this prototype has no network access, so
FastAPI could not be installed and therefore this module could not be executed
in the test suite. The test suite instead exercises `service.py` directly and
smoke-tests the stdlib server over real HTTP. Every route below is a thin
delegation to the same service functions those tests cover, so the behaviour is
identical -- but the honest statement is that this file is unverified at
runtime, and the stdlib server is what we demo with.

To use it:

    pip install fastapi uvicorn
    uvicorn powerback.api_fastapi:app --reload --port 8000

If anything here misbehaves, `python -m powerback.server` is the reliable path
and requires no installation at all.
"""
from __future__ import annotations

from typing import Any, Dict, Optional

try:
    from fastapi import Body, FastAPI, HTTPException, Request
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import JSONResponse
    from fastapi.staticfiles import StaticFiles
    from pydantic import BaseModel, Field
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "FastAPI is not installed. Either run `pip install fastapi uvicorn`, "
        "or use the zero-dependency server: python -m powerback.server"
    ) from exc

import os

from . import config, database, lifecycle, service
from .abuse import RateLimitExceeded
from .service import NotFound, ValidationError

app = FastAPI(
    title="PowerBack API",
    version="1.0",
    description="Citizen-powered outage intelligence and response coordination.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=config.CORS_ALLOW_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST", "PATCH", "OPTIONS"],
    allow_headers=["Content-Type"],
)


@app.on_event("startup")
def _startup() -> None:
    database.init_db()
    os.makedirs(service.MEDIA_DIR, exist_ok=True)


# ---------------------------------------------------------------------------
# Error mapping -- identical semantics to the stdlib server
# ---------------------------------------------------------------------------
@app.exception_handler(ValidationError)
def _validation(_: Request, exc: ValidationError):
    return JSONResponse(status_code=400,
                        content={"error": str(exc), "field": getattr(exc, "field", None)})


@app.exception_handler(NotFound)
def _notfound(_: Request, exc: NotFound):
    return JSONResponse(status_code=404, content={"error": str(exc)})


@app.exception_handler(lifecycle.TransitionError)
def _transition(_: Request, exc: lifecycle.TransitionError):
    return JSONResponse(status_code=409,
                        content={"error": str(exc), "type": "invalid_transition"})


@app.exception_handler(RateLimitExceeded)
def _ratelimit(_: Request, exc: RateLimitExceeded):
    return JSONResponse(status_code=429,
                        content={"error": str(exc),
                                 "retry_after_minutes": round(exc.retry_after_min, 1)})


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------
class ReportIn(BaseModel):
    description: str = Field(..., min_length=1, max_length=config.DESCRIPTION_MAX_LEN)
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    occurred_at: Optional[str] = None
    session_id: Optional[str] = None
    photo_base64: Optional[str] = None
    photo_mime: Optional[str] = None


class ResponseIn(BaseModel):
    assigned_team: Optional[str] = None


class TicketPatch(BaseModel):
    status: Optional[str] = None
    assigned_team: Optional[str] = None


class RestorationIn(BaseModel):
    source: str
    status: str
    note: Optional[str] = None


class ReviewIn(BaseModel):
    action: str


class CloseIn(BaseModel):
    note: Optional[str] = None


class SeedIn(BaseModel):
    reset: bool = True


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.get("/api/health")
def health() -> Dict[str, Any]:
    return {"status": "ok", "database": database.get_db_path()}


@app.get("/api/system")
def system() -> Dict[str, Any]:
    return service.system_info()


@app.get("/api/stats")
def stats() -> Dict[str, Any]:
    return service.stats()


@app.post("/api/reports")
def create_report(payload: ReportIn) -> Dict[str, Any]:
    return service.submit_report(payload.model_dump())


@app.get("/api/reports")
def list_reports(limit: int = 200) -> Dict[str, Any]:
    return {"reports": service.list_reports(limit=limit)}


@app.get("/api/incidents")
def list_incidents(status: Optional[str] = None) -> Dict[str, Any]:
    return {"incidents": service.list_incidents(status=status)}


@app.get("/api/incidents/{ref}")
def get_incident(ref: str) -> Dict[str, Any]:
    return service.get_incident(ref)


@app.get("/api/incidents/{ref}/explain")
def explain(ref: str) -> Dict[str, Any]:
    return service.explain_incident(ref)


@app.post("/api/incidents/{ref}/response")
def create_response(ref: str, payload: ResponseIn = Body(default=ResponseIn())):
    return service.create_response(ref, payload.assigned_team)


@app.post("/api/incidents/{ref}/restoration")
def restoration(ref: str, payload: RestorationIn):
    return service.add_restoration_update(ref, payload.source, payload.status, payload.note)


@app.post("/api/incidents/{ref}/verify")
def verify(ref: str):
    return service.verify_restoration(ref)


@app.post("/api/incidents/{ref}/close")
def close(ref: str, payload: CloseIn = Body(default=CloseIn())):
    return service.close_incident(ref, payload.note)


@app.patch("/api/response-tickets/{ref}")
def patch_ticket(ref: str, payload: TicketPatch):
    return service.update_ticket(ref, payload.status, payload.assigned_team)


@app.get("/api/reviews")
def reviews() -> Dict[str, Any]:
    return {"reviews": service.list_reviews()}


@app.post("/api/reviews/{link_id}")
def resolve_review(link_id: int, payload: ReviewIn):
    return service.resolve_review(link_id, payload.action)


@app.post("/api/demo/seed")
def seed_demo(payload: SeedIn = Body(default=SeedIn())):
    from . import seed as seed_mod
    return seed_mod.seed(reset=payload.reset)


# ---------------------------------------------------------------------------
# Static assets (mounted last so they never shadow the API routes)
# ---------------------------------------------------------------------------
_FRONTEND = os.environ.get(
    "PB_FRONTEND_DIR",
    os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__)))), "frontend"))

if os.path.isdir(service.MEDIA_DIR):
    app.mount("/media", StaticFiles(directory=service.MEDIA_DIR), name="media")
if os.path.isdir(_FRONTEND):
    app.mount("/", StaticFiles(directory=_FRONTEND, html=True), name="frontend")
