"""
PowerBack — centralized configuration.

EVERY tunable number in the correlation, priority, restoration and abuse
subsystems lives here. No magic numbers are allowed elsewhere in the codebase.

These are PROTOTYPE PARAMETERS chosen by testing against the synthetic demo
dataset. They are NOT scientifically optimal and would require real-world
calibration before operational use. See docs/correlation-engine.md.
"""
from __future__ import annotations

import os


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, default))
    except (TypeError, ValueError):
        return default


# ---------------------------------------------------------------------------
# CANDIDATE SELECTION
# ---------------------------------------------------------------------------
# A new report is only ever compared against incidents that fall inside BOTH
# of these hard gates. This keeps the expensive semantic comparison bounded
# (performance) and prevents absurd correlations across a whole city (safety).
CANDIDATE_RADIUS_M = _env_float("PB_CANDIDATE_RADIUS_M", 600.0)
CANDIDATE_WINDOW_MIN = _env_float("PB_CANDIDATE_WINDOW_MIN", 120.0)

# Incidents in these states no longer accept new correlated reports.
CANDIDATE_EXCLUDED_STATES = ("RESTORED", "VERIFICATION", "CLOSED")


# ---------------------------------------------------------------------------
# CORRELATION SIGNAL WEIGHTS
# ---------------------------------------------------------------------------
# Weights are renormalized over the signals actually AVAILABLE for a given
# comparison. If a report has no photo, the evidence weight is dropped and the
# remaining weights are rescaled -- a missing signal never silently counts as
# a zero score.
# Semantic carries the largest weight DELIBERATELY. Proximity in space and
# time is cheap evidence -- in a dense neighbourhood almost everything is
# nearby and recent, so a spatially-dominated model will happily merge a water
# leak into a power outage. Measured: with spatial/temporal dominant, an
# unrelated non-electrical complaint 70 m away scored 0.50. With semantics
# dominant it scores 0.38 and is correctly separated.
WEIGHTS = {
    "semantic": _env_float("PB_W_SEMANTIC", 0.50),
    "spatial": _env_float("PB_W_SPATIAL", 0.25),
    "temporal": _env_float("PB_W_TEMPORAL", 0.15),
    "evidence": _env_float("PB_W_EVIDENCE", 0.10),
}

# Spatial decay: score = exp(-(distance / SPATIAL_DECAY_M)^2)
SPATIAL_DECAY_M = _env_float("PB_SPATIAL_DECAY_M", 350.0)

# Temporal decay: score = exp(-minutes_apart / TEMPORAL_DECAY_MIN)
TEMPORAL_DECAY_MIN = _env_float("PB_TEMPORAL_DECAY_MIN", 45.0)


# ---------------------------------------------------------------------------
# CORRELATION DECISION THRESHOLDS
# ---------------------------------------------------------------------------
# >= MERGE          -> attach to the existing incident
# >= REVIEW         -> attach as PENDING_REVIEW, flagged for a human
# <  REVIEW         -> create a new incident
THRESHOLD_MERGE = _env_float("PB_THRESHOLD_MERGE", 0.60)
THRESHOLD_REVIEW = _env_float("PB_THRESHOLD_REVIEW", 0.42)

# A semantic score below this floor blocks an automatic merge even when the
# spatial/temporal signals are very strong. This is what stops two physically
# adjacent but genuinely different events from being blindly merged.
SEMANTIC_MERGE_FLOOR = _env_float("PB_SEMANTIC_MERGE_FLOOR", 0.30)


# ---------------------------------------------------------------------------
# PRIORITY ENGINE (transparent rules, not a black-box model)
# ---------------------------------------------------------------------------
PRIORITY_BANDS = [
    ("CRITICAL", _env_float("PB_PRIORITY_CRITICAL", 70.0)),
    ("HIGH", _env_float("PB_PRIORITY_HIGH", 42.0)),
    ("MEDIUM", _env_float("PB_PRIORITY_MEDIUM", 20.0)),
    ("LOW", 0.0),
]

PRIORITY_RULES = {
    # Safety first: a reported hazard dominates the score.
    "hazard_points": _env_float("PB_PR_HAZARD", 45.0),
    # Scale of the event.
    "points_per_report": _env_float("PB_PR_PER_REPORT", 5.0),
    "report_points_cap": _env_float("PB_PR_REPORT_CAP", 30.0),
    # Rapid growth = spreading / escalating event.
    "growth_reports_per_10min": _env_float("PB_PR_GROWTH_RATE", 2.5),
    "growth_points": _env_float("PB_PR_GROWTH", 14.0),
    # Sustained outage.
    "duration_minutes_threshold": _env_float("PB_PR_DURATION_MIN", 45.0),
    "duration_points": _env_float("PB_PR_DURATION", 10.0),
    # Reports indicate many premises are out, not just one household.
    "area_wide_points": _env_float("PB_PR_AREA_WIDE", 12.0),
    # Critical premises affected.
    "critical_infra_points": _env_float("PB_PR_CRITICAL_INFRA", 18.0),
    # Photo evidence attached that a human should look at.
    "evidence_points": _env_float("PB_PR_EVIDENCE", 6.0),
}

# NOTE: the keyword families that drive symptom/hazard extraction live in
# lexicon.py, which is the single source of truth for the domain ontology.
# They are intentionally NOT duplicated here.


# ---------------------------------------------------------------------------
# SEMANTIC VECTOR COMPOSITION
# ---------------------------------------------------------------------------
# The active semantic vector concatenates a domain CONCEPT vector with a
# lexical TF-IDF vector. Concepts dominate because short citizen reports
# describing one event share concepts but rarely share words; the lexical part
# only breaks ties and catches wording the ontology has not seen.
SEMANTIC_ALPHA_CONCEPT = _env_float("PB_SEM_ALPHA", 0.88)
SEMANTIC_BETA_LEXICAL = _env_float("PB_SEM_BETA", 0.30)


# ---------------------------------------------------------------------------
# RESTORATION VERIFICATION
# ---------------------------------------------------------------------------
# Restoration confidence is a weighted combination of the signals we can
# actually observe. Without authoritative utility telemetry this is a
# CONFIDENCE, never a claim of confirmed physical grid restoration.
RESTORATION_WEIGHTS = {
    "response_team_update": _env_float("PB_RW_TEAM", 0.45),
    "citizen_confirmation": _env_float("PB_RW_CITIZEN", 0.35),
    "report_rate_decline": _env_float("PB_RW_DECLINE", 0.20),
    "utility_status": _env_float("PB_RW_UTILITY", 0.0),  # 0 until a real feed exists
}
# Citizen confirmations saturate: 3 independent confirmations reach full weight.
CITIZEN_CONFIRMATIONS_FOR_FULL = _env_int("PB_CITIZEN_CONFIRMS", 3)
# Minutes with no new outage reports before "report rate decline" counts.
QUIET_PERIOD_MIN = _env_float("PB_QUIET_PERIOD_MIN", 20.0)

RESTORATION_BANDS = [
    ("HIGH", _env_float("PB_RESTORE_HIGH", 0.70)),
    ("MEDIUM", _env_float("PB_RESTORE_MEDIUM", 0.40)),
    ("LOW", 0.0),
]
# Confidence required before an incident may be moved to RESTORED.
RESTORATION_VERIFY_MIN = _env_float("PB_RESTORE_VERIFY_MIN", 0.70)


# ---------------------------------------------------------------------------
# ABUSE / SPAM PROTECTION
# ---------------------------------------------------------------------------
RATE_LIMIT_MAX_REPORTS = _env_int("PB_RATE_LIMIT_MAX", 8)
RATE_LIMIT_WINDOW_MIN = _env_float("PB_RATE_LIMIT_WINDOW_MIN", 10.0)
# Near-identical text from the same session within this window = duplicate.
DUPLICATE_WINDOW_MIN = _env_float("PB_DUPLICATE_WINDOW_MIN", 15.0)
DUPLICATE_SIMILARITY = _env_float("PB_DUPLICATE_SIMILARITY", 0.93)
DUPLICATE_RADIUS_M = _env_float("PB_DUPLICATE_RADIUS_M", 120.0)


# ---------------------------------------------------------------------------
# INPUT VALIDATION LIMITS
# ---------------------------------------------------------------------------
DESCRIPTION_MIN_LEN = _env_int("PB_DESC_MIN", 3)
DESCRIPTION_MAX_LEN = _env_int("PB_DESC_MAX", 1000)
PHOTO_MAX_BYTES = _env_int("PB_PHOTO_MAX_BYTES", 5 * 1024 * 1024)
PHOTO_ALLOWED_TYPES = ("image/jpeg", "image/png", "image/webp")
LAT_RANGE = (-90.0, 90.0)
LON_RANGE = (-180.0, 180.0)


# ---------------------------------------------------------------------------
# RUNTIME
# ---------------------------------------------------------------------------
DB_PATH = os.environ.get("PB_DB_PATH", "powerback.db")
CORS_ALLOW_ORIGINS = [
    o.strip() for o in os.environ.get("PB_CORS_ORIGINS", "*").split(",") if o.strip()
]
# Preferred semantic backend: "auto" | "sentence-transformers" | "tfidf"
SEMANTIC_BACKEND = os.environ.get("PB_SEMANTIC_BACKEND", "auto")
SEMANTIC_MODEL_NAME = os.environ.get("PB_SEMANTIC_MODEL", "all-MiniLM-L6-v2")
