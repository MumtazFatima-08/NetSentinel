"""
Restoration tracking and verification.

CLAIM BOUNDARY
--------------
Without authoritative utility telemetry, PowerBack cannot and does not confirm
physical grid restoration. It computes a RESTORATION CONFIDENCE from the
signals it can actually observe, and the UI always says "confidence", never
"confirmed".

Observable signals, weighted in config.RESTORATION_WEIGHTS:

  response_team_update  a responder marked the work complete (strongest)
  citizen_confirmation  citizens report supply is back (saturating)
  report_rate_decline   new outage reports have stopped arriving
  utility_status        authoritative feed -- WEIGHT 0 until one exists

`utility_status` is wired but carries zero weight, because there is no real
utility connection in this prototype. It is present so integrating a genuine
feed is a configuration change, not a rewrite -- and so nobody can mistake the
current build for one that has such a feed.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from . import config
from .util import minutes_between, now, parse_time

# Restoration signal sources
SOURCE_TEAM = "RESPONSE_TEAM"
SOURCE_CITIZEN = "CITIZEN"
SOURCE_SYSTEM = "SYSTEM"
SOURCE_UTILITY = "UTILITY"

VALID_SOURCES = (SOURCE_TEAM, SOURCE_CITIZEN, SOURCE_SYSTEM, SOURCE_UTILITY)

# Restoration statuses reported by a signal
STATUS_RESTORED = "RESTORED"
STATUS_NOT_RESTORED = "NOT_RESTORED"
STATUS_PARTIAL = "PARTIAL"

VALID_STATUSES = (STATUS_RESTORED, STATUS_NOT_RESTORED, STATUS_PARTIAL)


def _band(confidence: float) -> str:
    for name, floor in config.RESTORATION_BANDS:
        if confidence >= floor:
            return name
    return "LOW"


def compute_confidence(conn, incident: Dict[str, Any]) -> dict:
    """
    Combine all observed restoration signals into one explainable confidence.

    Returns {confidence, band, contributions[], can_verify, signals_seen}.
    """
    incident_id = incident["id"]
    weights = config.RESTORATION_WEIGHTS
    rows = conn.execute(
        "SELECT * FROM restoration_updates WHERE incident_id = ? ORDER BY id ASC",
        (incident_id,)).fetchall()
    updates = [dict(r) for r in rows]

    contributions: List[dict] = []
    total = 0.0

    # --- Signal 1: response team update ----------------------------------
    team = [u for u in updates if u["source"] == SOURCE_TEAM]
    team_restored = [u for u in team if u["status"] == STATUS_RESTORED]
    # A later NOT_RESTORED from the team overrides an earlier RESTORED.
    team_latest = team[-1] if team else None
    if team_latest and team_latest["status"] == STATUS_RESTORED:
        w = weights["response_team_update"]
        total += w
        contributions.append({
            "signal": "response_team_update", "weight": w, "contribution": w,
            "text": "Response team reported restoration complete.",
            "count": len(team_restored),
        })
    elif team_latest:
        contributions.append({
            "signal": "response_team_update", "weight": weights["response_team_update"],
            "contribution": 0.0,
            "text": f"Latest response team update reports status '{team_latest['status']}'.",
            "count": len(team),
        })

    # --- Signal 2: citizen confirmations (saturating) --------------------
    citizen = [u for u in updates
               if u["source"] == SOURCE_CITIZEN and u["status"] == STATUS_RESTORED]
    if citizen:
        need = max(1, config.CITIZEN_CONFIRMATIONS_FOR_FULL)
        frac = min(1.0, len(citizen) / need)
        c = weights["citizen_confirmation"] * frac
        total += c
        contributions.append({
            "signal": "citizen_confirmation", "weight": weights["citizen_confirmation"],
            "contribution": round(c, 4),
            "text": (f"{len(citizen)} citizen confirmation(s) that supply is back "
                     f"({len(citizen)}/{need} toward full weight)."),
            "count": len(citizen),
        })

    # --- Signal 3: no new outage reports -------------------------------
    last_report = conn.execute(
        "SELECT MAX(r.occurred_at) AS latest FROM reports r "
        "JOIN incident_reports ir ON ir.report_id = r.id "
        "WHERE ir.incident_id = ? AND ir.link_type != 'REJECTED'",
        (incident_id,)).fetchone()
    quiet_minutes = None
    if last_report and last_report["latest"]:
        quiet_minutes = minutes_between(now(), parse_time(last_report["latest"]))
        if quiet_minutes >= config.QUIET_PERIOD_MIN:
            w = weights["report_rate_decline"]
            total += w
            contributions.append({
                "signal": "report_rate_decline", "weight": w, "contribution": w,
                "text": (f"No new outage reports for {quiet_minutes:.0f} minutes "
                         f"(threshold {config.QUIET_PERIOD_MIN:.0f})."),
                "count": 0,
            })
        else:
            contributions.append({
                "signal": "report_rate_decline", "weight": weights["report_rate_decline"],
                "contribution": 0.0,
                "text": (f"Last outage report was {quiet_minutes:.0f} minutes ago; "
                         f"quiet period of {config.QUIET_PERIOD_MIN:.0f} min not yet reached."),
                "count": 0,
            })

    # --- Signal 4: utility telemetry (not connected) ---------------------
    utility = [u for u in updates if u["source"] == SOURCE_UTILITY]
    contributions.append({
        "signal": "utility_status",
        "weight": weights["utility_status"],
        "contribution": 0.0,
        "text": ("No authoritative utility telemetry is connected to this prototype, "
                 "so this signal carries zero weight."),
        "count": len(utility),
    })

    confidence = max(0.0, min(1.0, total))
    return {
        "confidence": round(confidence, 4),
        "band": _band(confidence),
        "contributions": contributions,
        "can_verify": confidence >= config.RESTORATION_VERIFY_MIN,
        "verify_threshold": config.RESTORATION_VERIFY_MIN,
        "quiet_minutes": round(quiet_minutes, 1) if quiet_minutes is not None else None,
        "signals_seen": len(updates),
        "disclaimer": (
            "Restoration confidence is inferred from citizen and response-team "
            "signals. It is not a confirmation of physical grid restoration, "
            "which would require authoritative utility telemetry."
        ),
    }


def validate_update(source: str, status: str) -> None:
    if source not in VALID_SOURCES:
        raise ValueError(
            f"Invalid restoration source '{source}'. Expected one of: {', '.join(VALID_SOURCES)}.")
    if status not in VALID_STATUSES:
        raise ValueError(
            f"Invalid restoration status '{status}'. Expected one of: {', '.join(VALID_STATUSES)}.")


def describe() -> dict:
    return {
        "weights": dict(config.RESTORATION_WEIGHTS),
        "verify_threshold": config.RESTORATION_VERIFY_MIN,
        "citizen_confirmations_for_full_weight": config.CITIZEN_CONFIRMATIONS_FOR_FULL,
        "quiet_period_minutes": config.QUIET_PERIOD_MIN,
        "utility_telemetry_connected": False,
        "note": (
            "Reports restoration CONFIDENCE, never confirmed physical restoration."
        ),
    }
