"""
Concept matching and symptom extraction.

This module is deliberately rule-based and we call it rule-based everywhere.
It answers: "which known domain concepts does this text mention, and where?"

The matcher is word-boundary aware. A naive `term in text` substring check
produces false positives that would corrupt both the similarity signal and the
priority reasons ("shock" inside "shocking", "pole" inside "poles"), so every
term is compiled to a regex with boundaries. Multi-word terms allow flexible
internal whitespace.
"""
from __future__ import annotations

import re
from functools import lru_cache
from typing import Dict, List, Tuple

from .lexicon import CONCEPTS, OUTAGE_CONCEPTS

_WS = re.compile(r"\s+")


def normalize_text(text: str) -> str:
    """Lowercase, replace punctuation with spaces, collapse whitespace."""
    if not text:
        return ""
    t = str(text).lower().strip()
    t = re.sub(r"[^\w\s'-]", " ", t)
    return _WS.sub(" ", t).strip()


def _compile_term(term: str) -> re.Pattern:
    """
    Build a boundary-anchored pattern for a term.

    Terms ending in a truncated stem (e.g. "fluctuat") intentionally allow a
    trailing word continuation so they match "fluctuating"/"fluctuation".
    """
    parts = [re.escape(p) for p in term.split()]
    body = r"\s+".join(parts)
    # Allow plural / inflected endings on the final token.
    return re.compile(rf"(?<!\w){body}\w{{0,4}}(?!\w)")


@lru_cache(maxsize=1)
def _compiled() -> Dict[str, List[Tuple[str, re.Pattern]]]:
    out: Dict[str, List[Tuple[str, re.Pattern]]] = {}
    for concept, spec in CONCEPTS.items():
        out[concept] = [(t, _compile_term(t)) for t in spec["terms"]]
    return out


def match_concepts(text: str) -> Dict[str, List[str]]:
    """
    Return {concept_name: [matched surface terms]} for every concept present.

    Only concepts with at least one match appear in the result.
    """
    norm = normalize_text(text)
    if not norm:
        return {}
    found: Dict[str, List[str]] = {}
    for concept, terms in _compiled().items():
        hits = [term for term, pat in terms if pat.search(norm)]
        if hits:
            # Keep the longest, most specific matches first for display.
            hits.sort(key=len, reverse=True)
            found[concept] = hits
    return found


def extract_signals(text: str) -> dict:
    """
    Structured, explainable extraction from one report's text.

    Everything here is derived from an ACTUAL matched term, so any reason shown
    in the UI can be traced back to words the citizen really wrote.
    """
    concepts = match_concepts(text)
    return {
        "concepts": sorted(concepts.keys()),
        "matched_terms": {k: v[:4] for k, v in concepts.items()},
        "has_hazard": "HAZARD" in concepts,
        "hazard_terms": concepts.get("HAZARD", [])[:4],
        "has_critical_infra": "CRITICAL_INFRA" in concepts,
        "critical_infra_terms": concepts.get("CRITICAL_INFRA", [])[:4],
        "indicates_restored": "RESTORED" in concepts,
        "indicates_outage": any(c in concepts for c in OUTAGE_CONCEPTS),
        "is_non_electrical": (
            "NON_ELECTRICAL" in concepts
            and not any(c in concepts for c in OUTAGE_CONCEPTS)
            and "HAZARD" not in concepts
            and "EQUIPMENT" not in concepts
        ),
    }


def symptom_summary(text_list) -> List[str]:
    """Human-readable symptom bullets aggregated across an incident's reports."""
    agg: Dict[str, int] = {}
    for t in text_list:
        for concept in match_concepts(t):
            agg[concept] = agg.get(concept, 0) + 1
    order = [
        ("POWER_ABSENT", "Multiple premises without power"),
        ("AREA_WIDE", "Outage spans several premises / whole street"),
        ("STREETLIGHT", "Street lighting affected"),
        ("EQUIPMENT", "Distribution equipment referenced by reporters"),
        ("HAZARD", "Safety hazard observed"),
        ("PERSISTING", "Outage continuing without restoration"),
        ("PARTIAL", "Partial or unstable supply reported"),
        ("WEATHER", "Weather conditions reported around onset"),
        ("CRITICAL_INFRA", "Critical premises reported affected"),
        ("RESTORED", "Restoration reported by citizens"),
    ]
    return [label for key, label in order if key in agg]
