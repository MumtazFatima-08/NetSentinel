"""
PowerBack domain lexicon / concept ontology.

This is the SINGLE SOURCE OF TRUTH for the outage concept space. It is used by:

  * semantic.py   -- to build concept vectors for similarity
  * symptoms.py   -- to extract observed symptoms, hazards and infrastructure
  * the UI        -- to render the shared concepts in an explanation

Why an ontology rather than pure lexical matching:

Citizen outage reports are short and describe the SAME physical event with
almost no shared vocabulary. "Power has gone out", "no electricity", "power
cut" and "everything went dark" have near-zero lexical overlap but are the same
concept. A bag-of-words model scores them as unrelated, while scoring "garbage
on our street" and "power out on our street" as similar because both contain
"street". We measured exactly that failure before adopting this approach.

Grounding the text in concepts fixes the discrimination problem AND makes the
similarity explainable: we can name the concepts two reports share, instead of
showing an opaque number.

Each concept maps to surface forms. Multi-word forms are matched as phrases;
single tokens are matched on word boundaries (so "pole" does not match
"poles apart" incorrectly via substring, and "shock" does not fire inside
"shocking news" -- see symptoms.py for the matcher).
"""
from __future__ import annotations

from typing import Dict, Tuple

# ---------------------------------------------------------------------------
# CONCEPT SPACE
# ---------------------------------------------------------------------------
# weight = how strongly this concept identifies an incident's nature.
# Concepts with higher weight dominate the similarity geometry.
CONCEPTS: Dict[str, dict] = {
    "POWER_ABSENT": {
        "label": "Loss of electricity supply",
        "weight": 1.0,
        "terms": (
            "no power", "no electricity", "power cut", "power outage", "outage",
            "power failure", "power has gone", "power is gone", "power gone",
            "power went", "power is out", "power out", "lost power",
            "without power", "without electricity", "no current", "no supply",
            "no electric", "blackout", "black out", "lights are out",
            "lights went out", "went dark", "everything went dark",
            "supply is off", "electricity is off", "power is off",
            "power has been cut", "load shedding", "no light",
        ),
    },
    "AREA_WIDE": {
        "label": "Multiple premises affected",
        "weight": 0.9,
        "terms": (
            "several houses", "many houses", "all houses", "whole street",
            "entire street", "whole lane", "entire lane", "whole area",
            "entire area", "whole block", "entire block", "neighbourhood",
            "neighborhood", "everyone", "everybody", "all the homes",
            "multiple houses", "whole building", "entire building",
            "nearby houses", "the whole colony", "the entire society",
            # NOTE: deliberately NOT including bare "our street" / "this road".
            # Those phrases appear just as often in non-electrical complaints
            # ("garbage on our street"), and matching them created a false
            # AREA_WIDE overlap that made unrelated reports look similar.
        ),
    },
    "STREETLIGHT": {
        "label": "Street lighting affected",
        "weight": 0.85,
        "terms": (
            "street light", "street lights", "streetlight", "streetlights",
            "lamp post", "lamppost", "lamp posts", "road lights",
            "public lighting", "park lights",
        ),
    },
    "EQUIPMENT": {
        "label": "Distribution equipment observation",
        "weight": 0.9,
        "terms": (
            "transformer", "electric pole", "electricity pole", "power pole",
            "pole", "feeder", "substation", "sub station", "junction box",
            "distribution box", "meter box", "cable", "power line",
            "electric line", "overhead line", "dp box", "fuse box", "breaker",
        ),
    },
    "HAZARD": {
        "label": "Safety hazard reported",
        "weight": 1.0,
        "terms": (
            "spark", "sparks", "sparking", "sparked", "fire", "flames",
            "smoke", "smoking", "burning", "burnt", "burn smell",
            "burning smell", "explosion", "blast", "loud bang", "loud noise",
            "live wire", "fallen wire", "wire has fallen", "snapped wire",
            "hanging wire", "broken wire", "electric shock", "got a shock",
            "arcing", "short circuit", "shortcircuit", "dangerous",
            "caught fire",
        ),
    },
    "PERSISTING": {
        "label": "Outage continuing",
        "weight": 0.7,
        "terms": (
            "still not back", "still out", "still no", "still off",
            "not restored", "not yet restored", "yet to be restored",
            "since morning", "since evening", "since night", "since afternoon",
            "for hours", "two hours", "three hours", "many hours",
            "long time", "all day", "all night", "not come back",
            "has not returned", "no update",
        ),
    },
    "PARTIAL": {
        "label": "Partial or unstable supply",
        "weight": 0.75,
        "terms": (
            "flicker", "flickering", "flickers", "low voltage", "voltage is low",
            "dim", "dimming", "fluctuat", "fluctuation", "one phase",
            "single phase", "half the house", "partial power", "unstable",
            "coming and going", "on and off",
        ),
    },
    "RESTORED": {
        "label": "Supply restored",
        "weight": 0.95,
        "terms": (
            "power is back", "power back", "electricity is back",
            "supply restored", "has been restored", "is restored",
            "came back", "come back", "working again", "back to normal",
            "resumed", "power restored", "lights are back", "we have power",
            "everything is fine now", "all normal",
        ),
    },
    "WEATHER": {
        "label": "Weather-related context",
        "weight": 0.6,
        "terms": (
            "storm", "heavy rain", "rain", "raining", "wind", "windy",
            "lightning", "thunder", "tree fell", "branch fell", "tree branch",
            "cyclone", "gale",
        ),
    },
    "CRITICAL_INFRA": {
        "label": "Critical premises affected",
        "weight": 0.9,
        "terms": (
            "hospital", "clinic", "health centre", "health center",
            "nursing home", "dialysis", "school", "college", "water pump",
            "pumping station", "water supply station", "fire station",
            "police station", "traffic signal", "traffic light", "emergency",
        ),
    },
    # Deliberately part of the space: lets the model represent "this report is
    # about something else entirely", which is what separates a non-electrical
    # complaint from an outage instead of silently scoring it as similar.
    "NON_ELECTRICAL": {
        "label": "Non-electrical issue",
        "weight": 1.0,
        "terms": (
            "water leak", "water leakage", "no water", "water supply problem",
            "garbage", "trash", "rubbish", "waste collection", "pothole",
            "road damage", "road is broken", "drainage", "sewage", "blocked drain",
            "internet", "wifi", "broadband", "phone network", "mobile signal",
            "network issue", "street dog", "stray dog", "noise complaint",
            "construction noise", "parking", "encroachment", "gas leak",
        ),
    },
}

# Concepts that indicate the report describes an ACTIVE outage.
OUTAGE_CONCEPTS: Tuple[str, ...] = (
    "POWER_ABSENT", "AREA_WIDE", "STREETLIGHT", "PARTIAL", "PERSISTING",
)

# Derived views used by the priority engine and symptom extractor.
HAZARD_TERMS: Tuple[str, ...] = tuple(CONCEPTS["HAZARD"]["terms"])
CRITICAL_INFRA_TERMS: Tuple[str, ...] = tuple(CONCEPTS["CRITICAL_INFRA"]["terms"])
RESTORED_TERMS: Tuple[str, ...] = tuple(CONCEPTS["RESTORED"]["terms"])

CONCEPT_NAMES: Tuple[str, ...] = tuple(CONCEPTS.keys())
CONCEPT_INDEX: Dict[str, int] = {n: i for i, n in enumerate(CONCEPT_NAMES)}


# ---------------------------------------------------------------------------
# LATENT FACTOR SPACE
# ---------------------------------------------------------------------------
# Treating concepts as independent dimensions is wrong: it makes "the street
# lights are off" exactly orthogonal to "power has gone out", scoring 0.00,
# even though both are evidence of the same outage. We measured that failure.
#
# So each concept is given coordinates in a small space of latent FACTORS.
# Related concepts share factors, which yields graded relatedness instead of
# all-or-nothing matching, while remaining a proper inner-product space (so
# cosine similarity stays well defined and vectors stay cacheable).
#
# Read a row as: "how much does this concept load onto each underlying aspect
# of an electricity incident".
FACTORS: Tuple[str, ...] = (
    "outage_core",   # supply is absent / interrupted
    "area_scale",    # how many premises are involved
    "equipment",     # distribution hardware referenced
    "hazard",        # danger to people or property
    "persistence",   # duration / continuation
    "restoration",   # supply coming back
    "critical",      # critical premises involved
    "weather",       # environmental cause context
    "other_domain",  # explicitly not an electricity issue
)
FACTOR_INDEX: Dict[str, int] = {f: i for i, f in enumerate(FACTORS)}

CONCEPT_FACTORS: Dict[str, Dict[str, float]] = {
    "POWER_ABSENT":   {"outage_core": 1.00, "area_scale": 0.15},
    "AREA_WIDE":      {"outage_core": 0.55, "area_scale": 1.00},
    "STREETLIGHT":    {"outage_core": 0.70, "area_scale": 0.45, "equipment": 0.25},
    "EQUIPMENT":      {"outage_core": 0.50, "equipment": 1.00},
    "HAZARD":         {"hazard": 1.00, "equipment": 0.35, "outage_core": 0.20},
    # "power is still not back" is fundamentally a statement that supply is
    # ABSENT; persistence is the modifier, not the main claim. Loading it at
    # 0.65 made a natural follow-up report score 0.49 against the incident it
    # obviously belonged to, landing it a hair under the merge threshold.
    "PERSISTING":     {"outage_core": 0.85, "persistence": 1.00},
    "PARTIAL":        {"outage_core": 0.60, "persistence": 0.25},
    "RESTORED":       {"restoration": 1.00, "outage_core": 0.25},
    "WEATHER":        {"weather": 1.00, "outage_core": 0.25},
    "CRITICAL_INFRA": {"outage_core": 0.45, "area_scale": 0.50, "critical": 1.00},
    "NON_ELECTRICAL": {"other_domain": 1.00},
}


def factor_vector(concept: str) -> Tuple[float, ...]:
    """Coordinates of one concept in the latent factor space."""
    loads = CONCEPT_FACTORS.get(concept, {})
    return tuple(loads.get(f, 0.0) for f in FACTORS)


def concept_label(name: str) -> str:
    c = CONCEPTS.get(name)
    return c["label"] if c else name
