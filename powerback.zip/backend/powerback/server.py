"""
PowerBack HTTP server (Python standard library only).

WHY STDLIB RATHER THAN FASTAPI
------------------------------
FastAPI is the documented target stack and `api_fastapi.py` implements it. This
stdlib server exists because the prototype must start with:

    python -m powerback.server

on any Python 3.10+ machine, with no install step, no network access and no
dependency resolution. A hackathon demo that fails because a wheel could not be
fetched is a failed demo.

Both transports are thin: they parse the request, call `service`, and map
exceptions to status codes. All behaviour lives in the service layer, so the
two cannot drift.

Serves:
    /api/*      JSON API
    /media/*    uploaded evidence photos
    /*          the static frontend
"""
from __future__ import annotations

import json
import mimetypes
import os
import re
import sys
import threading
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, unquote, urlparse

from . import config, database, lifecycle, service
from .service import NotFound, ValidationError

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FRONTEND_DIR = os.environ.get(
    "PB_FRONTEND_DIR", os.path.join(os.path.dirname(BASE_DIR), "frontend"))
MEDIA_DIR = service.MEDIA_DIR

MAX_BODY_BYTES = 12 * 1024 * 1024  # generous enough for one photo, bounded

_write_lock = threading.Lock()


class ApiError(Exception):
    def __init__(self, status: int, message: str, **extra):
        self.status = status
        self.message = message
        self.extra = extra
        super().__init__(message)


def _route(method, path, handler_map):
    for pattern, methods in handler_map:
        m = pattern.match(path)
        if m:
            if method in methods:
                return methods[method], m.groupdict()
            raise ApiError(405, f"Method {method} is not allowed on {path}.")
    return None, None


# ===========================================================================
# API HANDLERS
# ===========================================================================
def h_health(body, q, p):
    return {"status": "ok", "database": database.get_db_path()}


def h_system(body, q, p):
    return service.system_info()


def h_stats(body, q, p):
    return service.stats()


def h_create_report(body, q, p):
    return service.submit_report(body or {})


def h_list_reports(body, q, p):
    return {"reports": service.list_reports(limit=int(q.get("limit", ["200"])[0]))}


def h_list_incidents(body, q, p):
    status = q.get("status", [None])[0]
    return {"incidents": service.list_incidents(status=status)}


def h_get_incident(body, q, p):
    return service.get_incident(p["ref"])


def h_explain(body, q, p):
    return service.explain_incident(p["ref"])


def h_create_response(body, q, p):
    return service.create_response(p["ref"], (body or {}).get("assigned_team"))


def h_restoration(body, q, p):
    body = body or {}
    source = body.get("source")
    status = body.get("status")
    if not source or not status:
        raise ValidationError("Both 'source' and 'status' are required.")
    return service.add_restoration_update(p["ref"], source, status, body.get("note"))


def h_verify(body, q, p):
    return service.verify_restoration(p["ref"])


def h_close(body, q, p):
    return service.close_incident(p["ref"], (body or {}).get("note"))


def h_update_ticket(body, q, p):
    body = body or {}
    return service.update_ticket(p["ref"], body.get("status"), body.get("assigned_team"))


def h_list_reviews(body, q, p):
    return {"reviews": service.list_reviews()}


def h_resolve_review(body, q, p):
    return service.resolve_review(int(p["link_id"]), (body or {}).get("action", ""))


def h_seed(body, q, p):
    from . import seed as seed_mod
    reset = bool((body or {}).get("reset", True))
    return seed_mod.seed(reset=reset)


ROUTES = [
    (re.compile(r"^/api/health$"), {"GET": h_health}),
    (re.compile(r"^/api/system$"), {"GET": h_system}),
    (re.compile(r"^/api/stats$"), {"GET": h_stats}),
    (re.compile(r"^/api/reports$"), {"POST": h_create_report, "GET": h_list_reports}),
    (re.compile(r"^/api/incidents$"), {"GET": h_list_incidents}),
    (re.compile(r"^/api/incidents/(?P<ref>[^/]+)$"), {"GET": h_get_incident}),
    (re.compile(r"^/api/incidents/(?P<ref>[^/]+)/explain$"),
     {"GET": h_explain, "POST": h_explain}),
    (re.compile(r"^/api/incidents/(?P<ref>[^/]+)/response$"), {"POST": h_create_response}),
    (re.compile(r"^/api/incidents/(?P<ref>[^/]+)/restoration$"), {"POST": h_restoration}),
    (re.compile(r"^/api/incidents/(?P<ref>[^/]+)/verify$"), {"POST": h_verify}),
    (re.compile(r"^/api/incidents/(?P<ref>[^/]+)/close$"), {"POST": h_close}),
    (re.compile(r"^/api/response-tickets/(?P<ref>[^/]+)$"),
     {"PATCH": h_update_ticket, "POST": h_update_ticket}),
    (re.compile(r"^/api/reviews$"), {"GET": h_list_reviews}),
    (re.compile(r"^/api/reviews/(?P<link_id>\d+)$"), {"POST": h_resolve_review}),
    (re.compile(r"^/api/demo/seed$"), {"POST": h_seed}),
]


class Handler(BaseHTTPRequestHandler):
    server_version = "PowerBack/1.0"
    protocol_version = "HTTP/1.1"

    # -- plumbing ---------------------------------------------------------
    def log_message(self, fmt, *args):
        if os.environ.get("PB_QUIET") != "1":
            sys.stderr.write("  %s - %s\n" % (self.address_string(), fmt % args))

    def _cors(self):
        origins = config.CORS_ALLOW_ORIGINS
        origin = self.headers.get("Origin")
        if "*" in origins:
            self.send_header("Access-Control-Allow-Origin", "*")
        elif origin and origin in origins:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,PATCH,OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def _send_json(self, status, payload):
        raw = json.dumps(payload, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self._cors()
        self.end_headers()
        self.wfile.write(raw)

    def _send_bytes(self, status, data, content_type):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self._cors()
        self.end_headers()
        self.wfile.write(data)

    def _read_body(self):
        length = self.headers.get("Content-Length")
        if not length:
            return None
        try:
            n = int(length)
        except ValueError:
            raise ApiError(400, "Invalid Content-Length header.")
        if n > MAX_BODY_BYTES:
            raise ApiError(413, f"Request body exceeds {MAX_BODY_BYTES} bytes.")
        if n <= 0:
            return None
        raw = self.rfile.read(n)
        try:
            return json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ApiError(400, f"Request body is not valid JSON ({exc}).")

    # -- verbs ------------------------------------------------------------
    def do_OPTIONS(self):
        self.send_response(204)
        self._cors()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self):
        self._handle("GET")

    def do_POST(self):
        self._handle("POST")

    def do_PATCH(self):
        self._handle("PATCH")

    def _handle(self, method):
        parsed = urlparse(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path.startswith("/api/"):
                handler, params = _route(method, path, ROUTES)
                if handler is None:
                    raise ApiError(404, f"No API route matches {path}.")
                body = self._read_body() if method in ("POST", "PATCH") else None
                # SQLite writes are serialised. The prototype favours obvious
                # correctness over write concurrency it will never need.
                if method in ("POST", "PATCH"):
                    with _write_lock:
                        result = handler(body, query, params)
                else:
                    result = handler(body, query, params)
                self._send_json(200, result)
                return
            if path.startswith("/media/"):
                self._serve_media(path[len("/media/"):])
                return
            self._serve_static(path)
        except ApiError as exc:
            self._send_json(exc.status, {"error": exc.message, **exc.extra})
        except ValidationError as exc:
            self._send_json(400, {"error": str(exc), "field": getattr(exc, "field", None)})
        except NotFound as exc:
            self._send_json(404, {"error": str(exc)})
        except lifecycle.TransitionError as exc:
            self._send_json(409, {"error": str(exc), "type": "invalid_transition"})
        except Exception as exc:
            from .abuse import RateLimitExceeded
            if isinstance(exc, RateLimitExceeded):
                self._send_json(429, {
                    "error": str(exc),
                    "retry_after_minutes": round(exc.retry_after_min, 1),
                })
                return
            # Log the real traceback server-side; return a safe message.
            traceback.print_exc()
            self._send_json(500, {
                "error": "An internal error occurred while processing the request.",
            })

    # -- static files -----------------------------------------------------
    def _safe_join(self, root, relative):
        """Resolve a path inside root, refusing traversal outside it."""
        target = os.path.normpath(os.path.join(root, relative.lstrip("/")))
        root_abs = os.path.abspath(root)
        if not os.path.abspath(target).startswith(root_abs + os.sep) \
                and os.path.abspath(target) != root_abs:
            raise ApiError(403, "Forbidden path.")
        return target

    def _serve_media(self, relative):
        if not relative:
            raise ApiError(404, "Not found.")
        target = self._safe_join(MEDIA_DIR, relative)
        if not os.path.isfile(target):
            raise ApiError(404, "Evidence file not found.")
        ctype = mimetypes.guess_type(target)[0] or "application/octet-stream"
        with open(target, "rb") as fh:
            self._send_bytes(200, fh.read(), ctype)

    def _serve_static(self, path):
        if path in ("", "/"):
            path = "/index.html"
        target = self._safe_join(FRONTEND_DIR, path)
        if os.path.isdir(target):
            target = os.path.join(target, "index.html")
        if not os.path.isfile(target):
            # Single-page app: unknown non-asset paths fall back to index.html.
            if "." not in os.path.basename(path):
                target = os.path.join(FRONTEND_DIR, "index.html")
            if not os.path.isfile(target):
                raise ApiError(404, "Not found.")
        ctype = mimetypes.guess_type(target)[0] or "application/octet-stream"
        if ctype.startswith("text/") or ctype in ("application/javascript",
                                                  "application/json"):
            ctype += "; charset=utf-8"
        with open(target, "rb") as fh:
            self._send_bytes(200, fh.read(), ctype)


def create_server(host="127.0.0.1", port=8000):
    database.init_db()
    os.makedirs(MEDIA_DIR, exist_ok=True)
    return ThreadingHTTPServer((host, port), Handler)


def main():
    host = os.environ.get("PB_HOST", "127.0.0.1")
    port = int(os.environ.get("PORT", os.environ.get("PB_PORT", "8000")))
    httpd = create_server(host, port)
    from . import semantic
    info = semantic.describe()
    print("=" * 66)
    print("  PowerBack  -- from scattered signals to coordinated response")
    print("=" * 66)
    print(f"  Server     : http://{host}:{port}")
    print(f"  Database   : {database.get_db_path()}")
    print(f"  Semantic   : {info['backend']} ({'neural' if info['is_neural'] else 'vector-space'})")
    print(f"  Frontend   : {FRONTEND_DIR}")
    print("  Stop with Ctrl+C")
    print("=" * 66)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down.")
        httpd.shutdown()


if __name__ == "__main__":
    main()
