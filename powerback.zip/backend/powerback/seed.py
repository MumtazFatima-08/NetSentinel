"""
Synthetic demo dataset.

CLEARLY LABELLED AS SYNTHETIC. These are fabricated reports written for
demonstration. They are not real citizen submissions, and no real outage,
utility, location or statistic is represented.

The reports are fed through the REAL intake pipeline (`service.submit_report`).
Nothing about the resulting incidents is hardcoded: the incident numbers,
correlation confidences, priorities and groupings are whatever the engine
computes. Re-running the seed re-derives everything from scratch.

Scenarios
---------
A  Five reports on one street within ~15 minutes -> should correlate into ONE
   incident. This is the primary demo.

B  Reports from a different street ~1.1 km away, later -> should form a
   SEPARATE incident, demonstrating that PowerBack does not blindly merge.

C  A near-duplicate resubmission and a non-electrical complaint -> demonstrates
   duplicate detection and robustness to noise.

D  A safety hazard reported at the same place and time as the Scenario A
   outage -> genuinely ambiguous, so the engine routes it to HUMAN REVIEW
   rather than guessing. Confirming it escalates the incident's priority.
"""
from __future__ import annotations

from datetime import timedelta
from typing import Any, Dict, List

from . import service
from .database import reset_db
from .util import now, to_iso

# Anchor coordinates for the synthetic locality (a fictional demo area).
STREET_A = (17.44970, 78.53920)
STREET_B = (17.45810, 78.54760)


def _offset(base, dlat_m: float, dlon_m: float):
    """Shift a coordinate by an approximate metre offset."""
    import math
    dlat = dlat_m / 111_320.0
    dlon = dlon_m / (111_320.0 * math.cos(math.radians(base[0])))
    return (round(base[0] + dlat, 6), round(base[1] + dlon, 6))


def build_scenarios(t0=None) -> Dict[str, List[Dict[str, Any]]]:
    """Construct the synthetic report payloads with relative timestamps."""
    base = t0 or (now() - timedelta(minutes=40))

    scenario_a = [
        {"description": "Power has gone out on our street.",
         "coords": _offset(STREET_A, 0, 0), "minute": 0, "session": "demo-a1"},
        {"description": "Several houses on this road have no electricity.",
         "coords": _offset(STREET_A, 60, 40), "minute": 2, "session": "demo-a2"},
        {"description": "The street lights are also off.",
         "coords": _offset(STREET_A, -50, 90), "minute": 5, "session": "demo-a3"},
        {"description": "Power is still not back.",
         "coords": _offset(STREET_A, 120, -30), "minute": 9, "session": "demo-a4"},
        {"description": "The transformer area appears to be affected.",
         "coords": _offset(STREET_A, 30, 150), "minute": 15, "session": "demo-a5"},
    ]

    scenario_b = [
        {"description": "No electricity in our building since a few minutes ago.",
         "coords": _offset(STREET_B, 0, 0), "minute": 22, "session": "demo-b1"},
        {"description": "The whole block here is without power.",
         "coords": _offset(STREET_B, 70, 50), "minute": 25, "session": "demo-b2"},
    ]

    # Scenario D -- an observation that is genuinely AMBIGUOUS: a safety hazard
    # at the same place and time as an active outage. It could be the cause of
    # this incident, or an unrelated second event. The engine should decline to
    # decide and route it to a human.
    scenario_d = [
        {"description": "Sparks near the pole at the corner.",
         "coords": _offset(STREET_A, 80, 110), "minute": 11, "session": "demo-d1"},
    ]

    scenario_c = [
        # Same session, same place, same wording, minutes later -> duplicate.
        {"description": "Power has gone out on our street.",
         "coords": _offset(STREET_A, 5, 5), "minute": 12, "session": "demo-a1"},
        # Non-electrical complaint in the same area -> must not merge.
        {"description": "There is a water leak on the main road near our house.",
         "coords": _offset(STREET_A, 40, 60), "minute": 17, "session": "demo-c1"},
    ]

    def materialise(items):
        out = []
        for it in items:
            lat, lon = it["coords"]
            out.append({
                "description": it["description"],
                "latitude": lat,
                "longitude": lon,
                "occurred_at": to_iso(base + timedelta(minutes=it["minute"])),
                "session_id": it["session"],
            })
        return out

    return {
        "A": materialise(scenario_a),
        "B": materialise(scenario_b),
        "C": materialise(scenario_c),
        "D": materialise(scenario_d),
    }


def seed(reset: bool = True, conn=None, scenarios=("A", "B", "D", "C")) -> dict:
    """
    Load the synthetic dataset through the real pipeline.

    Returns a summary of what the ENGINE decided -- not a scripted result.
    """
    if reset:
        conn = reset_db()
    conn = conn or service.connect()

    data = build_scenarios()

    # Submit in TRUE CHRONOLOGICAL ORDER across all scenarios, exactly as a
    # live system would receive them. Processing scenario-by-scenario would
    # let a later report influence an earlier one and would not reflect how
    # the engine behaves in production.
    queue = []
    for key in scenarios:
        for payload in data.get(key, []):
            queue.append((payload["occurred_at"], key, payload))
    queue.sort(key=lambda x: x[0])

    results: Dict[str, List[dict]] = {k: [] for k in scenarios}
    for _, key, payload in queue:
            outcome = service.submit_report(payload, conn=conn)
            results[key].append({
                "report": outcome["report"]["public_id"],
                "description": payload["description"],
                "decision": (outcome["correlation"] or {}).get("decision", "DUPLICATE"),
                "confidence": (outcome["correlation"] or {}).get("confidence"),
                "incident": (outcome["incident"] or {}).get("public_id"),
                "duplicate_of": (outcome.get("duplicate_of") or {}).get("public_id"),
            })

    return {
        "seeded": {k: len(v) for k, v in results.items()},
        "results": results,
        "stats": service.stats(conn=conn),
        "incidents": [
            {"public_id": i["public_id"], "priority": i["priority"],
             "report_count": i["report_count"], "status": i["status"],
             "correlation_confidence": i["correlation_confidence"]}
            for i in service.list_incidents(conn=conn)
        ],
        "note": ("Synthetic demonstration data. All groupings, confidences and "
                 "priorities were computed by the engine at seed time."),
    }


if __name__ == "__main__":
    import json
    print(json.dumps(seed(), indent=2))
