"""
Persistence layer (SQLite).

SQLite is used because the prototype must run anywhere with zero setup and no
service dependency. The access layer is plain parameterised SQL with a thin
connection helper, so moving to PostgreSQL means changing the DSN and a small
number of type declarations -- no ORM lock-in, no query rewriting.

Every query in this codebase is parameterised. No string interpolation of user
input into SQL, anywhere.
"""
from __future__ import annotations

import json
import os
import sqlite3
import threading
from contextlib import contextmanager
from typing import Any, Dict, Iterable, List, Optional

from . import config

_local = threading.local()

SCHEMA = """
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS reports (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id         TEXT    NOT NULL UNIQUE,
    description       TEXT    NOT NULL,
    latitude          REAL,
    longitude         REAL,
    occurred_at       TEXT    NOT NULL,
    created_at        TEXT    NOT NULL,
    session_id        TEXT,
    photo_path        TEXT,
    photo_mime        TEXT,
    photo_bytes       INTEGER,
    extracted_signals TEXT    NOT NULL DEFAULT '{}',
    embedding         BLOB,
    status            TEXT    NOT NULL DEFAULT 'ACCEPTED',
    flags             TEXT    NOT NULL DEFAULT '[]'
);
CREATE INDEX IF NOT EXISTS idx_reports_time   ON reports(occurred_at);
CREATE INDEX IF NOT EXISTS idx_reports_lat    ON reports(latitude);
CREATE INDEX IF NOT EXISTS idx_reports_lon    ON reports(longitude);
CREATE INDEX IF NOT EXISTS idx_reports_sess   ON reports(session_id, created_at);

CREATE TABLE IF NOT EXISTS incidents (
    id                     INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id              TEXT    NOT NULL UNIQUE,
    status                 TEXT    NOT NULL,
    priority               TEXT,
    priority_score         REAL    NOT NULL DEFAULT 0,
    priority_reasons       TEXT    NOT NULL DEFAULT '[]',
    correlation_confidence REAL    NOT NULL DEFAULT 0,
    centroid_latitude      REAL,
    centroid_longitude     REAL,
    affected_radius_m      REAL    NOT NULL DEFAULT 0,
    first_seen             TEXT    NOT NULL,
    last_seen              TEXT    NOT NULL,
    report_count           INTEGER NOT NULL DEFAULT 0,
    evidence_summary       TEXT    NOT NULL DEFAULT '{}',
    symptoms               TEXT    NOT NULL DEFAULT '[]',
    hazard_flag            INTEGER NOT NULL DEFAULT 0,
    recommended_action     TEXT,
    restoration_confidence REAL    NOT NULL DEFAULT 0,
    needs_review           INTEGER NOT NULL DEFAULT 0,
    created_at             TEXT    NOT NULL,
    updated_at             TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_incidents_status ON incidents(status);
CREATE INDEX IF NOT EXISTS idx_incidents_seen   ON incidents(last_seen);
CREATE INDEX IF NOT EXISTS idx_incidents_lat    ON incidents(centroid_latitude);
CREATE INDEX IF NOT EXISTS idx_incidents_lon    ON incidents(centroid_longitude);

CREATE TABLE IF NOT EXISTS incident_reports (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    incident_id   INTEGER NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
    report_id     INTEGER NOT NULL REFERENCES reports(id)   ON DELETE CASCADE,
    match_score   REAL    NOT NULL DEFAULT 0,
    match_reasons TEXT    NOT NULL DEFAULT '{}',
    link_type     TEXT    NOT NULL DEFAULT 'MERGED',
    created_at    TEXT    NOT NULL,
    UNIQUE(incident_id, report_id)
);
CREATE INDEX IF NOT EXISTS idx_ir_incident ON incident_reports(incident_id);
CREATE INDEX IF NOT EXISTS idx_ir_report   ON incident_reports(report_id);

CREATE TABLE IF NOT EXISTS response_tickets (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    public_id          TEXT    NOT NULL UNIQUE,
    incident_id        INTEGER NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
    status             TEXT    NOT NULL,
    priority           TEXT,
    assigned_team      TEXT,
    recommended_action TEXT,
    brief              TEXT,
    created_at         TEXT    NOT NULL,
    updated_at         TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_tickets_incident ON response_tickets(incident_id);
CREATE INDEX IF NOT EXISTS idx_tickets_status   ON response_tickets(status);

CREATE TABLE IF NOT EXISTS restoration_updates (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    incident_id INTEGER NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
    source      TEXT    NOT NULL,
    status      TEXT    NOT NULL,
    note        TEXT,
    confidence  REAL    NOT NULL DEFAULT 0,
    created_at  TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_restore_incident ON restoration_updates(incident_id);

CREATE TABLE IF NOT EXISTS audit_logs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    entity_type TEXT NOT NULL,
    entity_id   TEXT NOT NULL,
    action      TEXT NOT NULL,
    detail      TEXT NOT NULL DEFAULT '{}',
    actor       TEXT,
    created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_logs(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_time   ON audit_logs(created_at);
"""


def get_db_path() -> str:
    return os.environ.get("PB_DB_PATH", config.DB_PATH)


def connect(path: Optional[str] = None) -> sqlite3.Connection:
    """Per-thread connection. SQLite objects are not shareable across threads."""
    target = path or get_db_path()
    existing = getattr(_local, "conn", None)
    if existing is not None and getattr(_local, "path", None) == target:
        return existing
    if existing is not None:
        try:
            existing.close()
        except Exception:
            pass
    conn = sqlite3.connect(target, timeout=15.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    _local.conn = conn
    _local.path = target
    return conn


def close() -> None:
    conn = getattr(_local, "conn", None)
    if conn is not None:
        try:
            conn.close()
        finally:
            _local.conn = None
            _local.path = None


def init_db(path: Optional[str] = None) -> sqlite3.Connection:
    conn = connect(path)
    conn.executescript(SCHEMA)
    conn.commit()
    return conn


def reset_db(path: Optional[str] = None) -> sqlite3.Connection:
    """Drop everything and recreate. Used by the seeder and the test suite."""
    conn = connect(path)
    for table in ("audit_logs", "restoration_updates", "response_tickets",
                  "incident_reports", "incidents", "reports"):
        conn.execute(f"DROP TABLE IF EXISTS {table}")
    conn.commit()
    conn.executescript(SCHEMA)
    conn.commit()
    return conn


@contextmanager
def transaction(path: Optional[str] = None):
    """Atomic unit of work. Rolls back on any exception."""
    conn = connect(path)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise


# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------
def rows_to_dicts(rows: Iterable[sqlite3.Row]) -> List[Dict[str, Any]]:
    return [dict(r) for r in rows]


def jload(value: Any, default: Any) -> Any:
    if value is None or value == "":
        return default
    if isinstance(value, (dict, list)):
        return value
    try:
        return json.loads(value)
    except (TypeError, ValueError):
        return default


def jdump(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, default=str)
