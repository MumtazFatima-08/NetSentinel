"""Geospatial helpers. Pure functions, no external services, no API keys."""
from __future__ import annotations

import math
from typing import Iterable, Optional, Sequence, Tuple

EARTH_RADIUS_M = 6_371_008.8


def haversine_m(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance between two WGS84 points, in metres."""
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlam = math.radians(lon2 - lon1)
    a = (math.sin(dphi / 2) ** 2
         + math.cos(p1) * math.cos(p2) * math.sin(dlam / 2) ** 2)
    return 2 * EARTH_RADIUS_M * math.asin(math.sqrt(min(1.0, a)))


def centroid(points: Sequence[Tuple[float, float]]) -> Optional[Tuple[float, float]]:
    """
    Mean position of (lat, lon) points, computed in 3D to stay correct across
    the antimeridian and at high latitude.
    """
    pts = [p for p in points if p is not None and p[0] is not None and p[1] is not None]
    if not pts:
        return None
    x = y = z = 0.0
    for lat, lon in pts:
        rlat, rlon = math.radians(lat), math.radians(lon)
        x += math.cos(rlat) * math.cos(rlon)
        y += math.cos(rlat) * math.sin(rlon)
        z += math.sin(rlat)
    n = len(pts)
    x, y, z = x / n, y / n, z / n
    hyp = math.sqrt(x * x + y * y)
    if hyp < 1e-12 and abs(z) < 1e-12:
        return pts[0]
    return (math.degrees(math.atan2(z, hyp)), math.degrees(math.atan2(y, x)))


def affected_radius_m(
    points: Sequence[Tuple[float, float]],
    center: Optional[Tuple[float, float]] = None,
    floor_m: float = 60.0,
) -> float:
    """
    Radius of the affected zone: the distance from the centroid to the furthest
    contributing report, with a small floor so a single-report incident still
    renders a sensible zone on the map.
    """
    pts = [p for p in points if p is not None and p[0] is not None and p[1] is not None]
    if not pts:
        return floor_m
    c = center or centroid(pts)
    if c is None:
        return floor_m
    furthest = max(haversine_m(c[0], c[1], lat, lon) for lat, lon in pts)
    return max(floor_m, round(furthest, 1))


def bounding_box(lat: float, lon: float, radius_m: float) -> Tuple[float, float, float, float]:
    """
    Cheap lat/lon envelope around a point. Used to pre-filter candidates with an
    indexed SQL range query BEFORE running exact haversine -- this is what keeps
    candidate selection from becoming a full table scan as data grows.

    Returns (min_lat, max_lat, min_lon, max_lon).
    """
    dlat = math.degrees(radius_m / EARTH_RADIUS_M)
    coslat = math.cos(math.radians(lat))
    if abs(coslat) < 1e-9:
        dlon = 180.0
    else:
        dlon = math.degrees(radius_m / (EARTH_RADIUS_M * coslat))
    return (lat - dlat, lat + dlat, lon - dlon, lon + dlon)


def spatial_score(distance_m: float, decay_m: float) -> float:
    """
    Gaussian decay: 1.0 at zero distance, ~0.37 at one decay length,
    approaching 0 well beyond it. Smooth and explainable.
    """
    if distance_m <= 0:
        return 1.0
    return float(math.exp(-((distance_m / decay_m) ** 2)))


def project_points(
    points: Iterable[Tuple[float, float]],
    width: float,
    height: float,
    padding: float = 0.12,
):
    """
    Equirectangular projection of lat/lon into an SVG viewport, preserving
    aspect ratio. Powers the built-in map renderer so the frontend needs no
    external tile service and no API key.

    Returns (list_of_xy, transform_callable).
    """
    pts = [p for p in points if p and p[0] is not None and p[1] is not None]
    if not pts:
        return [], lambda lat, lon: (width / 2, height / 2)

    lats = [p[0] for p in pts]
    lons = [p[1] for p in pts]
    clat = sum(lats) / len(lats)
    k = math.cos(math.radians(clat)) or 1e-6

    xs = [lon * k for lon in lons]
    ys = [-lat for lat in lats]
    minx, maxx = min(xs), max(xs)
    miny, maxy = min(ys), max(ys)
    spanx = maxx - minx
    spany = maxy - miny
    span = max(spanx, spany, 1e-7) * (1 + padding * 2)
    cx = (minx + maxx) / 2
    cy = (miny + maxy) / 2
    size = min(width, height)

    def transform(lat: float, lon: float):
        x = (lon * k - cx) / span * size + width / 2
        y = (-lat - cy) / span * size + height / 2
        return (x, y)

    return [transform(lat, lon) for lat, lon in pts], transform
