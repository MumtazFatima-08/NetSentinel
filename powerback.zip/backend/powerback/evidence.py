"""
Evidence handling (photos).

HONESTY STATEMENT -- PLEASE READ
================================

PowerBack does NOT run a computer-vision classifier on citizen photos, and it
therefore never produces an image-derived confidence number, never claims to
have "detected a damaged transformer in the image", and never lets an image
influence the correlation score with a fabricated value.

The original design called for visual evidence extraction. We could not
implement a vision pipeline that was actually reliable in this environment
(no model weights are reachable, and a hand-rolled classifier on outage photos
would produce numbers we could not defend). Per the project's own rule -- do
not fabricate AI results -- we did the honest thing:

  * the photo is validated, stored and preserved as evidence
  * the photo is surfaced to a human reviewer in the incident detail screen
  * having a photo RAISES the incident's priority, because a human should
    look at it -- that is a rule, and we label it as a rule
  * the photo never becomes a machine-made claim about its contents

The interface below is deliberately shaped so a real vision model can be
dropped in later: implement `analyze()` in a subclass, return concepts with
genuine confidences, and the rest of the system consumes them unchanged.
Until then `analyze()` reports `available: False` and the product says so.

Everything else in PowerBack works without image analysis.
"""
from __future__ import annotations

import base64
import binascii
import hashlib
import os
from typing import Any, Dict, Optional, Tuple

from . import config

# Magic-number signatures. We validate the actual bytes rather than trusting a
# client-supplied MIME type or file extension.
_SIGNATURES: Tuple[Tuple[bytes, str], ...] = (
    (b"\xff\xd8\xff", "image/jpeg"),
    (b"\x89PNG\r\n\x1a\n", "image/png"),
)


class EvidenceError(ValueError):
    """Raised when submitted evidence fails validation."""


def sniff_mime(data: bytes) -> Optional[str]:
    """Identify image type from magic bytes. Returns None if unrecognised."""
    for sig, mime in _SIGNATURES:
        if data.startswith(sig):
            return mime
    # WebP: "RIFF" .... "WEBP"
    if len(data) >= 12 and data[0:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    return None


def decode_data_url(value: str) -> bytes:
    """Accept a raw base64 string or a full `data:image/...;base64,...` URL."""
    if not value:
        raise EvidenceError("Empty image payload.")
    payload = value.strip()
    if payload.startswith("data:"):
        if "," not in payload:
            raise EvidenceError("Malformed data URL.")
        payload = payload.split(",", 1)[1]
    try:
        return base64.b64decode(payload, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise EvidenceError(f"Image is not valid base64 data ({exc}).") from exc


def validate_and_store(
    b64_or_dataurl: str,
    storage_dir: str,
    declared_mime: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Validate an uploaded image and persist it.

    Validation order matters: size is checked BEFORE the bytes are inspected,
    and the true type is sniffed from content rather than trusting the client.
    """
    data = decode_data_url(b64_or_dataurl)

    if not data:
        raise EvidenceError("Image payload decoded to zero bytes.")
    if len(data) > config.PHOTO_MAX_BYTES:
        limit_mb = config.PHOTO_MAX_BYTES / (1024 * 1024)
        raise EvidenceError(
            f"Image is {len(data) / (1024 * 1024):.1f} MB, which exceeds the "
            f"{limit_mb:.0f} MB limit.")

    actual_mime = sniff_mime(data)
    if actual_mime is None:
        raise EvidenceError(
            "File is not a recognised image. Accepted formats: JPEG, PNG, WebP.")
    if actual_mime not in config.PHOTO_ALLOWED_TYPES:
        raise EvidenceError(f"Image type '{actual_mime}' is not accepted.")
    if declared_mime and declared_mime != actual_mime:
        # Not fatal -- the real type wins -- but worth recording.
        pass

    digest = hashlib.sha256(data).hexdigest()
    ext = {"image/jpeg": "jpg", "image/png": "png", "image/webp": "webp"}[actual_mime]
    os.makedirs(storage_dir, exist_ok=True)
    filename = f"{digest[:24]}.{ext}"
    path = os.path.join(storage_dir, filename)
    if not os.path.exists(path):
        with open(path, "wb") as fh:
            fh.write(data)

    return {
        "photo_path": filename,
        "photo_mime": actual_mime,
        "photo_bytes": len(data),
        "sha256": digest,
    }


def analyze(photo_path: Optional[str]) -> Dict[str, Any]:
    """
    Vision analysis hook.

    Returns `available: False` in this build. It does NOT return a made-up
    confidence. Any future implementation must return real model outputs or
    keep reporting unavailable.
    """
    return {
        "available": False,
        "has_photo": bool(photo_path),
        "concepts": [],
        "confidence": None,
        "method": None,
        "note": (
            "Automated image analysis is not enabled in this build. The photo is "
            "preserved as evidence for human review and is not converted into a "
            "machine-generated claim about its contents."
        ),
    }


def describe() -> dict:
    """Capability report surfaced at GET /api/system so the UI cannot overclaim."""
    return {
        "vision_enabled": False,
        "photo_storage": "local filesystem",
        "max_bytes": config.PHOTO_MAX_BYTES,
        "allowed_types": list(config.PHOTO_ALLOWED_TYPES),
        "validation": "magic-byte content sniffing (declared MIME is not trusted)",
        "note": (
            "Photos are validated, stored and shown to human reviewers. No "
            "automated visual classification is performed and no image-derived "
            "confidence values are generated."
        ),
    }
