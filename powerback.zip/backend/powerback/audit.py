"""Audit trail for state changes and significant system actions."""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from .database import jdump, jload
from .util import to_iso


def log(conn, entity_type: str, entity_id: Any, action: str,
        detail: Optional[Dict[str, Any]] = None, actor: str = "system") -> None:
    conn.execute(
        "INSERT INTO audit_logs (entity_type, entity_id, action, detail, actor, created_at) "
        "VALUES (?,?,?,?,?,?)",
        (entity_type, str(entity_id), action, jdump(detail or {}), actor, to_iso()))


def for_entity(conn, entity_type: str, entity_id: Any, limit: int = 200) -> List[dict]:
    rows = conn.execute(
        "SELECT * FROM audit_logs WHERE entity_type = ? AND entity_id = ? "
        "ORDER BY id ASC LIMIT ?",
        (entity_type, str(entity_id), limit)).fetchall()
    return [{
        "action": r["action"],
        "actor": r["actor"],
        "detail": jload(r["detail"], {}),
        "created_at": r["created_at"],
    } for r in rows]


def recent(conn, limit: int = 100) -> List[dict]:
    rows = conn.execute(
        "SELECT * FROM audit_logs ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [{
        "entity_type": r["entity_type"],
        "entity_id": r["entity_id"],
        "action": r["action"],
        "actor": r["actor"],
        "detail": jload(r["detail"], {}),
        "created_at": r["created_at"],
    } for r in rows]
