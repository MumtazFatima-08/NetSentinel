"""
Abuse, spam and duplicate protection for citizen reports.

A public reporting endpoint is an obvious target. The controls here are sized
for a prototype but they are real: they run on every submission and they are
enforced in the service layer, not merely advertised.

Design rule that matters more than any single control:
a report flagged as suspicious is STILL STORED, but it is prevented from
escalating priority or triggering physical response on its own. Silently
dropping citizen reports would be worse than storing and flagging them -- a
real outage report from an unusual client is not spam.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from . import config, semantic
from .geo import haversine_m
from .util import minutes_between, now, parse_time

# Report status values
ACCEPTED = "ACCEPTED"
DUPLICATE = "DUPLICATE"
RATE_LIMITED = "RATE_LIMITED"
FLAGGED = "FLAGGED"


class RateLimitExceeded(Exception):
    """Raised when a session exceeds the submission rate limit."""

    def __init__(self, retry_after_min: float, limit: int, window_min: float):
        self.retry_after_min = retry_after_min
        self.limit = limit
        self.window_min = window_min
        super().__init__(
            f"Rate limit reached: at most {limit} reports per "
            f"{window_min:.0f} minutes. Try again in about "
            f"{max(1, round(retry_after_min))} minute(s).")


def check_rate_limit(conn, session_id: Optional[str]) -> None:
    """Raise RateLimitExceeded if this session has submitted too frequently."""
    if not session_id:
        return
    rows = conn.execute(
        "SELECT created_at FROM reports WHERE session_id = ? "
        "ORDER BY created_at DESC LIMIT ?",
        (session_id, config.RATE_LIMIT_MAX_REPORTS)).fetchall()
    if len(rows) < config.RATE_LIMIT_MAX_REPORTS:
        return
    oldest = parse_time(rows[-1]["created_at"])
    elapsed = minutes_between(now(), oldest)
    if elapsed < config.RATE_LIMIT_WINDOW_MIN:
        raise RateLimitExceeded(
            retry_after_min=config.RATE_LIMIT_WINDOW_MIN - elapsed,
            limit=config.RATE_LIMIT_MAX_REPORTS,
            window_min=config.RATE_LIMIT_WINDOW_MIN)


def find_duplicate(conn, report: Dict[str, Any], vector) -> Optional[dict]:
    """
    Detect a near-identical resubmission.

    A duplicate must match on all three axes -- same session, close in time,
    close in space, and near-identical text. Requiring all four guards against
    wrongly discarding two genuinely different neighbours who happen to phrase
    an outage the same way, which is extremely common ("no power").
    """
    session = report.get("session_id")
    if not session:
        return None

    rows = conn.execute(
        "SELECT id, public_id, description, latitude, longitude, occurred_at, "
        "embedding FROM reports WHERE session_id = ? AND status != ? "
        "ORDER BY created_at DESC LIMIT 20",
        (session, DUPLICATE)).fetchall()

    when = parse_time(report["occurred_at"])
    lat, lon = report.get("latitude"), report.get("longitude")

    for row in rows:
        if minutes_between(when, parse_time(row["occurred_at"])) > config.DUPLICATE_WINDOW_MIN:
            continue
        if (lat is not None and lon is not None
                and row["latitude"] is not None and row["longitude"] is not None):
            if haversine_m(lat, lon, row["latitude"], row["longitude"]) > config.DUPLICATE_RADIUS_M:
                continue
        other = semantic.blob_to_vector(row["embedding"])
        if other is None:
            other = semantic.encode_one(row["description"])
        similarity = semantic.cosine(vector, other)
        if similarity >= config.DUPLICATE_SIMILARITY:
            return {
                "report_id": row["id"],
                "public_id": row["public_id"],
                "similarity": round(similarity, 4),
                "description": row["description"],
            }
    return None


def suspicion_flags(conn, report: Dict[str, Any], signals: Dict[str, Any]) -> List[str]:
    """
    Non-fatal quality flags. These are recorded on the report and shown to
    reviewers; they do not by themselves discard anything.
    """
    flags: List[str] = []
    text = (report.get("description") or "").strip()

    if len(text) < 12:
        flags.append("VERY_SHORT_DESCRIPTION")
    if text and sum(c.isalpha() for c in text) / max(len(text), 1) < 0.45:
        flags.append("LOW_ALPHABETIC_CONTENT")
    if text and len(set(text.lower().split())) <= 1 and len(text.split()) > 3:
        flags.append("REPEATED_TOKEN")
    if report.get("latitude") is None or report.get("longitude") is None:
        flags.append("NO_LOCATION")
    if signals.get("is_non_electrical"):
        flags.append("POSSIBLY_NOT_ELECTRICAL")
    if not signals.get("indicates_outage") and not signals.get("has_hazard"):
        flags.append("NO_RECOGNISED_OUTAGE_SIGNAL")

    # Burst from one session in a very short window.
    session = report.get("session_id")
    if session:
        recent = conn.execute(
            "SELECT created_at FROM reports WHERE session_id = ? "
            "ORDER BY created_at DESC LIMIT 5", (session,)).fetchall()
        if len(recent) >= 5:
            span = minutes_between(now(), parse_time(recent[-1]["created_at"]))
            if span < 2.0:
                flags.append("RAPID_BURST")
    return flags


def is_trustworthy(flags: List[str]) -> bool:
    """
    Whether a report may contribute to priority escalation and response.

    Flagged reports are still stored and still visible; they are simply not
    allowed to drive an automatic dispatch on their own.
    """
    blocking = {"REPEATED_TOKEN", "LOW_ALPHABETIC_CONTENT", "RAPID_BURST",
                "POSSIBLY_NOT_ELECTRICAL"}
    return not (blocking & set(flags))


def describe() -> dict:
    return {
        "rate_limit": {
            "max_reports": config.RATE_LIMIT_MAX_REPORTS,
            "window_minutes": config.RATE_LIMIT_WINDOW_MIN,
        },
        "duplicate_detection": {
            "similarity_threshold": config.DUPLICATE_SIMILARITY,
            "window_minutes": config.DUPLICATE_WINDOW_MIN,
            "radius_m": config.DUPLICATE_RADIUS_M,
        },
        "policy": (
            "Suspicious reports are stored and flagged for review, never silently "
            "discarded, and are excluded from automatic priority escalation."
        ),
    }
