"""
Incident and ticket lifecycle state machines.

Transitions are explicit and validated. An invalid transition is rejected with
a clear error rather than silently applied -- an incident that can jump from
NEW_SIGNALS straight to CLOSED is an incident that can hide an unresolved
outage.
"""
from __future__ import annotations

from typing import Dict, List, Tuple


class TransitionError(ValueError):
    """Raised when a requested state transition is not permitted."""


# ---------------------------------------------------------------------------
# INCIDENT STATES
# ---------------------------------------------------------------------------
NEW_SIGNALS = "NEW_SIGNALS"
INCIDENT_DETECTED = "INCIDENT_DETECTED"
VALIDATING = "VALIDATING"
PRIORITIZED = "PRIORITIZED"
RESPONSE_CREATED = "RESPONSE_CREATED"
ASSIGNED = "ASSIGNED"
FIELD_ACTION = "FIELD_ACTION"
RESTORATION_PENDING = "RESTORATION_PENDING"
RESTORED = "RESTORED"
VERIFICATION = "VERIFICATION"
CLOSED = "CLOSED"

INCIDENT_STATES: Tuple[str, ...] = (
    NEW_SIGNALS, INCIDENT_DETECTED, VALIDATING, PRIORITIZED, RESPONSE_CREATED,
    ASSIGNED, FIELD_ACTION, RESTORATION_PENDING, RESTORED, VERIFICATION, CLOSED,
)

INCIDENT_TRANSITIONS: Dict[str, Tuple[str, ...]] = {
    NEW_SIGNALS:         (INCIDENT_DETECTED, CLOSED),
    INCIDENT_DETECTED:   (VALIDATING, PRIORITIZED, CLOSED),
    VALIDATING:          (PRIORITIZED, INCIDENT_DETECTED, CLOSED),
    # An incident can gather more reports and be re-prioritised in place.
    PRIORITIZED:         (RESPONSE_CREATED, PRIORITIZED, VALIDATING,
                          RESTORATION_PENDING, CLOSED),
    # RESTORATION_PENDING is reachable directly: supply is often restored
    # before a crew is formally assigned (the utility fixed it independently,
    # or citizens report it back). Forcing the workflow through ASSIGNED would
    # strand such incidents in RESPONSE_CREATED forever.
    RESPONSE_CREATED:    (ASSIGNED, PRIORITIZED, RESTORATION_PENDING, CLOSED),
    ASSIGNED:            (FIELD_ACTION, RESTORATION_PENDING, CLOSED),
    FIELD_ACTION:        (RESTORATION_PENDING, RESTORED, CLOSED),
    RESTORATION_PENDING: (RESTORED, VERIFICATION, FIELD_ACTION, CLOSED),
    # Verification can fail and send the incident back to field action.
    RESTORED:            (VERIFICATION, CLOSED, FIELD_ACTION),
    VERIFICATION:        (CLOSED, FIELD_ACTION, RESTORATION_PENDING),
    CLOSED:              (),
}

# States in which the incident is still operationally open.
ACTIVE_INCIDENT_STATES = tuple(
    s for s in INCIDENT_STATES if s not in (CLOSED, RESTORED, VERIFICATION))


# ---------------------------------------------------------------------------
# RESPONSE TICKET STATES
# ---------------------------------------------------------------------------
AWAITING_DISPATCH = "AWAITING_DISPATCH"
TICKET_ASSIGNED = "ASSIGNED"
TICKET_FIELD_ACTION = "FIELD_ACTION"
TICKET_RESTORATION_PENDING = "RESTORATION_PENDING"
TICKET_RESTORED = "RESTORED"
TICKET_VERIFIED = "VERIFIED"
TICKET_CLOSED = "CLOSED"

TICKET_STATES: Tuple[str, ...] = (
    AWAITING_DISPATCH, TICKET_ASSIGNED, TICKET_FIELD_ACTION,
    TICKET_RESTORATION_PENDING, TICKET_RESTORED, TICKET_VERIFIED, TICKET_CLOSED,
)

TICKET_TRANSITIONS: Dict[str, Tuple[str, ...]] = {
    AWAITING_DISPATCH:          (TICKET_ASSIGNED, TICKET_CLOSED),
    TICKET_ASSIGNED:            (TICKET_FIELD_ACTION, TICKET_RESTORATION_PENDING,
                                 TICKET_CLOSED),
    TICKET_FIELD_ACTION:        (TICKET_RESTORATION_PENDING, TICKET_RESTORED,
                                 TICKET_CLOSED),
    TICKET_RESTORATION_PENDING: (TICKET_RESTORED, TICKET_FIELD_ACTION, TICKET_CLOSED),
    TICKET_RESTORED:            (TICKET_VERIFIED, TICKET_FIELD_ACTION, TICKET_CLOSED),
    TICKET_VERIFIED:            (TICKET_CLOSED,),
    TICKET_CLOSED:              (),
}

# Ticket state -> the incident state it drives. Keeping the two machines in
# step is what stops a ticket being "Closed" while its incident is still open.
TICKET_TO_INCIDENT: Dict[str, str] = {
    AWAITING_DISPATCH: RESPONSE_CREATED,
    TICKET_ASSIGNED: ASSIGNED,
    TICKET_FIELD_ACTION: FIELD_ACTION,
    TICKET_RESTORATION_PENDING: RESTORATION_PENDING,
    TICKET_RESTORED: RESTORED,
    TICKET_VERIFIED: VERIFICATION,
    TICKET_CLOSED: CLOSED,
}


def _check(machine: Dict[str, Tuple[str, ...]], kind: str,
           current: str, target: str) -> str:
    if target not in machine:
        raise TransitionError(
            f"'{target}' is not a valid {kind} state. "
            f"Valid states: {', '.join(machine.keys())}.")
    if current not in machine:
        raise TransitionError(f"Current {kind} state '{current}' is not recognised.")
    allowed = machine[current]
    if target not in allowed:
        allowed_txt = ", ".join(allowed) if allowed else "none (terminal state)"
        raise TransitionError(
            f"Cannot move {kind} from '{current}' to '{target}'. "
            f"Allowed from '{current}': {allowed_txt}.")
    return target


def transition_incident(current: str, target: str) -> str:
    return _check(INCIDENT_TRANSITIONS, "incident", current, target)


def transition_ticket(current: str, target: str) -> str:
    return _check(TICKET_TRANSITIONS, "ticket", current, target)


def can_transition_incident(current: str, target: str) -> bool:
    try:
        transition_incident(current, target)
        return True
    except TransitionError:
        return False


def allowed_incident_next(current: str) -> List[str]:
    return list(INCIDENT_TRANSITIONS.get(current, ()))


def allowed_ticket_next(current: str) -> List[str]:
    return list(TICKET_TRANSITIONS.get(current, ()))


def is_open(state: str) -> bool:
    return state != CLOSED
