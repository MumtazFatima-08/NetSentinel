#!/usr/bin/env bash
# PowerBack launcher. No build step, no install step required.
set -euo pipefail
cd "$(dirname "$0")/backend"
echo "Starting PowerBack on http://127.0.0.1:${PORT:-8000}"
exec python3 -m powerback.server
