/* ==========================================================================
   PowerBack frontend v2
   Vanilla JS, no build step, no framework, no external CDN — the app must
   run offline and deploy as static files anywhere.

   This file preserves every API contract from v1 exactly. What changed is
   presentation: a command-center Response Center, a tabbed hero Incident
   Detail screen with a lifecycle stepper, and a four-step citizen report
   wizard. No new endpoints were needed for any of it — see the handoff notes
   for why.
   ========================================================================== */
'use strict';

const API = (location.protocol === 'file:') ? 'http://127.0.0.1:8000' : '';

/* ---------------------------------------------------------------- helpers */
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const el = (tag, attrs = {}, ...kids) => {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v === null || v === undefined || v === false) continue;
    if (k === 'class') n.className = v;
    else if (k.startsWith('on') && typeof v === 'function') n.addEventListener(k.slice(2), v);
    else n.setAttribute(k, v);
  }
  for (const kid of kids.flat()) {
    if (kid === null || kid === undefined || kid === false) continue;
    n.appendChild(typeof kid === 'string' ? document.createTextNode(kid) : kid);
  }
  return n;
};
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const fmtTime = (iso) => {
  if (!iso) return '—';
  const d = new Date(iso);
  if (isNaN(d)) return String(iso);
  return d.toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
};
const fmtClock = (iso) => {
  if (!iso) return '—';
  const d = new Date(iso);
  return isNaN(d) ? String(iso) : d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
};
const titleCase = (s) => String(s || '').replace(/_/g, ' ').toLowerCase()
  .replace(/\b\w/g, (c) => c.toUpperCase());

function toast(msg, kind = '') {
  document.querySelectorAll('.toast').forEach((t) => t.remove());
  const t = el('div', { class: `toast ${kind}`, role: 'status' }, msg);
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 4200);
}

/* ------------------------------------------------------------------- api */
async function api(path, options = {}) {
  let res;
  try {
    res = await fetch(API + path, {
      headers: { 'Content-Type': 'application/json' },
      ...options,
      body: options.body ? JSON.stringify(options.body) : undefined,
    });
  } catch (networkErr) {
    const e = new Error('Could not reach the PowerBack server. Make sure the backend is running.');
    e.offline = true;
    throw e;
  }
  let data = null;
  try { data = await res.json(); } catch (_) { /* empty body is acceptable */ }
  if (!res.ok) {
    const e = new Error((data && data.error) || `Request failed (${res.status}).`);
    e.status = res.status;
    e.data = data;
    throw e;
  }
  return data;
}

function sessionId() {
  let id = null;
  try { id = localStorage.getItem('pb_session'); } catch (_) { /* private mode */ }
  if (!id) {
    id = 'web-' + Math.random().toString(36).slice(2, 10);
    try { localStorage.setItem('pb_session', id); } catch (_) { /* ignore */ }
  }
  return id;
}

/* ===========================================================================
   ICONS — hand-authored minimal line icons. No icon font, no CDN.
   =========================================================================== */
// ROOT-CAUSE FIX (submission QA pass): icon() used to return a raw SVG string.
// When that string was passed as a direct child to el(), the generic kid-handler
// in el() treats any string kid as plain text (document.createTextNode), so the
// literal "<svg ...>...</svg>" markup rendered as visible text instead of an
// icon. It only "worked" where a call site routed the string through
// `{ html: ... }` (element.innerHTML), which is an unnecessary parsing hack.
//
// Fix: icon() now builds and returns a REAL SVG DOM element via
// document.createElementNS, exactly like renderMap() already does for the map.
// A real node passed as a child to el() takes the appendChild(kid) branch, so
// it renders as an actual <svg> element everywhere it's used — as a direct
// child of a button, inside a span, inside an icon-square div — with no
// innerHTML/dangerouslySetInnerHTML-style hack anywhere in the icon pipeline.
const ICON_PATHS = {
  location: 'M12 21s7-6.5 7-12a7 7 0 1 0-14 0c0 5.5 7 12 7 12Z M12 12a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z',
  chat: 'M4 5h16v11H8l-4 4V5Z',
  camera: 'M4 8h3l2-2h6l2 2h3v11H4V8Z M12 17a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Z',
  alert: 'M12 3 2 20h20L12 3Z M12 10v4 M12 17h.01',
  map: 'M9 4 3 6v14l6-2 6 2 6-2V4l-6 2-6-2Z M9 4v14 M15 6v14',
  list: 'M8 6h13 M8 12h13 M8 18h13 M3 6h.01 M3 12h.01 M3 18h.01',
  users: 'M8 12a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Z M2 20c0-3.3 2.7-6 6-6s6 2.7 6 6 M17 8a3 3 0 1 0 0-6 M22 20c0-2.6-1.9-4.8-4.4-5.6',
  clock: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Z M12 7v5l3 3',
  check: 'm4 12 5 5 11-11',
  activity: 'M3 12h4l2-7 4 14 2-7h6',
  shield: 'M12 3 4 6v6c0 5 3.5 8.5 8 9 4.5-.5 8-4 8-9V6l-8-3Z',
  layers: 'm12 3 9 5-9 5-9-5 9-5Z M3 13l9 5 9-5 M3 18l9 5 9-5',
  zap: 'M13 2 4 13h6l-1 9 9-11h-6l1-9Z',
  send: 'm3 11 18-8-7 18-3-8-8-2Z',
  wrench: 'M14.7 6.3a4 4 0 0 1-5.4 5.4L4 17l3 3 5.3-5.3a4 4 0 0 1 5.4-5.4l-2.3 2.3-2-2 2.3-2.3Z',
  droplet: 'M12 3s6 6.5 6 11a6 6 0 1 1-12 0c0-4.5 6-11 6-11Z',
  arrowRight: 'M5 12h14 M13 5l7 7-7 7',
  plug: 'M9 3v5 M15 3v5 M6.5 8h11v3a5.5 5.5 0 0 1-11 0V8Z M12 16v5',
};
const SVG_NS = 'http://www.w3.org/2000/svg';
function icon(name, cls = '') {
  const d = ICON_PATHS[name] || ICON_PATHS.activity;
  const svg = document.createElementNS(SVG_NS, 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', 'currentColor');
  svg.setAttribute('stroke-width', '1.9');
  svg.setAttribute('stroke-linecap', 'round');
  svg.setAttribute('stroke-linejoin', 'round');
  svg.setAttribute('aria-hidden', 'true');
  if (cls) svg.setAttribute('class', cls);
  d.split(' M').forEach((seg, i) => {
    const path = document.createElementNS(SVG_NS, 'path');
    path.setAttribute('d', i === 0 ? seg : 'M' + seg);
    svg.appendChild(path);
  });
  return svg;
}
function iconSq(name, variant = '') {
  return el('div', { class: `icon-sq ${variant}` }, icon(name));
}

/* --------------------------------------------------------- shared pieces */
function priorityBadge(p) {
  const key = String(p || 'LOW').toLowerCase();
  return el('span', { class: `badge p-${key}` }, String(p || 'UNSET'));
}
function statusChip(s) {
  return el('span', { class: 'status-chip' }, String(s || '—').replace(/_/g, ' '));
}
function loadingBox(label = 'Loading…') {
  return el('div', { class: 'loading' }, el('div', { class: 'spinner' }), label);
}
function errorBox(err, retry) {
  const box = el('div', { class: 'errbox stack' },
    el('h3', {}, err.offline ? 'Backend unavailable' : 'Something went wrong'),
    el('p', { style: 'color:inherit' }, err.message));
  if (err.offline) {
    box.appendChild(el('p', { class: 'small mono', style: 'color:inherit' },
      'Start it with:  python -m powerback.server'));
  }
  if (retry) box.appendChild(el('button', { class: 'btn small', onclick: retry }, 'Try again'));
  return box;
}
function emptyBox(msg, action) {
  const n = el('div', { class: 'empty stack' }, el('p', { style: 'margin:0' }, msg));
  if (action) n.appendChild(action);
  return n;
}

/* ===========================================================================
   MAP  — SVG rendered from live incident data (no tiles, no API key)
   =========================================================================== */
function projector(points, w, h, pad = 0.18) {
  const pts = points.filter((p) => p && p.lat != null && p.lon != null);
  if (!pts.length) return null;
  const clat = pts.reduce((s, p) => s + p.lat, 0) / pts.length;
  const k = Math.cos(clat * Math.PI / 180) || 1e-6;
  const xs = pts.map((p) => p.lon * k);
  const ys = pts.map((p) => -p.lat);
  const minx = Math.min(...xs), maxx = Math.max(...xs);
  const miny = Math.min(...ys), maxy = Math.max(...ys);
  const span = Math.max(maxx - minx, maxy - miny, 0.0009) * (1 + pad * 2);
  const cx = (minx + maxx) / 2, cy = (miny + maxy) / 2;
  const size = Math.min(w, h);
  const fn = (lat, lon) => [
    (lon * k - cx) / span * size + w / 2,
    (-lat - cy) / span * size + h / 2,
  ];
  fn.metresToPx = (m) => {
    const degLat = m / 111320;
    return (degLat / span) * size;
  };
  return fn;
}

function renderMap(incidents, opts = {}) {
  const W = 760, H = opts.height || 430;
  const focus = opts.focus || null;

  // Collect real report/centroid coordinates AND, for each incident, four
  // synthetic corner points of its affected-radius circle (converted from
  // metres using the same approximation the backend uses for its own
  // candidate-search bounding box). Framing the projection around the circle
  // bounds -- not just the raw point cloud -- is what fixes both complaints
  // at once: a lone small incident no longer sits in a sea of empty grid
  // (the view zooms to its actual zone), and a large zone is never clipped
  // at the canvas edge (which is what was crowding the labels together).
  const points = [];
  incidents.forEach((inc) => {
    if (!inc.centroid) return;
    const { latitude: lat, longitude: lon } = inc.centroid;
    points.push({ lat, lon });
    const radiusM = Math.max(inc.affected_radius_m || 0, 60);
    const dLat = radiusM / 111320;
    const dLon = radiusM / (111320 * (Math.cos(lat * Math.PI / 180) || 1e-6));
    points.push({ lat: lat + dLat, lon }, { lat: lat - dLat, lon },
                { lat, lon: lon + dLon }, { lat, lon: lon - dLon });
    (inc.reports || []).forEach((r) => {
      if (r.latitude != null) points.push({ lat: r.latitude, lon: r.longitude });
    });
  });

  const shell = el('div', { class: 'map-shell' });
  if (!points.length) {
    shell.appendChild(el('div', { class: 'map-empty' },
      'No located reports yet. Submitting a report with a location will plot it here.'));
    return shell;
  }

  const proj = projector(points, W, H, 0.14);
  const NS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
  svg.setAttribute('role', 'img');
  svg.setAttribute('aria-label',
    `Map showing ${incidents.length} incident${incidents.length === 1 ? '' : 's'} and their reports.`);

  const mk = (tag, attrs) => {
    const n = document.createElementNS(NS, tag);
    for (const [k, v] of Object.entries(attrs)) n.setAttribute(k, v);
    return n;
  };

  svg.appendChild(mk('rect', { x: 0, y: 0, width: W, height: H, fill: '#EFF6FB' }));
  for (let x = 0; x <= W; x += 38) {
    svg.appendChild(mk('line', { x1: x, y1: 0, x2: x, y2: H, stroke: '#DCEAF2', 'stroke-width': 1 }));
  }
  for (let y = 0; y <= H; y += 38) {
    svg.appendChild(mk('line', { x1: 0, y1: y, x2: W, y2: y, stroke: '#DCEAF2', 'stroke-width': 1 }));
  }

  const colorFor = (p) => ({ CRITICAL: '#B3261E', HIGH: '#A8620A', MEDIUM: '#0077B6' }[p] || '#64708A');
  const priorityRank = (p) => ({ CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 }[p] ?? 4);

  // The single incident on an Incident Detail page is always the focus. On a
  // multi-incident overview with no explicit focus, the highest-priority open
  // incident is treated as visually dominant, so the most urgent situation is
  // never lost among several same-weight circles.
  const dominant = focus || (incidents.length > 1
    ? [...incidents].filter((i) => i.centroid)
      .sort((a, b) => priorityRank(a.priority) - priorityRank(b.priority))[0]?.public_id
    : null);

  const geo = incidents
    .filter((inc) => inc.centroid)
    .map((inc) => {
      const [cx, cy] = proj(inc.centroid.latitude, inc.centroid.longitude);
      const r = Math.max(20, Math.min(proj.metresToPx(Math.max(inc.affected_radius_m || 0, 60)), 190));
      return { inc, cx, cy, r, color: colorFor(inc.priority), isFocus: inc.public_id === dominant };
    });

  // ---- Pass 1: zones, report nodes, centroid markers ----
  geo.forEach(({ inc, cx, cy, r, color, isFocus }) => {
    svg.appendChild(mk('circle', {
      cx, cy, r, fill: color, 'fill-opacity': isFocus ? 0.14 : 0.07,
      stroke: color, 'stroke-opacity': isFocus ? 0.8 : 0.32,
      'stroke-width': isFocus ? 2.25 : 1.5, 'stroke-dasharray': '6 6',
    }));
    (inc.reports || []).forEach((rep) => {
      if (rep.latitude == null) return;
      const [rx, ry] = proj(rep.latitude, rep.longitude);
      const pending = rep.link_type === 'PENDING_REVIEW';
      svg.appendChild(mk('circle', {
        cx: rx, cy: ry, r: isFocus ? 6 : 5,
        fill: pending ? '#FFFFFF' : '#0077B6',
        stroke: pending ? '#03045E' : '#FFFFFF',
        'stroke-width': 2,
      }));
    });
    svg.appendChild(mk('circle', {
      cx, cy, r: isFocus ? 10 : 8, fill: color, stroke: '#fff', 'stroke-width': isFocus ? 2.75 : 2,
    }));
  });

  // ---- Pass 2: labels, placed to avoid collisions ----
  // Two lines per incident (id above the circle, zone size below it). Each
  // candidate rectangle is tested against every already-placed rectangle; on
  // collision the label steps further from the circle in fixed increments,
  // and once it has moved more than one step a thin leader line is drawn from
  // the circle edge to the label so it stays legibly connected to its zone.
  const placed = [];
  const overlaps = (a, b) => !(a.x2 < b.x || a.x > b.x2 || a.y2 < b.y || a.y > b.y2);
  const rectFor = (cx, y, textWidth, h) => ({ x: cx - textWidth / 2, x2: cx + textWidth / 2, y: y - h / 2, y2: y + h / 2 });
  const fitsCanvas = (rect) => rect.x > 2 && rect.x2 < W - 2 && rect.y > 2 && rect.y2 < H - 2;

  // Highest priority (most visually important) gets first pick of the clean
  // default slot directly above its circle.
  const order = [...geo].sort((a, b) => priorityRank(a.inc.priority) - priorityRank(b.inc.priority));

  order.forEach(({ inc, cx, cy, r, color }) => {
    const idText = inc.public_id;
    const idWidth = idText.length * 7.2 + 6;
    const candidates = [
      { x: cx, y: cy - r - 13, side: 'top' },
      { x: cx, y: cy + r + 24, side: 'bottom' },
      { x: cx + r + idWidth / 2 + 10, y: cy, side: 'right' },
      { x: cx - r - idWidth / 2 - 10, y: cy, side: 'left' },
      { x: cx, y: cy - r - 30, side: 'top-far' },
      { x: cx, y: cy + r + 41, side: 'bottom-far' },
    ];
    let chosen = null;
    for (const c of candidates) {
      const rect = rectFor(c.x, c.y, idWidth, 15);
      if (!fitsCanvas(rect)) continue;
      if (placed.some((p) => overlaps(rect, p))) continue;
      chosen = { ...c, rect };
      break;
    }
    if (!chosen) {
      // Every candidate collided -- fall back to the top slot and accept the
      // overlap rather than silently dropping the label.
      chosen = { x: cx, y: cy - r - 13, side: 'top', rect: rectFor(cx, cy - r - 13, idWidth, 15) };
    }
    placed.push(chosen.rect);

    const usesLeader = chosen.side !== 'top';
    if (usesLeader) {
      const anchorY = chosen.side.startsWith('bottom') ? cy + r : chosen.side === 'top-far' ? cy - r : cy;
      const anchorX = chosen.side === 'left' ? cx - r : chosen.side === 'right' ? cx + r : cx;
      svg.appendChild(mk('line', {
        x1: anchorX, y1: anchorY, x2: chosen.x, y2: chosen.y - 6,
        stroke: color, 'stroke-width': 1, 'stroke-opacity': 0.5, 'stroke-dasharray': '2 3',
      }));
    }

    const label = mk('text', {
      x: chosen.x, y: chosen.y, 'text-anchor': 'middle',
      'font-size': 13, 'font-weight': 700, fill: color, 'font-family': 'system-ui, sans-serif',
    });
    label.textContent = idText;
    svg.appendChild(label);

    if (inc.affected_radius_m > 0) {
      const sub = mk('text', {
        x: chosen.x, y: chosen.y + 15, 'text-anchor': 'middle',
        'font-size': 10.5, fill: '#64708A', 'font-family': 'system-ui, sans-serif',
      });
      sub.textContent = `~${Math.round(inc.affected_radius_m)} m zone`;
      svg.appendChild(sub);
    }
  });

  shell.appendChild(svg);
  shell.appendChild(el('div', { class: 'map-legend' },
    el('span', {}, el('i', { style: 'background:#0077B6' }), 'Citizen report'),
    el('span', {}, el('i', { style: 'background:#fff;border:2px solid #03045E' }), 'Awaiting review'),
    el('span', {}, el('i', { style: 'background:#B3261E' }), 'Incident centroid'),
    el('span', { class: 'muted' }, 'Rendered from live report coordinates — no external map service.')));
  return shell;
}

/* ===========================================================================
   SIGNATURE VISUAL — many signals converge into one incident
   Reused on the landing page and (compact) on the incident hero header.
   =========================================================================== */
function signalFigure(observations, incidentLabel = 'One incident') {
  return el('div', { class: 'sig-figure' },
    el('div', { class: 'sig-list' },
      observations.map((o, i) => el('div', {
        class: 'sig-chip', style: `animation-delay:${i * 90}ms`,
      }, el('span', { class: 'n' }, `R${i + 1}`), el('span', { class: 'd' }), o))),
    el('div', { class: 'sig-arrow', 'aria-hidden': 'true' }, el('div', {}, icon('arrowRight'))),
    el('div', { class: 'sig-out' },
      el('div', { class: 'id' }, 'CORRELATION ENGINE'),
      el('div', { class: 'big' }, incidentLabel),
      el('div', { class: 'small', style: 'color:#9FC2D8' },
        'semantic · spatial · temporal · evidence')));
}

/* ===========================================================================
   VIEW: LANDING
   =========================================================================== */
function viewHome(root) {
  const OBSERVATIONS = [
    'Power has gone out on our street.',
    'Several houses have no electricity.',
    'The street lights are also off.',
    'Power is still not back.',
    'The transformer area seems affected.',
  ];

  // Compact hero visual: the same "many signals -> one incident" idea as the
  // panel-dark section below, but condensed to three chips so it reads at a
  // glance as a companion graphic rather than duplicating that section's
  // detailed explanation. This is what the hero communicates visually instead
  // of leaving the right half of the navy panel empty on wide screens.
  const heroVisual = el('div', { class: 'hero-visual' },
    el('div', { class: 'sig-list' },
      OBSERVATIONS.slice(0, 3).map((o, i) => el('div', {
        class: 'sig-chip', style: `animation-delay:${i * 100}ms`,
      }, el('span', { class: 'n' }, `R${i + 1}`), el('span', { class: 'd' }), o))),
    el('div', { class: 'sig-arrow-down', 'aria-hidden': 'true' }, icon('arrowRight')),
    el('div', { class: 'sig-out' },
      el('div', { class: 'id' }, 'CORRELATION ENGINE'),
      el('div', { class: 'big' }, 'One incident'),
      el('div', { class: 'small', style: 'color:#9FC2D8' }, 'semantic · spatial · temporal · evidence')));

  root.appendChild(el('section', { class: 'hero' },
    el('div', { class: 'wrap hero-grid' },
      el('div', {},
        el('div', { class: 'eyebrow' }, 'Outage intelligence & response coordination'),
        el('h1', {}, 'From scattered signals to ', el('em', {}, 'coordinated response'), '.'),
        el('p', { class: 'lede' },
          'One physical outage arrives as dozens of disconnected reports. PowerBack correlates them into a single explainable incident, prioritises it, and tracks it through response, restoration and verification.'),
        el('div', { class: 'btn-row' },
          el('a', { class: 'btn', href: '#/report' }, icon('send'), 'Report an outage'),
          el('a', { class: 'btn on-dark', href: '#/center' }, icon('layers'), 'Open Response Center'))),
      heroVisual)));

  root.appendChild(el('section', { class: 'section' },
    el('div', { class: 'wrap' },
      el('div', { class: 'panel-dark' },
        el('div', { class: 'eyebrow' }, 'The core idea'),
        el('h2', { style: 'margin-bottom:6px' }, 'Five observations. One incident.'),
        el('p', { style: 'max-width:58ch' },
          'The problem isn\u2019t collecting more reports — it\u2019s understanding which reports describe the same incident.'),
        el('div', { style: 'margin-top:22px' }, signalFigure(OBSERVATIONS))))));

  function experienceCard(ic, t, d, href) {
    const openLine = el('div', {
      class: 'small',
      style: 'color:var(--blue);font-weight:650;display:flex;align-items:center;gap:6px',
    }, 'Open', el('span', { style: 'width:14px;height:14px' }, icon('arrowRight')));
    return el('a', { class: 'card feature-card', href, style: 'text-decoration:none;display:flex' },
      iconSq(ic, 'cyan'),
      el('h3', {}, t),
      el('p', { style: 'margin:0;flex:1' }, d),
      openLine);
  }
  const experiences = [
    ['map', 'Response Center', 'A command view of every active incident: the map, the queue, and what needs a human decision.', '#/center'],
    ['zap', 'Incident Detail', 'The evidence behind every grouping, shown as real computed values — never a fabricated score.', '#/center'],
    ['chat', 'Citizen Report', 'A short, guided flow. No technical knowledge required to tell us what you\u2019re seeing.', '#/report'],
  ];
  const experienceCards = experiences.map((row) => experienceCard(row[0], row[1], row[2], row[3]));
  root.appendChild(el('section', { class: 'section tight' },
    el('div', { class: 'wrap' },
      el('div', { class: 'grid three' }, experienceCards))));

  const sigBox = el('div', { class: 'grid four' });
  root.appendChild(el('section', { class: 'section tight' },
    el('div', { class: 'wrap' },
      el('div', { class: 'section-head' },
        el('h2', {}, 'Built on four real signals'),
        el('p', { style: 'margin:0;max-width:64ch' },
          'No single "AI score." Every correlation decision is a transparent combination of independently computed, independently explainable signals.')),
      sigBox)));

  const SIGNAL_META = {
    semantic: ['chat', 'Semantic', 'Do the descriptions mean the same thing?'],
    spatial: ['location', 'Spatial', 'How close are the reports geographically?'],
    temporal: ['clock', 'Temporal', 'How close together in time?'],
    evidence: ['camera', 'Evidence', 'Do the observed details overlap?'],
  };
  api('/api/system').then((sys) => {
    sigBox.innerHTML = '';
    Object.entries(sys.correlation.weights).forEach(([key, weight]) => {
      const meta = SIGNAL_META[key] || ['activity', titleCase(key), ''];
      sigBox.appendChild(el('div', { class: 'card feature-card' },
        iconSq(meta[0]),
        el('h3', { style: 'margin-bottom:0' }, meta[1]),
        el('p', { class: 'small', style: 'margin:0' }, meta[2]),
        el('div', { class: 'factor-top', style: 'margin-top:auto' },
          el('b', {}, 'Weight'), el('span', { class: 'v' }, String(weight)))));
    });
  }).catch(() => { sigBox.appendChild(errorBox({ message: 'Could not load live configuration.' })); });

  const capBox = el('div', {});
  root.appendChild(el('section', { class: 'section' },
    el('div', { class: 'wrap' },
      el('div', { class: 'section-head' },
        el('h2', {}, 'What this prototype does and does not do')),
      capBox)));
  api('/api/system')
    .then((sys) => {
      capBox.innerHTML = '';
      capBox.appendChild(el('div', { class: 'grid two' },
        el('div', { class: 'card' },
          el('div', { class: 'card-head' }, iconSq('shield', 'ghost'), el('h3', { style: 'margin:0' }, 'Boundaries we hold')),
          el('ul', { class: 'checklist dash' },
            sys.boundaries.map((b) => el('li', {}, b)))),
        el('div', { class: 'card' },
          el('div', { class: 'card-head' }, iconSq('layers', 'ghost'), el('h3', { style: 'margin:0' }, 'Live configuration')),
          el('dl', { class: 'kv' },
            el('dt', {}, 'Semantic model'), el('dd', {}, sys.semantic.backend),
            el('dt', {}, 'Type'), el('dd', {}, sys.semantic.is_neural ? 'Neural embeddings' : 'Vector-space model'),
            el('dt', {}, 'Image analysis'), el('dd', {}, sys.vision.vision_enabled ? 'Enabled' : 'Not enabled'),
            el('dt', {}, 'Utility feed'), el('dd', {}, sys.utility_integration.connected ? 'Connected' : 'Not connected'),
            el('dt', {}, 'Merge threshold'), el('dd', { class: 'mono' }, String(sys.correlation.thresholds.merge))))));
    })
    .catch((err) => { capBox.appendChild(errorBox(err)); });
}

/* ===========================================================================
   VIEW: CITIZEN REPORT  — four-step guided wizard
   =========================================================================== */
const QUICK_PHRASES = [
  'No power in my home.',
  'Power has gone out on our street.',
  'Several houses have no electricity.',
  'The street lights are also off.',
  'Power is flickering on and off.',
  'Power is still not back.',
];
const HAZARD_PHRASE = 'I can see sparks, smoke, fire, or a fallen or live wire near the affected area.';

function viewReport(root) {
  const state = {
    step: 0, lat: null, lon: null, locLabel: null,
    description: '', photo: null, photoName: null, hazard: false,
  };
  const STEPS = ['Location', 'What happened', 'Evidence', 'Review & submit'];

  const wrap = el('div', { class: 'wrap narrow section' });
  root.appendChild(wrap);

  wrap.appendChild(el('div', { class: 'section-head' },
    el('h1', {}, 'Report an outage'),
    el('p', {}, 'Four quick steps. No technical knowledge required.')));

  const progress = el('div', {});
  const stepHost = el('div', {});
  const card = el('div', { class: 'card' }, progress, stepHost);
  wrap.appendChild(card);

  function renderProgress() {
    progress.innerHTML = '';
    const dots = el('div', { class: 'wizard-progress' },
      STEPS.map((_, i) => el('div', { class: `wiz-dot ${i < state.step ? 'done' : i === state.step ? 'active' : ''}` })));
    const labels = el('div', { class: 'wiz-labels' },
      STEPS.map((s, i) => el('span', { class: i === state.step ? 'current' : '' }, s)));
    progress.appendChild(dots);
    progress.appendChild(labels);
  }

  function goto(step) {
    state.step = Math.max(0, Math.min(STEPS.length - 1, step));
    renderProgress();
    renderStep();
    wrap.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  function renderStep() {
    stepHost.innerHTML = '';
    const body = el('div', { class: 'wiz-step' });
    stepHost.appendChild(body);
    [stepLocation, stepWhatHappened, stepEvidence, stepReview][state.step](body);
  }

  function stepLocation(body) {
    const status = el('div', { class: 'hint' },
      state.locLabel ? `Location set: ${state.locLabel}` : 'Optional — helps us group your report with nearby ones.');
    const latInput = el('input', { type: 'text', inputmode: 'decimal', placeholder: 'Latitude', value: state.lat ?? '' });
    const lonInput = el('input', { type: 'text', inputmode: 'decimal', placeholder: 'Longitude', value: state.lon ?? '' });
    const manual = el('div', { class: 'grid two hidden', style: 'gap:10px;margin-top:12px' }, latInput, lonInput);

    body.appendChild(el('div', { class: 'field' },
      el('label', {}, 'Where is this happening?'),
      el('div', { class: 'choice-grid' },
        el('button', {
          class: 'choice', type: 'button',
          onclick: () => {
            if (!navigator.geolocation) { status.textContent = 'This browser does not support location. Enter coordinates manually below.'; manual.classList.remove('hidden'); return; }
            status.textContent = 'Getting your location…';
            navigator.geolocation.getCurrentPosition(
              (pos) => {
                state.lat = pos.coords.latitude.toFixed(6);
                state.lon = pos.coords.longitude.toFixed(6);
                state.locLabel = 'your current location';
                status.textContent = `Location set: ${state.locLabel}`;
              },
              (gerr) => { status.textContent = `Could not get location (${gerr.message}). Enter coordinates manually, or continue without one.`; manual.classList.remove('hidden'); },
              { timeout: 8000, enableHighAccuracy: true });
          },
        }, iconSq('location', 'sm ghost'), 'Use my location'),
        el('button', {
          class: 'choice', type: 'button',
          onclick: () => { manual.classList.toggle('hidden'); },
        }, iconSq('map', 'sm ghost'), 'Enter manually'),
        el('button', {
          class: 'choice', type: 'button',
          onclick: () => {
            state.lat = '17.449700'; state.lon = '78.539200'; state.locLabel = 'the demo locality';
            latInput.value = state.lat; lonInput.value = state.lon;
            status.textContent = `Location set: ${state.locLabel}`;
          },
        }, iconSq('layers', 'sm ghost'), 'Use demo location')),
      manual, status));

    body.appendChild(el('div', { class: 'btn-row end' },
      el('button', {
        class: 'btn', type: 'button', onclick: () => {
          const lat = latInput.value.trim(), lon = lonInput.value.trim();
          if ((lat && !lon) || (lon && !lat)) { status.textContent = 'Enter both latitude and longitude, or leave both blank.'; return; }
          if (lat && lon) { state.lat = lat; state.lon = lon; state.locLabel = state.locLabel || 'a manual location'; }
          goto(1);
        },
      }, 'Continue', icon('arrowRight'))));
  }

  function stepWhatHappened(body) {
    const textarea = el('textarea', {
      maxlength: '1000', placeholder: 'Describe it in your own words — e.g. "Power has gone out on our street and the street lights are off too."',
    });
    textarea.value = state.description;
    const err = el('div', {});

    body.appendChild(el('div', { class: 'field' },
      el('label', {}, 'Quick phrases'),
      el('div', { class: 'pill-row' },
        QUICK_PHRASES.map((p) => el('button', {
          class: 'btn secondary small', type: 'button',
          onclick: () => { textarea.value = textarea.value ? `${textarea.value} ${p}` : p; textarea.focus(); },
        }, p)))));

    body.appendChild(el('div', { class: 'field' },
      el('label', { for: 'desc' }, 'What are you seeing?'),
      textarea, err,
      el('div', { class: 'hint' }, 'You do not need to know the cause.')));

    body.appendChild(el('div', { class: 'btn-row', style: 'justify-content:space-between' },
      el('button', { class: 'btn secondary', type: 'button', onclick: () => goto(0) }, 'Back'),
      el('button', {
        class: 'btn', type: 'button', onclick: () => {
          const v = textarea.value.trim();
          if (v.length < 3) { err.innerHTML = ''; err.appendChild(el('div', { class: 'err' }, 'Please describe what you are seeing.')); textarea.focus(); return; }
          state.description = v;
          goto(2);
        },
      }, 'Continue', icon('arrowRight'))));
  }

  function stepEvidence(body) {
    const photoStatus = el('div', { class: 'hint' },
      state.photoName ? `Attached: ${state.photoName}` : 'Optional. Kept as evidence for a human reviewer — not analysed automatically.');
    const photoInput = el('input', {
      type: 'file', accept: 'image/jpeg,image/png,image/webp', style: 'padding:9px;min-height:auto',
      onchange: (e) => {
        const f = e.target.files && e.target.files[0];
        state.photo = null; state.photoName = null;
        if (!f) { photoStatus.textContent = 'Optional. Kept as evidence for a human reviewer — not analysed automatically.'; return; }
        if (f.size > 5 * 1024 * 1024) { photoStatus.textContent = `That image is ${(f.size / 1048576).toFixed(1)} MB. The limit is 5 MB.`; e.target.value = ''; return; }
        const reader = new FileReader();
        reader.onload = () => { state.photo = reader.result; state.photoName = f.name; photoStatus.textContent = `Attached: ${f.name}`; };
        reader.onerror = () => { photoStatus.textContent = 'Could not read that file. Try another image.'; };
        reader.readAsDataURL(f);
      },
    });

    body.appendChild(el('div', { class: 'field' },
      el('label', {}, 'Photo evidence'), photoInput, photoStatus));

    const toggle = el('label', { class: `hazard-toggle ${state.hazard ? 'selected' : ''}` },
      el('input', {
        type: 'checkbox', checked: state.hazard || null,
        onchange: (e) => { state.hazard = e.target.checked; toggle.classList.toggle('selected', state.hazard); },
      }),
      el('div', {},
        el('div', { style: 'font-weight:700;color:var(--navy);display:flex;align-items:center;gap:8px' },
          el('span', { style: 'width:18px;height:18px;color:var(--crit)' }, icon('alert')), 'Safety concern'),
        el('div', { class: 'small', style: 'margin-top:3px' }, HAZARD_PHRASE)));
    body.appendChild(el('div', { class: 'field' }, el('label', {}, 'Is there an immediate safety hazard?'), toggle));

    body.appendChild(el('div', { class: 'btn-row', style: 'justify-content:space-between' },
      el('button', { class: 'btn secondary', type: 'button', onclick: () => goto(1) }, 'Back'),
      el('button', { class: 'btn', type: 'button', onclick: () => goto(3) }, 'Review', icon('arrowRight'))));
  }

  const pipeBox = el('div', {});
  const resultBox = el('div', {});

  function stepReview(body) {
    body.appendChild(el('div', { class: 'stack' },
      el('div', { class: 'hairline-card' },
        el('div', { class: 'small muted' }, 'LOCATION'),
        el('div', {}, state.locLabel ? titleCase(state.locLabel) : 'Not provided')),
      el('div', { class: 'hairline-card' },
        el('div', { class: 'small muted' }, 'DESCRIPTION'),
        el('div', {}, state.description)),
      el('div', { class: 'hairline-card' },
        el('div', { class: 'small muted' }, 'EVIDENCE'),
        el('div', {}, state.photoName ? `Photo: ${state.photoName}` : 'No photo attached',
          state.hazard ? el('div', { style: 'margin-top:6px' }, el('span', { class: 'badge p-critical' }, 'Safety concern flagged')) : null))));

    const submitBtn = el('button', { class: 'btn block', type: 'button' }, 'Submit report');
    const backBtn = el('button', { class: 'btn secondary', type: 'button', onclick: () => goto(2) }, 'Back');
    body.appendChild(el('div', { class: 'btn-row', style: 'margin-top:18px' }, backBtn, submitBtn));

    submitBtn.addEventListener('click', async () => {
      submitBtn.disabled = true; backBtn.disabled = true;
      submitBtn.textContent = 'Processing…';
      pipeBox.innerHTML = ''; resultBox.innerHTML = '';
      await runPipeline(pipeBox);

      try {
        let description = state.description;
        const lower = description.toLowerCase();
        if (state.hazard && !lower.includes('spark') && !lower.includes('smoke')
            && !lower.includes('fire') && !lower.includes('wire')) {
          description = `${description} ${HAZARD_PHRASE}`;
        }
        const payload = { description, session_id: sessionId() };
        if (state.lat && state.lon) { payload.latitude = parseFloat(state.lat); payload.longitude = parseFloat(state.lon); }
        if (state.photo) payload.photo_base64 = state.photo;

        const out = await api('/api/reports', { method: 'POST', body: payload });
        renderPipelineResult(pipeBox, out.trace);
        renderSubmitResult(resultBox, out);
        resultBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        submitBtn.textContent = 'Report another outage';
        submitBtn.disabled = false; backBtn.disabled = false;
        submitBtn.addEventListener('click', () => {
          state.step = 0; state.description = ''; state.photo = null; state.photoName = null; state.hazard = false;
          pipeBox.innerHTML = ''; resultBox.innerHTML = '';
          goto(0);
        }, { once: true });
      } catch (err) {
        pipeBox.innerHTML = '';
        submitBtn.disabled = false; backBtn.disabled = false;
        submitBtn.textContent = 'Submit report';
        if (err.status === 429) resultBox.appendChild(el('div', { class: 'notice warn' }, err.message));
        else resultBox.appendChild(errorBox(err));
      }
    }, { once: true });
  }

  renderProgress();
  renderStep();
  wrap.appendChild(pipeBox);
  wrap.appendChild(resultBox);
}

const PIPE_STAGES = [
  ['EXTRACT', 'Report received'],
  ['EMBED', 'Semantic encoding'],
  ['DEDUPE', 'Duplicate check'],
  ['CORRELATE', 'Correlation decision'],
  ['PRIORITIZE', 'Priority assessment'],
];

function runPipeline(box) {
  box.innerHTML = '';
  const card = el('div', { class: 'card' },
    el('h3', {}, 'Processing'),
    el('div', { class: 'pipe' },
      PIPE_STAGES.map(([key, label], i) => el('div', { class: 'pipe-step', 'data-stage': key },
        el('div', { class: 'pipe-icon' }, String(i + 1)),
        el('div', {}, el('div', { class: 't' }, label), el('div', { class: 'd' }, 'Waiting…'))))));
  box.appendChild(card);
  const steps = [...card.querySelectorAll('.pipe-step')];
  return new Promise((resolve) => {
    let i = 0;
    const tick = () => {
      if (i > 0) steps[i - 1].classList.remove('active');
      if (i >= steps.length) return resolve();
      steps[i].classList.add('active');
      i += 1;
      setTimeout(tick, 130);
    };
    tick();
  });
}

function renderPipelineResult(box, trace) {
  const steps = [...box.querySelectorAll('.pipe-step')];
  const byStage = {};
  (trace || []).forEach((t) => { byStage[t.stage] = t; });
  steps.forEach((step) => {
    const key = step.getAttribute('data-stage');
    const info = byStage[key];
    step.classList.remove('active');
    const detail = step.querySelector('.d');
    if (!info) { step.style.opacity = '.35'; detail.textContent = 'Not reached'; return; }
    step.classList.add(info.ok ? 'done' : 'failed');
    step.querySelector('.pipe-icon').textContent = info.ok ? '✓' : '!';
    detail.textContent = info.detail;
  });
}

function renderSubmitResult(box, out) {
  box.innerHTML = '';

  if (out.duplicate_of) {
    box.appendChild(el('div', { class: 'card stack' },
      el('div', { class: 'card-head' }, el('h3', {}, 'Looks like a repeat'), el('span', { class: 'badge plain' }, 'Duplicate')),
      el('p', { style: 'margin:0' }, out.message),
      el('div', { class: 'notice' },
        `Matched your earlier report ${out.duplicate_of.public_id} at ${Math.round(out.duplicate_of.similarity * 100)}% similarity. It was stored but not counted twice.`)));
    return;
  }

  const inc = out.incident;
  const corr = out.correlation || {};
  const decisionBadge = {
    MERGE: ['ok', 'Correlated'], REVIEW: ['review', 'Sent for review'], NEW: ['info', 'New incident'],
  }[corr.decision] || ['plain', corr.decision || '—'];

  const card = el('div', { class: 'card stack' },
    el('div', { class: 'card-head' }, el('h3', {}, 'Thanks — your report was processed'), el('span', { class: `badge ${decisionBadge[0]}` }, decisionBadge[1])),
    el('p', { style: 'margin:0' }, out.message));

  if (corr.confidence !== undefined && corr.decision !== 'NEW') {
    card.appendChild(el('div', {},
      el('div', { class: 'factor-top' }, el('b', {}, 'Correlation confidence'), el('span', { class: 'v' }, corr.confidence.toFixed(2))),
      el('div', { class: 'bar' }, el('i', { style: `width:${Math.round(corr.confidence * 100)}%` }))));
  }

  if (inc) {
    card.appendChild(el('div', { class: 'row-top' },
      el('span', { class: 'row-id' }, inc.public_id), priorityBadge(inc.priority),
      el('span', { class: 'muted small' }, `${inc.report_count} correlated report${inc.report_count === 1 ? '' : 's'}`)));
    card.appendChild(el('a', { class: 'btn', href: `#/incident/${inc.public_id}` }, 'See the incident', icon('arrowRight')));
  }
  box.appendChild(card);
}

/* ===========================================================================
   VIEW: RESPONSE CENTER  — command-center layout
   =========================================================================== */
async function viewCenter(root) {
  const host = el('div', { class: 'wrap section' });
  root.appendChild(host);
  host.appendChild(loadingBox('Loading the response center…'));

  const load = async () => {
    host.innerHTML = '';
    try {
      const [stats, incidentList, reviews] = await Promise.all([
        api('/api/stats'), api('/api/incidents'), api('/api/reviews'),
      ]);

      host.appendChild(el('div', { class: 'card-head' },
        el('div', {},
          el('h1', { style: 'margin-bottom:.15em' }, 'Response Center'),
          el('p', { class: 'muted', style: 'margin:0' }, 'Active incidents, ranked by response priority.')),
        el('div', { class: 'btn-row' },
          el('button', { class: 'btn secondary small', onclick: load }, 'Refresh'),
          el('button', {
            class: 'btn small', onclick: async (e) => {
              const b = e.currentTarget; b.disabled = true; b.textContent = 'Loading demo…';
              try {
                await api('/api/demo/seed', { method: 'POST', body: { reset: true } });
                toast('Demo scenarios loaded.', 'ok');
                await load();
              } catch (err) { toast(err.message, 'err'); b.disabled = false; b.textContent = 'Load demo data'; }
            },
          }, 'Load demo data'))));

      host.appendChild(el('div', { class: 'kpi-strip', style: 'margin-bottom:22px' },
        el('div', { class: 'stat' }, el('div', { class: 'n' }, String(stats.open_incidents)), el('div', { class: 'l' }, 'Open incidents')),
        el('div', { class: 'stat' }, el('div', { class: 'n' }, String(stats.reports)), el('div', { class: 'l' }, 'Reports received')),
        el('div', { class: 'stat' }, el('div', { class: 'n' }, String(stats.consolidation_ratio)), el('div', { class: 'l' }, 'Reports per incident')),
        el('div', { class: 'stat' }, el('div', { class: 'n' }, String(stats.pending_review)), el('div', { class: 'l' }, 'Awaiting review'))));

      const detailed = await Promise.all(
        incidentList.incidents.slice(0, 12).map((i) => api(`/api/incidents/${i.public_id}`)));

      const left = el('div', { class: 'stack' });
      const right = el('div', { class: 'stack' });
      host.appendChild(el('div', { class: 'split wide-left', style: 'margin-bottom:22px' }, left, right));

      left.appendChild(el('div', { class: 'card-head' }, el('h2', { style: 'margin:0' }, 'Live map')));
      left.appendChild(renderMap(detailed, { height: 440 }));

      right.appendChild(el('h2', { style: 'margin:0' }, 'Response queue'));
      const queueSorted = [...incidentList.incidents]
        .filter((i) => i.status !== 'CLOSED')
        .sort((a, b) => ({ CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 }[a.priority] ?? 4)
          - ({ CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 }[b.priority] ?? 4))
        .slice(0, 6);
      if (!queueSorted.length) {
        right.appendChild(emptyBox('No open incidents right now.'));
      } else {
        right.appendChild(el('div', { class: 'rows' }, queueSorted.map((inc) => el('button', {
          class: `row-item priority-rail p-${String(inc.priority || 'low').toLowerCase()}`,
          onclick: () => { location.hash = `#/incident/${inc.public_id}`; },
        },
          el('div', { class: 'row-top' },
            el('span', { class: 'row-id' }, inc.public_id), priorityBadge(inc.priority),
            inc.hazard ? el('span', { class: 'badge p-critical' }, 'Hazard') : null),
          el('div', { class: 'row-meta' },
            el('span', {}, `${inc.report_count} report${inc.report_count === 1 ? '' : 's'}`),
            el('span', {}, statusChip(inc.status)))))));
      }

      if (reviews.reviews.length) {
        host.appendChild(el('div', { class: 'card stack', style: 'margin-bottom:22px;border-color:#C9D0E4' },
          el('div', { class: 'card-head' },
            el('div', { style: 'display:flex;align-items:center;gap:10px' }, iconSq('alert', 'ghost'), el('h2', { style: 'margin:0' }, 'Needs your decision')),
            el('span', { class: 'badge review' }, `${reviews.reviews.length} pending`)),
          el('p', { style: 'margin:0' }, 'These reports were close to an existing incident, but not close enough for PowerBack to merge them on its own.'),
          el('div', { class: 'rows' }, reviews.reviews.map((rv) => reviewRow(rv, load)))));
      }

      host.appendChild(el('h2', {}, 'All incidents'));
      if (!incidentList.incidents.length) {
        host.appendChild(emptyBox(
          'No incidents yet. Submit a report, or load the demo scenarios.',
          el('a', { class: 'btn', href: '#/report' }, 'Report an outage')));
        return;
      }
      host.appendChild(el('div', { class: 'rows' },
        incidentList.incidents.map((inc) => el('button', {
          class: `row-item priority-rail p-${String(inc.priority || 'low').toLowerCase()}`,
          onclick: () => { location.hash = `#/incident/${inc.public_id}`; },
        },
          el('div', { class: 'row-top' },
            el('span', { class: 'row-id' }, inc.public_id), priorityBadge(inc.priority), statusChip(inc.status),
            inc.hazard ? el('span', { class: 'badge p-critical' }, 'Hazard') : null,
            inc.needs_review ? el('span', { class: 'badge review' }, 'Review') : null),
          el('div', { class: 'row-meta' },
            el('span', {}, `${inc.report_count} report${inc.report_count === 1 ? '' : 's'}`),
            el('span', {}, `~${Math.round(inc.affected_radius_m)} m zone`),
            el('span', {}, `correlation ${inc.correlation_confidence.toFixed(2)}`),
            el('span', {}, `updated ${fmtTime(inc.last_seen)}`))))));
    } catch (err) {
      host.innerHTML = '';
      host.appendChild(errorBox(err, load));
    }
  };
  await load();
}

function reviewRow(rv, reload) {
  const act = async (action, btn) => {
    btn.disabled = true;
    try {
      await api(`/api/reviews/${rv.link_id}`, { method: 'POST', body: { action } });
      toast(action === 'CONFIRM' ? 'Report confirmed into the incident.' : 'Report separated into its own incident.', 'ok');
      await reload();
    } catch (err) { toast(err.message, 'err'); btn.disabled = false; }
  };
  return el('div', { class: 'report-card pending stack' },
    el('div', { class: 'row-top' },
      el('span', { class: 'row-id' }, rv.report), el('span', { class: 'muted small' }, `near ${rv.incident}`),
      el('span', { class: 'badge review' }, `score ${rv.match_score.toFixed(2)}`)),
    el('div', { class: 'q' }, rv.description),
    rv.reasons && rv.reasons.length
      ? el('details', { class: 'disclose' },
        el('summary', {}, 'Why this is uncertain'),
        el('div', {}, el('ul', { class: 'checklist dash' }, rv.reasons.slice(0, 4).map((r) => el('li', {}, r)))))
      : null,
    el('div', { class: 'btn-row' },
      el('button', { class: 'btn small', onclick: (e) => act('CONFIRM', e.currentTarget) }, 'Same incident'),
      el('button', { class: 'btn secondary small', onclick: (e) => act('REJECT', e.currentTarget) }, 'Separate incident')));
}

/* ===========================================================================
   VIEW: INCIDENT DETAIL  — tabbed hero screen with a lifecycle stepper
   =========================================================================== */
const LIFECYCLE_ORDER = [
  'NEW_SIGNALS', 'INCIDENT_DETECTED', 'VALIDATING', 'PRIORITIZED',
  'RESPONSE_CREATED', 'ASSIGNED', 'FIELD_ACTION', 'RESTORATION_PENDING',
  'RESTORED', 'VERIFICATION', 'CLOSED',
];
const LIFECYCLE_LABELS = {
  NEW_SIGNALS: 'New signals', INCIDENT_DETECTED: 'Detected', VALIDATING: 'Validating',
  PRIORITIZED: 'Prioritized', RESPONSE_CREATED: 'Response created', ASSIGNED: 'Assigned',
  FIELD_ACTION: 'Field action', RESTORATION_PENDING: 'Restoration pending',
  RESTORED: 'Restored', VERIFICATION: 'Verification', CLOSED: 'Closed',
};

function lifecycleStepper(status) {
  const idx = LIFECYCLE_ORDER.indexOf(status);
  const nodes = [];
  LIFECYCLE_ORDER.forEach((s, i) => {
    if (i > 0) nodes.push(el('div', { class: `lc-connector ${i <= idx ? 'done' : ''}` }));
    const cls = s === 'CLOSED' && idx === LIFECYCLE_ORDER.length - 1 ? 'closed'
      : i < idx ? 'past' : i === idx ? 'current' : '';
    nodes.push(el('div', { class: `lc-node ${cls}` },
      el('div', { class: 'lc-dot' }), el('div', { class: 'lc-label' }, LIFECYCLE_LABELS[s])));
  });
  return el('div', { class: 'lifecycle-strip' }, nodes);
}

function tabs(defs, initial = 0) {
  const bar = el('div', { class: 'tabbar', role: 'tablist' });
  const panelHost = el('div', { class: 'tab-panel' });
  function show(i) {
    [...bar.children].forEach((b, idx) => b.classList.toggle('active', idx === i));
    panelHost.innerHTML = '';
    panelHost.className = 'tab-panel';
    void panelHost.offsetWidth;
    defs[i].render(panelHost);
  }
  defs.forEach((d, i) => {
    bar.appendChild(el('button', {
      class: `tab-btn ${i === initial ? 'active' : ''}`, role: 'tab', type: 'button',
      onclick: () => show(i),
    }, d.label));
  });
  const container = el('div', {}, bar, panelHost);
  show(initial);
  return container;
}

async function viewIncident(root, ref) {
  const host = el('div', { class: 'wrap section' });
  root.appendChild(host);
  host.appendChild(loadingBox('Loading incident…'));

  const load = async () => {
    host.innerHTML = '';
    let inc, explain;
    try {
      inc = await api(`/api/incidents/${encodeURIComponent(ref)}`);
      explain = await api(`/api/incidents/${encodeURIComponent(ref)}/explain`);
    } catch (err) {
      host.appendChild(errorBox(err, load));
      return;
    }

    const priorityKey = String(inc.priority || 'low').toLowerCase();

    host.appendChild(el('a', { class: 'btn ghost small', href: '#/center', style: 'padding-left:0;margin-bottom:8px' }, '\u2190 Response Center'));
    host.appendChild(el('div', { class: `panel-dark priority-rail p-${priorityKey}`, style: 'margin-bottom:20px' },
      el('div', { class: 'row-top', style: 'margin-bottom:8px' },
        el('span', { class: 'badge on-dark' }, inc.public_id),
        priorityBadge(inc.priority), statusChip(inc.status),
        inc.hazard ? el('span', { class: 'badge p-critical' }, 'Safety hazard') : null,
        inc.needs_review ? el('span', { class: 'badge review' }, 'Has pending review') : null),
      el('h2', { style: 'color:#fff;margin-bottom:4px' },
        inc.symptoms && inc.symptoms[0] ? inc.symptoms[0] : 'Correlated outage incident'),
      el('p', { style: 'margin-bottom:18px' },
        `${inc.report_count} correlated report${inc.report_count === 1 ? '' : 's'} · ~${Math.round(inc.affected_radius_m)} m affected zone · updated ${fmtTime(inc.last_seen)}`),
      lifecycleStepper(inc.status)));

    host.appendChild(el('div', { class: 'kpi-strip', style: 'margin-bottom:20px' },
      el('div', { class: 'stat' }, el('div', { class: 'n' }, String(inc.report_count)), el('div', { class: 'l' }, 'Correlated reports')),
      el('div', { class: 'stat' }, el('div', { class: 'n' }, `${Math.round(inc.affected_radius_m)}m`), el('div', { class: 'l' }, 'Affected zone')),
      el('div', { class: 'stat' }, el('div', { class: 'n' }, inc.correlation_confidence.toFixed(2)), el('div', { class: 'l' }, 'Correlation confidence')),
      el('div', { class: 'stat' }, el('div', { class: 'n' }, String(inc.evidence_summary.photo_count || 0)), el('div', { class: 'l' }, 'Photo evidence'))));

    host.appendChild(tabs([
      { id: 'overview', label: 'Overview', render: (p) => renderOverviewTab(p, inc, explain) },
      { id: 'reports', label: `Reports (${inc.reports.length})`, render: (p) => renderReportsTab(p, inc) },
      { id: 'evidence', label: 'Evidence', render: (p) => renderEvidenceTab(p, inc) },
      { id: 'timeline', label: 'Timeline', render: (p) => renderTimelineTab(p, inc) },
      { id: 'response', label: 'Response', render: (p) => p.appendChild(responseCard(inc, load)) },
      { id: 'restoration', label: 'Restoration', render: (p) => p.appendChild(restorationCard(inc, load)) },
    ]));
  };

  await load();
}

function renderOverviewTab(panel, inc, explain) {
  const left = el('div', { class: 'stack' });
  const right = el('div', { class: 'stack' });
  panel.appendChild(el('div', { class: 'split' }, left, right));

  left.appendChild(renderMap([inc], { focus: inc.public_id }));

  const whyCard = el('div', { class: 'card stack' },
    el('div', { class: 'card-head' }, iconSq('zap', 'ghost'), el('h2', { style: 'margin:0' }, 'Why did PowerBack group these reports?')));
  if (!explain.factors.length) {
    whyCard.appendChild(el('p', { style: 'margin:0' }, 'This incident has a single seed report, so there is no correlation to explain yet.'));
  } else {
    explain.factors.forEach((f) => {
      whyCard.appendChild(el('div', { class: 'factor' },
        el('div', { class: 'factor-top' }, el('b', {}, f.label), el('span', { class: 'v' }, f.mean_score.toFixed(2))),
        el('div', { class: 'bar' }, el('i', { style: `width:${Math.round(f.mean_score * 100)}%` })),
        el('div', { class: 'hint' }, `Mean across ${f.samples} correlated report${f.samples === 1 ? '' : 's'} · weight ${f.weight}`)));
    });
  }
  if (explain.shared_evidence && explain.shared_evidence.length) {
    whyCard.appendChild(el('div', {}, el('h3', {}, 'Shared observations'),
      el('ul', { class: 'checklist' }, explain.shared_evidence.map((s) => el('li', {}, s)))));
  }
  whyCard.appendChild(el('div', { class: 'notice' }, explain.boundary));
  left.appendChild(whyCard);

  right.appendChild(el('div', { class: 'card stack' },
    el('div', { class: 'card-head' }, el('h2', { style: 'margin:0' }, 'Priority'), priorityBadge(inc.priority)),
    el('p', { class: 'small muted', style: 'margin:0' }, `Rule-based score ${inc.priority_score}. Every reason below comes from a rule that actually fired.`),
    el('ul', { class: 'checklist' },
      inc.priority_reasons.length ? inc.priority_reasons.map((r) => el('li', {}, `${r.text} (+${r.points})`))
        : [el('li', {}, 'No escalating factors detected.')]),
    el('div', { class: 'notice' }, el('b', {}, 'Recommended next action: '), inc.recommended_action || 'Monitor.')));

  if (inc.symptoms.length) {
    right.appendChild(el('div', { class: 'card' },
      el('div', { class: 'card-head' }, iconSq('activity', 'ghost'), el('h3', { style: 'margin:0' }, 'Observed symptoms')),
      el('ul', { class: 'checklist' }, inc.symptoms.map((s) => el('li', {}, s)))));
  }
}

function renderReportsTab(panel, inc) {
  const list = el('div', { class: 'rows' });
  inc.reports.forEach((r) => {
    const pending = r.link_type === 'PENDING_REVIEW';
    list.appendChild(el('div', { class: `report-card ${pending ? 'pending' : ''}` },
      el('div', { class: 'row-top' },
        el('span', { class: 'row-id' }, r.public_id), el('span', { class: 'muted small' }, fmtClock(r.occurred_at)),
        pending ? el('span', { class: 'badge review' }, 'Awaiting review') : null,
        r.has_photo ? el('span', { class: 'badge info' }, 'Photo') : null),
      el('div', { class: 'q' }, r.description),
      r.has_photo ? el('img', {
        src: `${API}/media/${r.photo_path}`, alt: `Evidence photo for report ${r.public_id}`,
        style: 'max-width:180px;border-radius:10px;border:1px solid var(--line);margin-top:8px',
      }) : null,
      el('div', { class: 'row-meta' },
        el('span', {}, r.link_type === 'MERGED' ? `match ${r.match_score.toFixed(2)}` : 'not counted yet'),
        r.latitude != null ? el('span', {}, `${r.latitude.toFixed(5)}, ${r.longitude.toFixed(5)}`) : el('span', {}, 'no location'),
        r.flags && r.flags.length ? el('span', {}, `flags: ${r.flags.map(titleCase).join(', ')}`) : null)));
  });
  panel.appendChild(el('div', { class: 'card' }, el('div', { class: 'card-head' }, el('h2', { style: 'margin:0' }, 'Correlated reports'),
    el('span', { class: 'muted small' }, `${inc.reports.length} linked`)), list));
}

function renderEvidenceTab(panel, inc) {
  const ev = inc.evidence_summary || {};
  const photos = inc.reports.filter((r) => r.has_photo);
  panel.appendChild(el('div', { class: 'split' },
    el('div', { class: 'stack' },
      el('div', { class: 'card stack' },
        el('div', { class: 'card-head' }, iconSq('camera', 'ghost'), el('h2', { style: 'margin:0' }, 'Photo evidence')),
        photos.length
          ? el('div', { class: 'grid three' }, photos.map((r) => el('div', { class: 'hairline-card', style: 'padding:0;overflow:hidden' },
            el('img', { src: `${API}/media/${r.photo_path}`, alt: `Evidence from ${r.public_id}`, style: 'width:100%;display:block' }),
            el('div', { class: 'small', style: 'padding:8px 10px' }, r.public_id))))
          : el('p', { style: 'margin:0' }, 'No photos attached to this incident yet.'),
        el('div', { class: 'notice' }, ev.vision && ev.vision.note ? ev.vision.note :
          'Photos are preserved for human review. PowerBack does not run automated image classification, so no image-derived confidence is produced.'))),
    el('div', { class: 'stack' },
      el('div', { class: 'card' },
        el('div', { class: 'card-head' }, iconSq('layers', 'ghost'), el('h3', { style: 'margin:0' }, 'Observed evidence categories')),
        (ev.concept_labels && ev.concept_labels.length)
          ? el('ul', { class: 'checklist' }, ev.concept_labels.map((c) => el('li', {}, c)))
          : el('p', { style: 'margin:0' }, 'No structured evidence categories matched yet.')),
      el('div', { class: 'card' },
        el('div', { class: 'card-head' }, el('h3', { style: 'margin:0' }, 'At a glance')),
        el('dl', { class: 'kv' },
          el('dt', {}, 'Confirmed reports'), el('dd', {}, String(ev.report_count ?? inc.report_count)),
          el('dt', {}, 'Pending review'), el('dd', {}, String(ev.pending_review_count ?? 0)),
          el('dt', {}, 'Photos'), el('dd', {}, String(ev.photo_count ?? 0)))))));
}

function renderTimelineTab(panel, inc) {
  panel.appendChild(el('div', { class: 'card' },
    el('div', { class: 'card-head' }, iconSq('clock', 'ghost'), el('h2', { style: 'margin:0' }, 'Timeline')),
    (inc.timeline && inc.timeline.length)
      ? el('ul', { class: 'timeline' }, inc.timeline.map((t) => el('li', {},
        el('div', { class: 'a' }, titleCase(t.action)), el('div', { class: 't' }, `${fmtTime(t.created_at)} · ${t.actor}`))))
      : el('p', { style: 'margin:0' }, 'No recorded actions yet.')));
}

function responseCard(inc, reload) {
  const ticket = (inc.tickets || [])[0];
  const card = el('div', { class: 'card stack' },
    el('div', { class: 'card-head' },
      el('div', { style: 'display:flex;align-items:center;gap:10px' }, iconSq('send', 'ghost'), el('h2', { style: 'margin:0' }, 'Response')),
      ticket ? statusChip(ticket.status) : el('span', { class: 'badge plain' }, 'Not opened')));

  if (!ticket) {
    card.appendChild(el('p', { style: 'margin:0' }, 'Open a response ticket to generate the field brief and start the dispatch workflow.'));
    card.appendChild(el('button', {
      class: 'btn', onclick: async (e) => {
        const b = e.currentTarget; b.disabled = true; b.textContent = 'Opening…';
        try {
          const out = await api(`/api/incidents/${inc.public_id}/response`, { method: 'POST', body: {} });
          toast(out.message, 'ok'); await reload();
        } catch (err) { toast(err.message, 'err'); b.disabled = false; b.textContent = 'Open response ticket'; }
      },
    }, 'Open response ticket'));
    return card;
  }

  card.appendChild(el('dl', { class: 'kv' },
    el('dt', {}, 'Ticket'), el('dd', { class: 'mono' }, ticket.public_id),
    el('dt', {}, 'Priority'), el('dd', {}, ticket.priority || '—'),
    el('dt', {}, 'Team'), el('dd', {}, ticket.assigned_team || 'Unassigned')));

  const next = ticket.allowed_transitions || [];
  if (next.length) {
    card.appendChild(el('div', {},
      el('div', { class: 'hint', style: 'margin-bottom:8px' }, 'Advance the ticket:'),
      el('div', { class: 'btn-row' }, next.map((st) => el('button', {
        class: 'btn secondary small',
        onclick: async (e) => {
          const b = e.currentTarget; b.disabled = true;
          const body = { status: st };
          if (st === 'ASSIGNED' && !ticket.assigned_team) {
            const team = prompt('Assign to which team?', 'Field Crew 7');
            if (!team) { b.disabled = false; return; }
            body.assigned_team = team;
          }
          try {
            await api(`/api/response-tickets/${ticket.public_id}`, { method: 'PATCH', body });
            toast(`Ticket moved to ${titleCase(st)}.`, 'ok'); await reload();
          } catch (err) { toast(err.message, 'err'); b.disabled = false; }
        },
      }, titleCase(st))))));
  }

  card.appendChild(el('details', { class: 'disclose' },
    el('summary', {}, 'Response brief'), el('div', {}, el('pre', { class: 'brief' }, ticket.brief || ''))));
  return card;
}

function restorationCard(inc, reload) {
  const r = inc.restoration || {};
  const bandClass = { HIGH: 'ok', MEDIUM: 'p-medium', LOW: 'plain' }[r.band] || 'plain';

  const card = el('div', { class: 'card stack' },
    el('div', { class: 'card-head' },
      el('div', { style: 'display:flex;align-items:center;gap:10px' }, iconSq('plug', 'ghost'), el('h2', { style: 'margin:0' }, 'Restoration')),
      el('span', { class: `badge ${bandClass}` }, `${r.band || 'LOW'} confidence`)),
    el('div', {},
      el('div', { class: 'factor-top' }, el('b', {}, 'Restoration confidence'), el('span', { class: 'v' }, (r.confidence ?? 0).toFixed(2))),
      el('div', { class: 'bar' }, el('i', { style: `width:${Math.round((r.confidence || 0) * 100)}%` }))));

  if (r.contributions && r.contributions.length) {
    card.appendChild(el('ul', { class: 'checklist dash' }, r.contributions.map((c) => el('li', {}, c.text))));
  }

  if (inc.status !== 'CLOSED') {
    card.appendChild(el('div', { class: 'btn-row' },
      el('button', { class: 'btn secondary small', onclick: (e) => postRestoration(e, inc, 'RESPONSE_TEAM', 'Work completed on site', reload) }, 'Team: restored'),
      el('button', { class: 'btn secondary small', onclick: (e) => postRestoration(e, inc, 'CITIZEN', 'Power is back', reload) }, 'Citizen: power back')));

    const canVerify = r.can_verify;
    card.appendChild(el('button', {
      class: 'btn', disabled: !canVerify,
      onclick: async (e) => {
        const b = e.currentTarget; b.disabled = true; b.textContent = 'Verifying…';
        try {
          await api(`/api/incidents/${inc.public_id}/verify`, { method: 'POST', body: {} });
          toast('Restoration verified.', 'ok'); await reload();
        } catch (err) { toast(err.message, 'err'); b.disabled = false; b.textContent = 'Verify restoration'; }
      },
    }, canVerify ? 'Verify restoration' : `Verify (needs ${r.verify_threshold ?? 0.7} confidence)`));

    if (inc.status === 'VERIFICATION' || inc.status === 'RESTORED') {
      card.appendChild(el('button', {
        class: 'btn secondary',
        onclick: async (e) => {
          const b = e.currentTarget; b.disabled = true;
          try {
            await api(`/api/incidents/${inc.public_id}/close`, { method: 'POST', body: {} });
            toast('Incident closed.', 'ok'); await reload();
          } catch (err) { toast(err.message, 'err'); b.disabled = false; }
        },
      }, 'Close incident'));
    }
  }

  card.appendChild(el('div', { class: 'notice warn small' }, r.disclaimer || ''));
  return card;
}

async function postRestoration(e, inc, source, note, reload) {
  const b = e.currentTarget; b.disabled = true;
  try {
    await api(`/api/incidents/${inc.public_id}/restoration`, { method: 'POST', body: { source, status: 'RESTORED', note } });
    toast('Restoration signal recorded.', 'ok'); await reload();
  } catch (err) { toast(err.message, 'err'); b.disabled = false; }
}

/* ===========================================================================
   VIEW: ABOUT / HOW IT WORKS
   =========================================================================== */
async function viewAbout(root) {
  const host = el('div', { class: 'wrap section stack' });
  root.appendChild(host);
  host.appendChild(el('h1', {}, 'How PowerBack works'));
  host.appendChild(loadingBox());

  let sys;
  try { sys = await api('/api/system'); }
  catch (err) { host.innerHTML = ''; host.appendChild(errorBox(err)); return; }
  host.querySelector('.loading').remove();

  const c = sys.correlation;
  host.appendChild(el('div', { class: 'card stack' },
    el('div', { class: 'card-head' }, iconSq('zap'), el('h2', { style: 'margin:0' }, 'The correlation decision')),
    el('p', { style: 'margin:0' },
      'When a report arrives, PowerBack finds incidents within a bounded search window, scores four independent signals, and combines them into one confidence value.'),
    el('div', { class: 'grid four' },
      Object.entries(c.weights).map(([k, v]) => el('div', { class: 'stat' },
        el('div', { class: 'n' }, String(v)), el('div', { class: 'l' }, `${k} weight`)))),
    el('ul', { class: 'checklist dash' },
      el('li', {}, `Merge automatically at ${c.thresholds.merge} confidence or above.`),
      el('li', {}, `Route to a human between ${c.thresholds.review} and ${c.thresholds.merge}.`),
      el('li', {}, `Create a separate incident below ${c.thresholds.review}.`),
      el('li', {}, `Block an automatic merge if semantic agreement is under ${c.thresholds.semantic_floor}, however close in space and time.`),
      el('li', {}, `Only consider incidents within ${c.candidate_gates.radius_m} m and ${c.candidate_gates.window_minutes} minutes.`)),
    el('div', { class: 'notice' }, c.note)));

  host.appendChild(el('div', { class: 'grid two' },
    el('div', { class: 'card stack' },
      el('div', { class: 'card-head' }, iconSq('chat', 'ghost'), el('h3', { style: 'margin:0' }, 'Semantic similarity')),
      el('p', { class: 'small', style: 'margin:0' }, sys.semantic.method),
      el('dl', { class: 'kv' },
        el('dt', {}, 'Backend'), el('dd', { class: 'mono' }, sys.semantic.backend),
        el('dt', {}, 'Dimensions'), el('dd', { class: 'mono' }, String(sys.semantic.dim)),
        el('dt', {}, 'Neural'), el('dd', {}, sys.semantic.is_neural ? 'Yes' : 'No'))),
    el('div', { class: 'card stack' },
      el('div', { class: 'card-head' }, iconSq('camera', 'ghost'), el('h3', { style: 'margin:0' }, 'Image evidence')),
      el('p', { class: 'small', style: 'margin:0' }, sys.vision.note),
      el('dl', { class: 'kv' },
        el('dt', {}, 'Classification'), el('dd', {}, sys.vision.vision_enabled ? 'Enabled' : 'Not performed'),
        el('dt', {}, 'Validation'), el('dd', { class: 'small' }, sys.vision.validation)))));

  host.appendChild(el('div', { class: 'card stack' },
    el('div', { class: 'card-head' }, iconSq('plug', 'ghost'), el('h2', { style: 'margin:0' }, 'Restoration verification')),
    el('p', { style: 'margin:0' }, sys.restoration.note),
    el('ul', { class: 'checklist dash' },
      Object.entries(sys.restoration.weights).map(([k, v]) => el('li', {}, `${titleCase(k)} — weight ${v}${v === 0 ? ' (not connected in this build)' : ''}`)))));

  host.appendChild(el('div', { class: 'panel-dark stack' },
    el('h2', { style: 'margin:0' }, 'What we do not claim'),
    el('ul', { class: 'checklist dash', style: 'color:#AFCFE2' }, sys.boundaries.map((b) => el('li', { style: 'color:#AFCFE2' }, b)))));
}

/* ===========================================================================
   ROUTER
   =========================================================================== */
const ROUTES = [
  [/^\/?$/, viewHome],
  [/^\/report\/?$/, viewReport],
  [/^\/center\/?$/, viewCenter],
  [/^\/about\/?$/, viewAbout],
  [/^\/incident\/([^/]+)\/?$/, viewIncident],
];

async function router() {
  const raw = location.hash.replace(/^#/, '') || '/';
  const view = $('#view');
  view.innerHTML = '';
  window.scrollTo(0, 0);

  document.querySelectorAll('[data-nav]').forEach((a) => {
    const base = '/' + raw.split('/')[1];
    a.removeAttribute('aria-current');
    if (a.getAttribute('data-nav') === (base === '/' ? '/' : base)) a.setAttribute('aria-current', 'page');
  });

  for (const [pattern, handler] of ROUTES) {
    const m = raw.match(pattern);
    if (m) {
      try {
        await handler(view, ...m.slice(1).map(decodeURIComponent));
      } catch (err) {
        view.innerHTML = '';
        view.appendChild(el('div', { class: 'wrap section' }, errorBox(err, router)));
      }
      return;
    }
  }
  view.appendChild(el('div', { class: 'wrap section' },
    emptyBox('That page does not exist.', el('a', { class: 'btn', href: '#/' }, 'Go home'))));
}

window.addEventListener('hashchange', router);
window.addEventListener('DOMContentLoaded', router);
if (document.readyState !== 'loading') router();
