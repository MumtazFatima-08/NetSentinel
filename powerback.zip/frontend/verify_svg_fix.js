'use strict';
/*
 * Minimal DOM shim used ONLY to actually execute app.js's el()/icon()/iconSq()
 * functions and the real call sites that were broken, since no browser is
 * available in this environment. This runs the real function bodies from
 * app.js (extracted verbatim) against a faithful-enough Element/Text/SVG
 * implementation and inspects the actual resulting node tree.
 */
class Node {
  constructor() { this.childNodes = []; this.parentNode = null; }
  appendChild(child) { child.parentNode = this; this.childNodes.push(child); return child; }
  get textContent() {
    return this.childNodes.map((c) => c.textContent).join('');
  }
}
class TextNode extends Node {
  constructor(data) { super(); this.nodeType = 3; this.data = String(data); }
  get textContent() { return this.data; }
}
class Element extends Node {
  constructor(tag, ns) {
    super();
    this.tagName = tag;
    this.ns = ns || null;
    this.attributes = {};
    this._className = '';
    this.eventListeners = {};
  }
  setAttribute(k, v) { this.attributes[k] = String(v); if (k === 'class') this._className = String(v); }
  getAttribute(k) { return this.attributes[k]; }
  removeAttribute(k) { delete this.attributes[k]; }
  addEventListener(name, fn) { (this.eventListeners[name] = this.eventListeners[name] || []).push(fn); }
  set className(v) { this._className = v; this.attributes.class = v; }
  get className() { return this._className; }
  set innerHTML(v) { this.childNodes = []; if (v) this.appendChild(new TextNode(v)); }
}
const document_ = {
  createElement: (tag) => new Element(tag, 'html'),
  createElementNS: (ns, tag) => new Element(tag, ns),
  createTextNode: (data) => new TextNode(data),
};

function serialize(node) {
  if (node.nodeType === 3) return node.data;
  const attrs = Object.entries(node.attributes)
    .filter(([k]) => k !== 'html')
    .map(([k, v]) => ` ${k}="${v}"`).join('');
  const kids = node.childNodes.map((c) => serialize(c)).join('');
  return `<${node.tagName}${attrs}>${kids}</${node.tagName}>`;
}

// Walk the tree looking for the ACTUAL bug: literal SVG markup sitting inside
// a text node (which is what a browser renders as visible text). A real
// <svg> Element child is fine and expected.
function findRawSvgText(node, path) {
  path = path || 'root';
  const hits = [];
  if (node.nodeType === 3) {
    if (/<svg|<\/svg>|<path/.test(node.data)) hits.push({ path, text: node.data });
    return hits;
  }
  node.childNodes.forEach((c, i) => {
    hits.push.apply(hits, findRawSvgText(c, path + '>' + node.tagName + '[' + i + ']'));
  });
  return hits;
}
function countSvgElements(node) {
  let n = node.tagName === 'svg' ? 1 : 0;
  node.childNodes.forEach((c) => { n += countSvgElements(c); });
  return n;
}

const fs = require('fs');
const path = require('path');
const src = fs.readFileSync(path.join(__dirname, 'app.js'), 'utf8');

function extract(startMarker, endMarker) {
  const start = src.indexOf(startMarker);
  if (start < 0) throw new Error('start marker not found: ' + startMarker);
  const end = src.indexOf(endMarker, start);
  if (end < 0) throw new Error('end marker not found: ' + endMarker);
  return src.slice(start, end + endMarker.length);
}

const elSrc = extract('const el = (tag, attrs', "\n};");
const iconSrc = extract('const ICON_PATHS = {', '\n  return svg;\n}');
const iconSqSrc = extract('function iconSq(name', "\n}");
const experienceCardSrc = extract('function experienceCard(', "\n  }");
const signalFigureSrc = extract('function signalFigure(', "\n}");

const vm = require('vm');
const sandbox = { document: document_, console: console, module: { exports: {} } };
vm.createContext(sandbox);
vm.runInContext(
  elSrc + '\n' + iconSrc + '\n' + iconSqSrc + '\n' + signalFigureSrc + '\n' + experienceCardSrc +
  '\nmodule.exports = { el: el, icon: icon, iconSq: iconSq, signalFigure: signalFigure, experienceCard: experienceCard };',
  sandbox
);

const el = sandbox.module.exports.el;
const icon = sandbox.module.exports.icon;
const iconSq = sandbox.module.exports.iconSq;
const signalFigure = sandbox.module.exports.signalFigure;
const experienceCard = sandbox.module.exports.experienceCard;

console.log('='.repeat(78));
console.log('REAL CODE EXECUTION TEST -- functions extracted verbatim from app.js');
console.log('='.repeat(78));

let allClean = true;

function check(label, node) {
  const svgCount = countSvgElements(node);
  const rawHits = findRawSvgText(node);
  const ok = rawHits.length === 0 && svgCount > 0;
  allClean = allClean && ok;
  console.log('\n[' + (ok ? 'PASS' : 'FAIL') + '] ' + label);
  console.log('  serialized:', serialize(node));
  console.log('  real <svg> elements found:', svgCount);
  if (rawHits.length) {
    console.log('  *** RAW SVG TEXT LEAKED INTO DOM ***');
    rawHits.forEach((h) => console.log('   at', h.path, '->', h.text.slice(0, 60)));
  }
  return ok;
}

const homeCta1 = el('a', { class: 'btn', href: '#/report' }, icon('send'), 'Report an outage');
check('Home CTA: "Report an outage" button', homeCta1);

const homeCta2 = el('a', { class: 'btn on-dark', href: '#/center' }, icon('layers'), 'Open Response Center');
check('Home CTA: "Open Response Center" button', homeCta2);

const continueBtn = el('button', { class: 'btn', type: 'button' }, 'Continue', icon('arrowRight'));
check('Report wizard: "Continue" button (this is the literal "Continue<svg...>" bug report case)', continueBtn);

const sq = iconSq('map', 'cyan');
check('iconSq("map") icon-square component', sq);

const card = experienceCard('zap', 'Incident Detail', 'Test description', '#/center');
check('Home experience card (nested icon inside a div inside an <a>)', card);

const fig = signalFigure(['Report A', 'Report B'], 'One incident');
check('Signal->incident figure (hero arrow icon)', fig);

console.log('\n' + '='.repeat(78));
console.log(allClean
  ? 'ALL CHECKS PASS -- no raw SVG text in any DOM tree, real <svg> elements present.'
  : '*** FAILURES DETECTED ***');
console.log('='.repeat(78));
process.exit(allClean ? 0 : 1);
