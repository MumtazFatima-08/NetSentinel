#!/usr/bin/env python3
"""
PowerBack demo rehearsal.

Walks the complete demo exactly as a judge would click it, against a running
server, and prints what the engine actually returned at each step.

    python3 -m powerback.server          # in one terminal
    python3 demo/rehearse.py             # in another
"""
import json
import os
import sys
import urllib.error
import urllib.request

BASE = os.environ.get("PB_BASE", "http://127.0.0.1:8000")


def call(path, method="GET", body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(
        BASE + path, data=data, method=method,
        headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return resp.status, json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        return exc.code, json.loads(exc.read())
    except urllib.error.URLError as exc:
        print(f"\nCould not reach {BASE} ({exc.reason}).")
        print("Start the server first:  python3 -m powerback.server")
        sys.exit(1)


def step(n, msg):
    print(f"\n[{n}] {msg}")


def main():
    step(1, "Load demo scenarios through the real pipeline")
    status, _ = call("/api/demo/seed", "POST", {"reset": True})
    print("   seed HTTP", status)

    step(2, "Response Center overview")
    _, st = call("/api/stats")
    print(f"   open={st['open_incidents']} reports={st['reports']} "
          f"reports-per-incident={st['consolidation_ratio']} awaiting-review={st['pending_review']}")
    _, inc = call("/api/incidents")
    for i in inc["incidents"]:
        print(f"   {i['public_id']}  {i['priority']:<8} {i['status']:<14} "
              f"reports={i['report_count']} hazard={i['hazard']}")

    step(3, "Open INC-001 and ask: why were these grouped?")
    _, ex = call("/api/incidents/INC-001/explain")
    for f in ex["factors"]:
        print(f"   {f['label']:<48} {f['mean_score']:.2f}  (weight {f['weight']})")
    print("   shared observations:", ", ".join(ex["shared_evidence"]) or "none")

    step(4, "Human review queue — the engine declined to guess")
    _, rv = call("/api/reviews")
    if not rv["reviews"]:
        print("   (no pending reviews)")
        return
    for r in rv["reviews"]:
        print(f"   link={r['link_id']} {r['report']} score={r['match_score']:.2f} :: {r['description']}")
    link = rv["reviews"][0]["link_id"]
    _, before = call("/api/incidents/INC-001")
    print(f"   before confirm: priority={before['priority']} "
          f"reports={before['report_count']} hazard={before['hazard']}")
    _, res = call(f"/api/reviews/{link}", "POST", {"action": "CONFIRM"})
    print(f"   AFTER CONFIRM : priority={res['incident']['priority']} "
          f"reports={res['incident']['report_count']} hazard={res['incident']['hazard']}")

    step(5, "Open a response ticket")
    _, r = call("/api/incidents/INC-001/response", "POST", {})
    ticket = r["ticket"]["public_id"]
    print(f"   {ticket} {r['ticket']['status']} | incident {r['incident']['status']}")

    step(6, "Advance the ticket through the workflow")
    for state, team in (("ASSIGNED", "Field Crew 7"), ("FIELD_ACTION", None),
                        ("RESTORATION_PENDING", None)):
        body = {"status": state}
        if team:
            body["assigned_team"] = team
        _, u = call(f"/api/response-tickets/{ticket}", "PATCH", body)
        print(f"   -> {u['ticket']['status']:<20} incident={u['incident']['status']}")

    step(7, "Premature verification must be refused")
    status, v = call("/api/incidents/INC-001/verify", "POST", {})
    print(f"   [{status}] {v.get('error', '')[:92]}")

    step(8, "Record restoration signals")
    for src, note in (("RESPONSE_TEAM", "fuse replaced"), ("CITIZEN", "power back"),
                      ("CITIZEN", "lights on"), ("CITIZEN", "supply restored")):
        _, rr = call("/api/incidents/INC-001/restoration", "POST",
                     {"source": src, "status": "RESTORED", "note": note})
        print(f"   {src:<14} -> confidence {rr['restoration']['confidence']:.2f} "
              f"({rr['restoration']['band']})")

    step(9, "Verify and close")
    _, v = call("/api/incidents/INC-001/verify", "POST", {})
    print("   verified ->", v["incident"]["status"])
    _, c = call("/api/incidents/INC-001/close", "POST", {})
    print("   closed   ->", c["incident"]["status"])
    print("   tickets  ->", [x["status"] for x in c["incident"]["tickets"]])

    step(10, "The separate incidents are untouched")
    _, inc = call("/api/incidents")
    for i in inc["incidents"]:
        print(f"   {i['public_id']}  {i['status']:<12} {i['priority']:<8} reports={i['report_count']}")

    step(11, "Repeatability — reseed from clean state")
    call("/api/demo/seed", "POST", {"reset": True})
    _, st = call("/api/stats")
    print("   ", json.dumps(st))

    print("\nDEMO REHEARSAL COMPLETE")


if __name__ == "__main__":
    main()
